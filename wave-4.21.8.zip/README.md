# Wave Android — бэкенд на Rust

Раньше внутри APK работал Node.js (`libnode.so`, ~50 МБ на архитектуру) с ядром десктопного Wave
(`main.cjs` + провайдеры, ~7 400 строк JS) через заглушку Electron. Теперь вся эта логика — на Rust,
в `libwavenode.so`. Интерфейс (WebView: `assets/wave/ui`), Java-оболочка (`classes.dex`) и воспроизведение
(`<audio>`/hls.js в WebView, `PlaybackService`) не менялись — ни байта.

Java-класс `app.wave.mobile.NodeRunner` по-прежнему вызывает `System.loadLibrary("node")`, затем
`"wavenode"`, `setEnv(...)` и `startNode(...)`. Rust-библиотека экспортирует ровно эти JNI-функции и поднимает
локальный сервер с тем же API, что был у `server.cjs`, поэтому замена прозрачна.

## Структура

| Файл | Что было в JS |
|---|---|
| `core/src/server.rs` | `node/server.cjs`: `/api/call`, SSE `/api/events`, `/api/window`, `/api/upload`, прокси `/px/`, медиа `/m/`, статика `/ui/`, колбэк Spotify на `:43821` |
| `core/src/commands.rs` | `ipcMain.handle("wave:call")` — все команды интерфейса, вход в Яндекс/Spotify |
| `core/src/engine.rs` | `main.cjs`: подбор потока и версий, «Лучшее качество», поиск, «Моя волна», артисты, импорт, фоновый подбор плейлистов, свои файлы, синхронизация лайков Яндекса |
| `core/src/cfg.rs` | настройки по умолчанию, очистка входных данных, `publicSettings`, починка файлов при старте |
| `core/src/providers/*` | `providers/*.cjs`: SoundCloud, Audius, Spotify, YouTube Music, Яндекс Музыка (+ расшифровка lossless), тексты (Яндекс/LRCLib/Genius), Афиша, теги файлов, подбор версий |
| `core/src/store.rs`, `vault.rs` | `store.cjs`, `safeStorage` (тот же формат `WV1` + AES-256-GCM — входы в аккаунты сохраняются) |
| `node-stub/` | пустой `libnode.so` |

Файлы данных (`settings.json`, `library.json`, `*-token.bin`, `media/`) — те же, что у Node-версии.

Интерфейс лежит в `ui/` (с 4.20 правится здесь, скрипт сборки кладёт его в APK вместо исходного). Оформление
«Wave» на телефоне — `ui/wave-skin.css`; прежний вид остался оформлением «Яндекс Музыка» (`ui/mobile.css`).
Версия приложения — `APP_VERSION` / `APP_CODE` в `build-apk.py` и `version` в `core/Cargo.toml`.

## Сборка

Нужно: Rust с целями `aarch64-linux-android`, `armv7-linux-androideabi`, `cargo-ndk`, Android SDK
(build-tools) + NDK, JDK (для `keytool`), Python 3.

```bash
python build-apk.py
```

Скрипт собирает библиотеки (`cargo ndk`), берёт исходный APK (`../Wave-Android-мини-плеер.apk`), заменяет
нативные библиотеки, убирает Node.js и его скрипты, выравнивает и подписывает → `../Wave-Android-rust.apk`.

Подпись: по умолчанию создаётся `android/wave-rust.keystore` (пароль `waverust`). Чтобы APK встал поверх
старой версии без удаления, подпишите своим исходным ключом:

```bash
WAVE_KEYSTORE=путь/к/ключу.jks WAVE_KEYSTORE_PASS=пароль WAVE_KEY_ALIAS=алиас python build-apk.py --skip-cargo
```

## Проверка на ПК

```bash
cargo build --release --bin wave-desktop-test
WAVE_DATA=./testdata WAVE_PORT=47811 WAVE_KEY=test ./target/release/wave-desktop-test <папка с ui/ из APK>
```

и открыть `http://127.0.0.1:47811/ui/index.html?k=test` в браузере.

## Отличия от Node-версии

* Ошибки Spotify API теперь приходят с настоящим текстом (в JS вызывалась неопределённая `apiError`, и любая
  ошибка превращалась в «apiError is not defined»; из-за этого не работал и запасной путь `/tracks` для плейлистов).
* `artist-cutout` сразу отвечает `null` (в Node на телефоне модуль вырезки отсутствовал, команда падала с ошибкой).
* `logo`/`palette`/клипы/микшер громкости интерфейс и раньше выполнял сам (bridge.js) — на сервере они заглушки,
  как и были.
