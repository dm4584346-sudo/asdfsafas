//! Yandex Music: import by link, the account (likes, playlists, «Моя волна», stats, lyrics), the landing pages of the
//! new web client, artist pages, podcasts / books, and the stream of the account (Plus) as a last resort.

use super::extras::{first_sentence_cut, name_key};
use super::ymfile;
use crate::http::{get_json, get_text, Opts};
use crate::js::{enc, jn, now_ms, qs, shuffle, slice, spread, J, E, R};
use crate::re;
use base64::Engine;
use futures_util::future::join_all;
use hmac::{Hmac, Mac};
use md5::{Digest, Md5};
use serde_json::{json, Map, Value};
use sha2::Sha256;
use std::collections::HashSet;
use std::sync::Mutex;

const API: &str = "https://api.music.yandex.net";
const H: [(&str, &str); 2] = [("X-Yandex-Music-Client", "YandexMusicAndroid/24023621"), ("Accept-Language", "ru")];
const WEB_H: [(&str, &str); 4] = [
    ("X-Yandex-Music-Client", "YandexMusicWebNext/1.0.0"),
    ("Origin", "https://music.yandex.ru"),
    ("Referer", "https://music.yandex.ru/"),
    ("Accept-Language", "ru"),
];

static TOKEN: Mutex<Option<String>> = Mutex::new(None);
static ME: Mutex<Value> = Mutex::new(Value::Null);

pub fn set_token(t: Option<&str>) {
    *TOKEN.lock().unwrap() = t.filter(|t| re!(r"^[A-Za-z0-9_\-.]{20,200}$").is_match(t)).map(String::from);
    *ME.lock().unwrap() = Value::Null;
}
pub fn token() -> Option<String> {
    TOKEN.lock().unwrap().clone()
}
pub fn has_token() -> bool {
    TOKEN.lock().unwrap().is_some()
}
pub fn me() -> Value {
    ME.lock().unwrap().clone()
}

/* ---------- helpers ---------- */
fn hex6(s: &str) -> bool {
    re!(r"(?i)^#[0-9a-f]{6}$").is_match(s)
}
pub fn cover(uri: &Value) -> Value {
    match uri.as_str() {
        Some(s) if !s.is_empty() => {
            json!(format!("https://{}", re!(r"^(https?:)?//").replacen(s, 1, "").replacen("%%", "400x400", 1)))
        }
        _ => Value::Null,
    }
}
fn big(uri: &Value, size: &str) -> Value {
    if !uri.truthy() {
        return Value::Null;
    }
    json!(format!("https://{}", re!(r"^(https?:)?//").replacen(&uri.sv(), 1, "").replacen("%%", size, 1)))
}
fn sized(uri: &str, size: &str) -> String {
    format!("https://{}", re!(r"^(https?:)?//").replacen(uri, 1, "").replacen("%%", size, 1))
}
pub fn colors_of(dc: &Value) -> Option<Value> {
    if !dc.truthy() || !hex6(&dc.g("average").s()) {
        return None;
    }
    let mut o = Map::new();
    for k in ["average", "waveText", "miniPlayer", "accent"] {
        let v = dc.g(k).s();
        if hex6(&v) {
            o.insert(k.into(), json!(v));
        }
    }
    Some(Value::Object(o))
}
fn digits(v: &Value) -> String {
    v.sv().chars().filter(|c| c.is_ascii_digit()).collect()
}
fn num(v: &Value) -> Option<String> {
    let s = v.sv();
    if re!(r"^\d{1,15}$").is_match(&s) {
        Some(s)
    } else {
        None
    }
}
fn uri_of(c: &Value) -> Value {
    if c.is_string() {
        return c.clone();
    }
    if c.g("uri").truthy() {
        return c.g("uri").clone();
    }
    let i = c.path(&["itemsUri", "0"]);
    if i.truthy() {
        i.clone()
    } else {
        Value::Null
    }
}
fn first_of<'a>(vals: &[&'a Value]) -> &'a Value {
    vals.iter().find(|v| v.truthy()).copied().unwrap_or(&crate::js::NULL)
}
pub fn pod_kind(a: &Value) -> Option<&'static str> {
    let v: Vec<String> = ["type", "metaType", "albumType"].iter().map(|k| a.g(k).s().to_lowercase()).collect();
    if v.iter().any(|x| x == "podcast") {
        return Some("podcast");
    }
    if v.iter().any(|x| re!(r"audiobook|fairy.?tale|book").is_match(x)) {
        return Some("book");
    }
    None
}
fn is_pod(t: &Value) -> bool {
    let ty = t.g("type").s().to_lowercase();
    (!ty.is_empty() && ty != "music") || pod_kind(t.path(&["albums", "0"])).is_some()
}
fn date_of(v: &Value) -> Option<String> {
    re!(r"^(\d{4})-(\d{2})-(\d{2})").captures(&v.s()).map(|m| format!("{}-{}-{}", &m[1], &m[2], &m[3]))
}
fn labels_of(a: &Value) -> Value {
    let list: Vec<String> = a
        .g("labels")
        .arr()
        .iter()
        .map(|l| if l.is_string() { l.sv() } else { l.g("name").s() }.trim().to_string())
        .filter(|s| !s.is_empty())
        .collect();
    json!(crate::js::uniq_strings(list).into_iter().take(4).map(|x| slice(&x, 80)).collect::<Vec<_>>())
}
fn kind_name(k: Option<&str>) -> Option<&'static str> {
    match k {
        Some("podcast") => Some("Подкаст"),
        Some("book") => Some("Аудиокнига"),
        _ => None,
    }
}

pub fn track(t: &Value) -> Option<Value> {
    if !t.truthy() || !t.g("id").truthy() || !t.g("title").truthy() {
        return None;
    }
    let title = if t.g("version").truthy() {
        format!("{} ({})", t.g("title").sv(), t.g("version").sv())
    } else {
        t.g("title").sv()
    };
    let arts = t.g("artists").arr();
    let names = arts.iter().map(|a| a.g("name").s()).collect::<Vec<_>>().join(", ");
    let al = t.path(&["albums", "0"]);
    let mut o = Map::new();
    o.insert("id".into(), json!(format!("ym:{}", digits(t.g("id")))));
    o.insert("source".into(), json!("yandex"));
    o.insert("title".into(), json!(title));
    o.insert("artist".into(), json!(if names.is_empty() { "Неизвестный исполнитель".to_string() } else { names }));
    o.insert(
        "artists".into(),
        Value::Array(
            arts.iter()
                .map(|a| {
                    let id = a.g("id").sv();
                    json!({
                        "id": if re!(r"^\d{1,15}$").is_match(&id) { json!(format!("yar:{}", id)) } else { Value::Null },
                        "name": a.g("name"),
                    })
                })
                .collect(),
        ),
    );
    o.insert("duration".into(), jn(crate::js::round(t.g("durationMs").n().max(0.0) / 1000.0)));
    o.insert(
        "cover".into(),
        cover(if t.g("coverUri").truthy() { t.g("coverUri") } else { al.g("coverUri") }),
    );
    o.insert(
        "link".into(),
        if al.g("id").truthy() {
            json!(format!("https://music.yandex.ru/album/{}/track/{}", al.g("id").sv(), t.g("id").sv()))
        } else {
            Value::Null
        },
    );
    o.insert("explicit".into(), json!(t.g("contentWarning").as_str() == Some("explicit")));
    if al.g("title").truthy() {
        o.insert("album".into(), json!(slice(&al.g("title").sv(), 200)));
    }
    o.insert("preview".into(), json!(false));
    o.insert("streamable".into(), json!(true));
    if let Some(c) = colors_of(t.g("derivedColors")) {
        o.insert("colors".into(), c);
    }
    let li = t.g("lyricsInfo");
    if li.truthy() {
        let l = if li.g("hasAvailableSyncLyrics").truthy() {
            2
        } else if li.g("hasAvailableTextLyrics").truthy() {
            1
        } else {
            0
        };
        o.insert("lyr".into(), json!(l));
    }
    if is_pod(t) {
        o.insert("pod".into(), json!(1));
    }
    Some(Value::Object(o))
}
fn tracks_of(list: &[Value]) -> Vec<Value> {
    list.iter().filter_map(track).collect()
}

/* ---------- requests ---------- */
#[derive(Default)]
struct Ao {
    auth: bool,
    timeout: Option<u64>,
    form: Option<String>,
    json: Option<String>,
}
fn auth() -> Ao {
    Ao { auth: true, ..Default::default() }
}
fn opt_auth() -> Ao {
    Ao { auth: has_token(), ..Default::default() }
}
impl Ao {
    fn t(mut self, ms: u64) -> Ao {
        self.timeout = Some(ms);
        self
    }
}

async fn api(path: &str, o: Ao) -> R<Value> {
    let mut op = Opts::new();
    for (k, v) in H {
        op = op.h(k, v);
    }
    if o.auth {
        if let Some(t) = token() {
            op = op.h("Authorization", &format!("OAuth {}", t));
        }
    }
    if let Some(f) = o.form {
        op = op.h("Content-Type", "application/x-www-form-urlencoded").post(f);
    } else if let Some(j) = o.json {
        op = op.h("Content-Type", "application/json").post(j);
    }
    op.timeout = o.timeout;
    let res = async {
        let r = get_json(&format!("{}{}", API, path), op).await?;
        if r.g("error").truthy() {
            let n = r.path(&["error", "name"]);
            return Err(E::new(if n.truthy() { n.sv() } else { "error".into() }).status(400));
        }
        Ok(r.g("result").clone())
    }
    .await;
    res.map_err(|e| {
        let legal = e.body.as_deref().filter(|b| !b.is_empty()).unwrap_or(&e.msg).contains("Legal");
        if e.status == Some(451) || legal {
            E::new("Яндекс Музыка недоступна из вашего региона (451). Попробуйте без VPN.")
        } else if e.status == Some(404) {
            E::new(if o.auth { "Не найдено в Яндекс Музыке" } else { "Плейлист не найден. Проверьте ссылку." })
        } else if e.status == Some(403) || e.status == Some(401) {
            E::new(if o.auth {
                "Яндекс не принял вход — войдите в аккаунт Яндекса заново (Настройки → Яндекс Музыка)"
            } else {
                "Плейлист закрыт. Сделайте его публичным в Яндекс Музыке."
            })
        } else {
            e
        }
    })
}

async fn web(path: &str, timeout: u64) -> R<Value> {
    let mut op = Opts::new().timeout(timeout);
    for (k, v) in WEB_H {
        op = op.h(k, v);
    }
    if let Some(t) = token() {
        op = op.h("Authorization", &format!("OAuth {}", t));
    }
    get_json(&format!("{}{}", API, path), op).await.map_err(|e| {
        if e.status == Some(451) || e.body.as_deref().unwrap_or("").contains("Legal") {
            E::new("Яндекс Музыка недоступна из вашего региона (451)").status(451)
        } else {
            e
        }
    })
}

fn form(pairs: &[(&str, &str)]) -> Ao {
    Ao { form: Some(qs(pairs)), ..Default::default() }
}

async fn fill(items: &[Value]) -> R<Vec<Value>> {
    let key = |x: &Value| if x.g("id").truthy() { x.g("id").sv() } else { x.g("trackId").sv() };
    let missing: Vec<String> = items.iter().filter(|x| !x.g("track").truthy()).map(key).filter(|s| !s.is_empty()).collect();
    let mut map = std::collections::HashMap::new();
    for ch in missing.chunks(200) {
        let r = api("/tracks", form(&[("track-ids", &ch.join(","))])).await?;
        for t in r.arr() {
            map.insert(t.g("id").sv(), t.clone());
        }
    }
    Ok(items
        .iter()
        .filter_map(|x| if x.g("track").truthy() { track(x.g("track")) } else { map.get(&key(x)).and_then(track) })
        .collect())
}

/* ---------- import by link ---------- */
enum Link {
    Playlist(String, String),
    Uuid(String),
    Track(String),
    Album(String),
    Artist(String),
}
fn parse_url(raw: &str) -> Option<Link> {
    let u = url::Url::parse(raw).ok()?;
    if !re!(r"^music\.yandex\.(ru|com|by|kz|uz)$").is_match(u.host_str()?) {
        return None;
    }
    let p = re!(r"/+$").replace(u.path(), "").into_owned();
    if let Some(m) = re!(r"^/users/([^/]+)/playlists/(\d+)$").captures(&p) {
        return Some(Link::Playlist(crate::js::dec(&m[1]), m[2].into()));
    }
    if let Some(m) = re!(r"^/playlists/([A-Za-z0-9.\-]+)$").captures(&p) {
        return Some(Link::Uuid(m[1].into()));
    }
    if let Some(m) = re!(r"^/album/(\d+)/track/(\d+)$").captures(&p) {
        return Some(Link::Track(m[2].into()));
    }
    if let Some(m) = re!(r"^/track/(\d+)$").captures(&p) {
        return Some(Link::Track(m[1].into()));
    }
    if let Some(m) = re!(r"^/album/(\d+)$").captures(&p) {
        return Some(Link::Album(m[1].into()));
    }
    if let Some(m) = re!(r"^/artist/(\d+)(/tracks)?$").captures(&p) {
        return Some(Link::Artist(m[1].into()));
    }
    None
}
fn pl_cover(p: &Value) -> Value {
    cover(first_of(&[p.path(&["cover", "uri"]), p.path(&["cover", "itemsUri", "0"]), p.g("ogImage"), p.g("coverUri")]))
}

pub async fn load(raw: &str) -> R<Value> {
    let r = parse_url(raw).ok_or_else(|| E::new("Не распознал ссылку Яндекс Музыки"))?;
    match r {
        Link::Playlist(owner, kind) => {
            let p = api(&format!("/users/{}/playlists/{}?rich-tracks=true", enc(&owner), kind), Ao::default()).await?;
            Ok(json!({ "title": p.g("title"), "cover": pl_cover(&p), "tracks": fill(p.g("tracks").arr()).await? }))
        }
        Link::Uuid(u) => {
            let p = api(&format!("/playlist/{}?rich-tracks=true", enc(&u)), Ao::default()).await?;
            Ok(json!({ "title": p.g("title"), "cover": pl_cover(&p), "tracks": fill(p.g("tracks").arr()).await? }))
        }
        Link::Album(id) => {
            let a = api(&format!("/albums/{}/with-tracks", id), Ao::default()).await?;
            let flat: Vec<Value> = a.g("volumes").arr().iter().flat_map(|v| v.arr().to_vec()).collect();
            Ok(json!({
                "title": format!("{} — {}", a.g("title").sv(), artists_of(&a)),
                "cover": cover(a.g("coverUri")),
                "tracks": tracks_of(&flat),
            }))
        }
        Link::Artist(id) => {
            let a = api(&format!("/artists/{}/tracks?page-size=100", id), Ao::default()).await?;
            Ok(json!({ "title": "Яндекс: исполнитель", "cover": null, "tracks": tracks_of(a.g("tracks").arr()) }))
        }
        Link::Track(id) => {
            let t = api(&format!("/tracks/{}", id), Ao::default()).await?;
            let title = t.at(0).g("title");
            Ok(json!({
                "title": if title.truthy() { title.clone() } else { json!("Трек") },
                "cover": null,
                "tracks": tracks_of(t.arr()),
            }))
        }
    }
}

/* ---------- cards ---------- */
fn artists_of(x: &Value) -> String {
    x.g("artists").arr().iter().map(|a| a.g("name").s()).filter(|s| !s.is_empty()).collect::<Vec<_>>().join(", ")
}
pub fn album_card(a: &Value) -> Option<Value> {
    if !a.truthy() || !a.g("id").truthy() || !a.g("title").truthy() {
        return None;
    }
    let pk = pod_kind(a);
    let mut o = Map::new();
    o.insert("id".into(), json!(format!("yma:{}", digits(a.g("id")))));
    o.insert("title".into(), a.g("title").clone());
    o.insert("owner".into(), json!(artists_of(a)));
    o.insert(
        "artists".into(),
        Value::Array(
            a.g("artists")
                .arr()
                .iter()
                .filter(|x| x.truthy() && x.g("name").truthy())
                .map(|x| {
                    let id = x.g("id").sv();
                    json!({ "id": if re!(r"^\d{1,15}$").is_match(&id) { json!(format!("yar:{}", id)) } else { Value::Null }, "name": x.g("name") })
                })
                .collect(),
        ),
    );
    o.insert("cover".into(), cover(a.g("coverUri")));
    o.insert("year".into(), if a.g("year").truthy() { a.g("year").clone() } else { Value::Null });
    o.insert("likes".into(), jn(nz(a.g("likesCount").n())));
    o.insert("count".into(), jn(nz(a.g("trackCount").n())));
    let ty = a.g("type").s();
    o.insert(
        "kind".into(),
        json!(kind_name(pk).unwrap_or(if ty == "single" {
            "Сингл"
        } else if ty == "compilation" {
            "Сборник"
        } else {
            "Альбом"
        })),
    );
    if let Some(d) = date_of(a.g("releaseDate")) {
        o.insert("date".into(), json!(d));
    }
    if let Some(p) = pk {
        o.insert("pod".into(), json!(p));
    }
    Some(Value::Object(o))
}
fn nz(f: f64) -> f64 {
    if f.is_nan() {
        0.0
    } else {
        f
    }
}
pub fn playlist_card(p: &Value) -> Option<Value> {
    if !p.truthy() || p.g("uid").is_null() || p.g("kind").is_null() || !p.g("title").truthy() {
        return None;
    }
    let ow = first_of(&[p.path(&["owner", "name"]), p.path(&["owner", "login"])]);
    Some(json!({
        "id": format!("ymp:{}-{}", digits(p.g("uid")), digits(p.g("kind"))),
        "title": p.g("title"),
        "owner": if ow.truthy() { ow.clone() } else { json!("Яндекс Музыка") },
        "cover": pl_cover(p),
        "likes": jn(nz(p.g("likesCount").n())),
        "count": jn(nz(p.g("trackCount").n())),
        "description": p.g("description").as_str().map(|s| slice(s, 300)).unwrap_or_default(),
    }))
}
fn chart_track(x: &Value) -> Option<Value> {
    let t = track(if x.g("track").truthy() { x.g("track") } else { x })?;
    let pos = x.path(&["chart", "position"]);
    let sh = x.path(&["chart", "shift"]);
    Some(spread(
        &t,
        &json!({ "chartPos": if pos.truthy() { pos.clone() } else { Value::Null }, "chartShift": if sh.truthy() { sh.clone() } else { json!(0) } }),
    ))
}

/* ---------- landing (public) ---------- */
async fn chart() -> R<Vec<Value>> {
    let r = api("/landing3/chart", Ao::default()).await?;
    Ok(r.path(&["chart", "tracks"]).arr().iter().filter_map(chart_track).take(100).collect())
}
async fn albums_by_ids(ids: &[String]) -> R<Vec<Value>> {
    let a = api("/albums", form(&[("album-ids", &ids.join(","))])).await?;
    Ok(a.arr().iter().filter_map(album_card).collect())
}
async fn playlists_by_ids(ids: &[String]) -> R<Vec<Value>> {
    let l = api("/playlists/list", form(&[("playlist-ids", &ids.join(","))])).await?;
    Ok(l.arr().iter().filter_map(playlist_card).collect())
}
async fn new_releases() -> R<Vec<Value>> {
    let r = api("/landing3/new-releases", Ao::default()).await?;
    let ids: Vec<String> = r.g("newReleases").arr().iter().take(20).map(|x| x.sv()).collect();
    if ids.is_empty() {
        return Ok(vec![]);
    }
    albums_by_ids(&ids).await
}
fn uid_kind(p: &Value) -> String {
    format!("{}:{}", p.g("uid").sv(), p.g("kind").sv())
}
async fn new_playlists() -> R<Vec<Value>> {
    let r = api("/landing3/new-playlists", Ao::default()).await?;
    let ids: Vec<String> = r.g("newPlaylists").arr().iter().take(20).map(uid_kind).collect();
    if ids.is_empty() {
        return Ok(vec![]);
    }
    playlists_by_ids(&ids).await
}
async fn via_web(uri: &str) -> R<Value> {
    let r = web(uri, 12000).await?;
    block_data(&Value::Null, &r).await
}
fn cards_of(b: &Value, kind: &str) -> R<Vec<Value>> {
    let l: Vec<Value> = b.g("items").arr().iter().filter(|x| x.g("kind").as_str() == Some(kind)).map(|x| x.g("card").clone()).collect();
    if l.is_empty() {
        return Err(E::new("пусто"));
    }
    Ok(l)
}
pub async fn landing() -> R<Value> {
    let (a, b, c) = tokio::join!(
        async {
            match via_web("/landing/block/chart?limit=100").await {
                Ok(b) if !b.g("tracks").arr().is_empty() => Ok(b.g("tracks").arr().to_vec()),
                _ => chart().await,
            }
        },
        async {
            match via_web("/landing-blocks/new-releases").await.and_then(|b| cards_of(&b, "album")) {
                Ok(l) => Ok(l),
                Err(_) => new_releases().await,
            }
        },
        async {
            match via_web("/landing-blocks/new-playlists").await.and_then(|b| cards_of(&b, "playlist")) {
                Ok(l) => Ok(l),
                Err(_) => new_playlists().await,
            }
        }
    );
    let mut out = Map::new();
    let mut errors = vec![];
    for (k, r) in [("chart", a), ("releases", b), ("playlists", c)] {
        match r {
            Ok(v) => {
                out.insert(k.into(), Value::Array(v));
            }
            Err(e) => {
                out.insert(k.into(), json!([]));
                errors.push(e.msg);
            }
        }
    }
    out.insert("errors".into(), json!(crate::js::uniq_strings(errors)));
    Ok(Value::Object(out))
}

pub async fn remote(id: &str) -> R<Value> {
    if let Some(m) = re!(r"^yma:(\d{1,15})$").captures(id) {
        let a = api(&format!("/albums/{}/with-tracks", &m[1]), Ao::default()).await?;
        let card = album_card(&a).unwrap_or(json!({ "id": id, "title": "Альбом" }));
        let best = a.path(&["bests", "0"]).s();
        let artists: Vec<Value> = a
            .g("artists")
            .arr()
            .iter()
            .filter(|x| num(x.g("id")).is_some() && x.g("name").truthy())
            .take(6)
            .map(|x| {
                let c = uri_of(x.g("cover"));
                json!({
                    "id": format!("yar:{}", x.g("id").sv()),
                    "name": slice(&x.g("name").sv(), 150),
                    "cover": cover(if c.truthy() { &c } else { x.g("ogImage") }),
                })
            })
            .collect();
        let kind = if card.g("kind").truthy() { card.g("kind").clone() } else { json!("Альбом") };
        let pl = spread(
            &card,
            &json!({
                "kind": kind,
                "artistIds": a.g("artists").arr().iter().map(|x| json!(format!("yar:{}", x.g("id").sv()))).collect::<Vec<_>>(),
                "artists": artists,
                "labels": labels_of(&a),
                "releaseDate": date_of(a.g("releaseDate")),
            }),
        );
        let flat: Vec<Value> = a.g("volumes").arr().iter().flat_map(|v| v.arr().to_vec()).collect();
        let tracks: Vec<Value> = tracks_of(&flat)
            .into_iter()
            .map(|t| if !best.is_empty() && t.g("id").s() == format!("ym:{}", best) { spread(&t, &json!({ "hot": true })) } else { t })
            .collect();
        return Ok(json!({ "playlist": pl, "tracks": tracks }));
    }
    if let Some(m) = re!(r"^ymp:(\d{1,15})-(\d{1,10})$").captures(id) {
        let p = api(&format!("/users/{}/playlists/{}?rich-tracks=true", &m[1], &m[2]), Ao::default()).await?;
        let c = playlist_card(&p).unwrap_or(json!({ "id": id, "title": "Плейлист" }));
        return Ok(json!({
            "playlist": spread(&c, &json!({ "kind": "Плейлист Яндекс Музыки" })),
            "tracks": fill(p.g("tracks").arr()).await?,
        }));
    }
    Err(E::new("Неизвестный плейлист Яндекс Музыки"))
}

/* ---------- lyrics (needs the user's token) ---------- */
fn low(s: &str) -> String {
    super::extras::norm_words(s)
}
fn hmac_b64(msg: &str) -> String {
    let mut mac = Hmac::<Sha256>::new_from_slice(ymfile::SIGN_KEY.as_bytes()).unwrap();
    mac.update(msg.as_bytes());
    base64::engine::general_purpose::STANDARD.encode(mac.finalize().into_bytes())
}

/// { synced, text } — LRC when Yandex has a synced text, otherwise its plain text
pub async fn lyrics_any(t: &Value, via: &Value) -> R<Value> {
    if !has_token() {
        return Ok(Value::Null);
    }
    let tid = t.g("id").sv();
    let mut id = tid.strip_prefix("ym:").map(String::from);
    let mut info: Option<(bool, bool)> = if id.is_some() && !t.g("lyr").is_null() {
        let l = t.g("lyr").n();
        Some((l == 2.0, l >= 1.0))
    } else {
        None
    };
    if id.is_none() {
        let src = if via.truthy() && !via.g("id").sv().starts_with("sc:") { via } else { t };
        let sa = src.g("artist").s();
        let first = sa.split(',').next().unwrap_or("").to_string();
        let q = slice(&format!("{} {}", first, src.g("title").s()), 150);
        let r = api(&format!("/search?{}", qs(&[("text", &q), ("type", "track"), ("page", "0")])), auth().t(8000)).await?;
        let art = low(&first);
        let st = low(&src.g("title").s());
        let list: Vec<&Value> = r
            .path(&["tracks", "results"])
            .arr()
            .iter()
            .filter(|x| {
                let a = low(&x.g("title").s());
                !a.is_empty() && !st.is_empty() && (st.contains(&a) || a.contains(&st))
            })
            .collect();
        let hit = list
            .iter()
            .find(|x| {
                !art.is_empty()
                    && x.g("artists").arr().iter().any(|y| {
                        let n = low(&y.g("name").s());
                        !n.is_empty() && (art.contains(&n) || n.contains(&art))
                    })
            })
            .or(list.first())
            .copied();
        let Some(hit) = hit else { return Ok(Value::Null) };
        id = Some(hit.g("id").sv());
        let li = hit.g("lyricsInfo");
        if li.truthy() {
            info = Some((li.g("hasAvailableSyncLyrics").truthy(), li.g("hasAvailableTextLyrics").truthy()));
        }
    }
    let id = id.unwrap_or_default();
    if !re!(r"^\d{1,15}$").is_match(&id) {
        return Ok(Value::Null);
    }
    if let Some((s, t)) = info {
        if !s && !t {
            return Ok(Value::Null);
        }
    }
    let get = |format: &'static str| {
        let id = id.clone();
        async move {
            let ts = ((now_ms() / 1000.0).floor() as i64).to_string();
            let sign = hmac_b64(&format!("{}{}", id, ts));
            let r = api(
                &format!("/tracks/{}/lyrics?{}", id, qs(&[("format", format), ("timeStamp", &ts), ("sign", &sign)])),
                auth().t(8000),
            )
            .await?;
            let u = r.g("downloadUrl").s();
            if !u.starts_with("https://") {
                return Ok::<Option<String>, E>(None);
            }
            Ok(Some(get_text(&u, Some(8000)).await?))
        }
    };
    if info.map(|i| i.0).unwrap_or(true) {
        let lrc = match get("LRC").await {
            Ok(x) => x,
            Err(e) => {
                if info.is_some() {
                    return Err(e);
                }
                None
            }
        };
        if let Some(l) = lrc.filter(|l| !l.is_empty()) {
            return Ok(json!({ "synced": true, "text": l }));
        }
    }
    if info.map(|i| i.1).unwrap_or(true) {
        if let Ok(Some(txt)) = get("TEXT").await {
            if !txt.trim().is_empty() {
                return Ok(json!({ "synced": false, "text": txt }));
            }
        }
    }
    Ok(Value::Null)
}

/* ---------- streams of the account ---------- */
const DL_SALT: &str = "XGRlBW9FXlekgbPrRHuSiA";

pub async fn search(text: &str, limit: usize) -> R<Vec<Value>> {
    let q = slice(text.trim(), 150);
    if q.is_empty() {
        return Ok(vec![]);
    }
    let r = api(&format!("/search?{}", qs(&[("text", &q), ("type", "track"), ("page", "0")])), opt_auth().t(8000)).await?;
    Ok(r.path(&["tracks", "results"])
        .arr()
        .iter()
        .filter(|x| x.truthy() && x.g("available") != &Value::Bool(false))
        .filter_map(track)
        .take(limit)
        .collect())
}

async fn file_info(tid: &str, quality: &str) -> R<Value> {
    let r = api(&format!("/get-file-info?{}", ymfile::signed_query(tid, quality)), auth().t(10000)).await?;
    let f = ymfile::parse_info(&r).ok_or_else(|| E::new("Яндекс не отдал файл в этом качестве"))?;
    let mut q = Map::new();
    q.insert("codec".into(), json!(f.label));
    q.insert("kbps".into(), f.kbps.clone());
    q.insert("src".into(), json!("Яндекс Музыка"));
    if f.lossless {
        q.insert("lossless".into(), json!(true));
    }
    let mut o = Map::new();
    o.insert("url".into(), json!(f.url));
    o.insert("type".into(), json!("file"));
    o.insert("preview".into(), json!(false));
    o.insert("q".into(), Value::Object(q));
    o.insert("yandex".into(), json!(true));
    if let Some(k) = f.key {
        o.insert("enc".into(), json!({ "key": k, "mime": f.mime }));
    }
    Ok(Value::Object(o))
}

/// quality: «lossless» (FLAC when the track has it), «hq» (MP3 320), «nq» (≈192)
pub async fn stream(id: &str, quality: &str) -> R<Value> {
    if !has_token() {
        return Err(E::new("Для звука из Яндекс Музыки нужен вход в аккаунт"));
    }
    let tid = id.strip_prefix("ym:").unwrap_or(id).to_string();
    if !re!(r"^\d{1,15}$").is_match(&tid) {
        return Err(E::new("Неверный id Яндекс Музыки"));
    }
    let mut loss_err = None;
    if quality == "lossless" {
        match file_info(&tid, "lossless").await {
            Ok(v) => return Ok(v),
            Err(e) => loss_err = Some(e.msg),
        }
    }
    let list = api(&format!("/tracks/{}/download-info", tid), auth().t(10000)).await?;
    let mut full: Vec<Value> = list
        .arr()
        .iter()
        .filter(|x| {
            x.truthy()
                && !x.g("preview").truthy()
                && x.g("downloadInfoUrl").s().starts_with("https://")
                && re!(r"^(mp3|aac)$").is_match(&x.g("codec").sv())
        })
        .cloned()
        .collect();
    if full.is_empty() {
        let mut e = E::new("Яндекс отдаёт только 30-секундный фрагмент — нужна подписка Плюс");
        e.preview = true;
        return Err(e);
    }
    let br = |x: &Value| nz(x.g("bitrateInKbps").n());
    full.sort_by(|a, b| {
        let ma = (a.g("codec").as_str() == Some("mp3")) as i32;
        let mb = (b.g("codec").as_str() == Some("mp3")) as i32;
        mb.cmp(&ma).then(br(b).partial_cmp(&br(a)).unwrap_or(std::cmp::Ordering::Equal))
    });
    let mut best = full[0].clone();
    if quality == "nq" {
        let mut mp3: Vec<&Value> =
            full.iter().filter(|x| x.g("codec").as_str() == Some("mp3") && br(x) >= 128.0).collect();
        mp3.sort_by(|a, b| br(a).partial_cmp(&br(b)).unwrap_or(std::cmp::Ordering::Equal));
        if let Some(x) = mp3.first() {
            best = (*x).clone();
        }
    }
    let mut op = Opts::new().timeout(10000);
    for (k, v) in H {
        op = op.h(k, v);
    }
    op = op.h("Authorization", &format!("OAuth {}", token().unwrap_or_default()));
    let (st, _, xml) = crate::http::text(&best.g("downloadInfoUrl").s(), op).await?;
    if !(200..300).contains(&st) {
        return Err(E::new(format!("Яндекс: HTTP {}", st)));
    }
    let tag = |k: &str| -> String {
        regex::Regex::new(&format!("<{k}>([^<]{{1,500}})</{k}>"))
            .ok()
            .and_then(|r| r.captures(&xml).map(|m| m[1].to_string()))
            .unwrap_or_default()
    };
    let (host, p, ts, sg) = (tag("host"), tag("path"), tag("ts"), tag("s"));
    if !re!(r"(?i)^[a-z0-9.-]{3,120}$").is_match(&host) || !p.starts_with('/') || ts.is_empty() || sg.is_empty() {
        return Err(E::new("Яндекс не отдал ссылку на поток"));
    }
    let sign = hex::encode(Md5::digest(format!("{}{}{}", DL_SALT, &p[1..], sg).as_bytes()));
    let codec = best.g("codec").sv();
    let kb = best.g("bitrateInKbps");
    let mut o = Map::new();
    o.insert("url".into(), json!(format!("https://{}/get-{}/{}/{}{}", host, codec, sign, ts, p)));
    o.insert("type".into(), json!("file"));
    o.insert("preview".into(), json!(false));
    o.insert(
        "q".into(),
        json!({ "codec": codec.to_uppercase(), "kbps": if kb.truthy() { kb.clone() } else { Value::Null }, "src": "Яндекс Музыка" }),
    );
    o.insert("yandex".into(), json!(true));
    if let Some(l) = loss_err {
        o.insert("lossErr".into(), json!(l));
    }
    Ok(Value::Object(o))
}

/// a fresh link + key of the same file format (the old link expired)
pub async fn renew_enc(id: &str, quality: &str, mime: &str) -> R<Option<(String, String)>> {
    let n = stream(id, quality).await?;
    crate::app::blog(&format!("yandex stream {}: link renewed", id));
    let e = n.g("enc");
    if e.truthy() && e.g("mime").as_str() == Some(mime) {
        return Ok(Some((n.g("url").s(), e.g("key").s())));
    }
    Ok(None)
}

/* ---------- the account ---------- */
const OAUTH_CLIENT: &str = "23cabbbdc6cd418abb4b39c32c41195d";
pub fn oauth_url() -> String {
    format!("https://oauth.yandex.ru/authorize?{}", qs(&[("response_type", "token"), ("client_id", OAUTH_CLIENT)]))
}
pub fn token_from_url(raw: &str) -> Option<String> {
    let u = url::Url::parse(raw).ok()?;
    let src = match u.fragment() {
        Some(f) if !f.is_empty() => f.to_string(),
        _ => u.query().unwrap_or("").to_string(),
    };
    let t = url::form_urlencoded::parse(src.as_bytes()).find(|(k, _)| k == "access_token").map(|(_, v)| v.into_owned())?;
    if re!(r"^[A-Za-z0-9_\-.]{20,200}$").is_match(&t) {
        Some(t)
    } else {
        None
    }
}
pub async fn account() -> R<Value> {
    if !has_token() {
        return Ok(Value::Null);
    }
    let r = api("/account/status", auth().t(10000)).await?;
    let a = r.g("account");
    if !a.g("uid").truthy() {
        return Err(E::new("Яндекс не вернул аккаунт — войдите заново"));
    }
    let name = first_of(&[a.g("displayName"), a.g("fullName"), a.g("login")]);
    let hp = r.path(&["plus", "hasPlus"]);
    let me = json!({
        "uid": a.g("uid").sv(),
        "login": a.g("login").s(),
        "name": if name.truthy() { name.clone() } else { json!("Яндекс") },
        "plus": if hp.is_boolean() { hp.clone() } else { Value::Null },
    });
    *ME.lock().unwrap() = me.clone();
    Ok(me)
}
async fn uid() -> R<String> {
    let m = me();
    if m.g("uid").truthy() {
        return Ok(m.g("uid").s());
    }
    Ok(account().await?.g("uid").sv_or_undef())
}
trait Undef {
    fn sv_or_undef(&self) -> String;
}
impl Undef for Value {
    fn sv_or_undef(&self) -> String {
        if self.is_null() {
            "undefined".into()
        } else {
            self.sv()
        }
    }
}
pub async fn liked_tracks() -> R<Vec<Value>> {
    let u = uid().await?;
    let r = api(&format!("/users/{}/likes/tracks", u), auth().t(20000)).await?;
    let items: Vec<Value> = r.path(&["library", "tracks"]).arr().iter().map(|x| json!({ "id": x.g("id") })).collect();
    fill(&items).await
}
pub async fn liked_ids() -> R<(Option<f64>, Vec<String>)> {
    let u = uid().await?;
    let r = api(&format!("/users/{}/likes/tracks", u), auth().t(20000)).await?;
    let lib = r.g("library");
    let rev = lib.g("revision").n();
    let ids = lib
        .g("tracks")
        .arr()
        .iter()
        .map(|x| x.g("id").s())
        .filter(|x| re!(r"^\d{1,15}$").is_match(x))
        .collect();
    Ok((if rev.is_finite() && !lib.g("revision").is_null() { Some(rev) } else { None }, ids))
}
pub async fn tracks_by_ids(ids: &[String]) -> R<Vec<Value>> {
    let items: Vec<Value> = ids.iter().map(|i| json!({ "id": i })).collect();
    fill(&items).await
}
pub async fn my_playlists() -> R<Vec<Value>> {
    let u = uid().await?;
    let l = api(&format!("/users/{}/playlists/list", u), auth().t(15000)).await?;
    Ok(l.arr().iter().filter_map(playlist_card).collect())
}
pub async fn playlist_tracks(id: &str) -> R<Value> {
    let m = re!(r"^ymp:(\d{1,15})-(\d{1,10})$").captures(id).ok_or_else(|| E::new("Неизвестный плейлист Яндекс Музыки"))?;
    let p = api(&format!("/users/{}/playlists/{}?rich-tracks=true", &m[1], &m[2]), auth().t(20000)).await?;
    Ok(json!({ "playlist": playlist_card(&p), "tracks": fill(p.g("tracks").arr()).await? }))
}

/* ---------- «Моя волна» (rotor) ---------- */
fn station_ok(s: &str) -> bool {
    re!(r"^(user|genre|mood|activity|epoch|track|artist|album|playlist|local|personal):[A-Za-z0-9_\-.:]{1,80}$").is_match(s)
}
fn seed_ok(s: &str) -> bool {
    re!(r"^[A-Za-z][A-Za-z0-9_-]{0,30}:[A-Za-z0-9_\-.:]{1,80}$").is_match(s)
}
fn seeds_of(s: &str) -> Option<Vec<String>> {
    let list: Vec<String> = s.split(',').map(|x| x.trim().to_string()).filter(|x| !x.is_empty()).collect();
    if !list.is_empty() && list.len() <= 8 && list.iter().all(|x| seed_ok(x)) {
        Some(list)
    } else {
        None
    }
}
struct Rs {
    key: String,
    id: String,
    at: f64,
}
static RS: Mutex<Option<Rs>> = Mutex::new(None);

pub async fn rotor(mood: &str, diversity: &str, seed: &Value, want: Option<&str>, recent: &[String]) -> R<Vec<Value>> {
    let mut station = "user:onyourwave".to_string();
    let sid = seed.g("id").s();
    let many = want.and_then(seeds_of);
    if let Some(m) = &many {
        station = m.join(",");
    } else if let Some(s) = sid.strip_prefix("ym:") {
        station = format!("track:{}", s);
    } else if mood == "rap" {
        station = "genre:rap".into();
    } else if mood == "rock" {
        station = "genre:rock".into();
    } else if mood == "wakeup" {
        station = "activity:wake-up".into();
    } else if mood == "sleep" {
        station = "activity:fall-asleep".into();
    }
    let mut seeds: Vec<String> = if station.contains(',') { seeds_of(&station).unwrap_or_default() } else { vec![station.clone()] };
    if station == "user:onyourwave" {
        let m = match mood {
            "energetic" => Some("active"),
            "calm" => Some("calm"),
            "sad" => Some("sad"),
            "fun" => Some("fun"),
            _ => None,
        };
        if let Some(m) = m {
            seeds.push(format!("settingMoodEnergy:{}", m));
        }
        if !diversity.is_empty() && diversity != "default" {
            seeds.push(format!("settingDiversity:{}", diversity));
        }
    }
    let from_seq = |r: &Value| -> Vec<Value> {
        r.g("sequence").arr().iter().filter_map(|x| track(if x.g("track").truthy() { x.g("track") } else { x })).collect()
    };
    let key = json!(seeds).to_string();
    let queue: Vec<String> = recent
        .iter()
        .map(|x| x.strip_prefix("ym:").unwrap_or(x).to_string())
        .filter(|x| re!(r"^\d{1,15}$").is_match(x))
        .take(30)
        .collect();
    let keep = |r: &Value| -> Vec<Value> {
        if r.g("radioSessionId").truthy() {
            *RS.lock().unwrap() = Some(Rs { key: key.clone(), id: r.g("radioSessionId").sv(), at: now_ms() });
        }
        from_seq(r)
    };
    let jbody = |b: Value| Ao { auth: true, timeout: Some(12000), json: Some(b.to_string()), form: None };
    let cont = {
        let rs = RS.lock().unwrap();
        rs.as_ref().filter(|r| r.key == key && now_ms() - r.at < 3.0 * 3600e3).map(|r| r.id.clone())
    };
    if let Some(sid) = cont {
        match api(&format!("/rotor/session/{}/tracks", enc(&sid)), jbody(json!({ "queue": queue }))).await {
            Ok(r) => {
                let l = keep(&r);
                if !l.is_empty() {
                    return Ok(l);
                }
            }
            Err(_) => *RS.lock().unwrap() = None,
        }
    }
    if let Ok(r) = api("/rotor/session/new", jbody(json!({ "seeds": seeds, "includeTracksInResponse": true, "queue": queue }))).await {
        let l = keep(&r);
        if !l.is_empty() {
            return Ok(l);
        }
    }
    let get = |st: String| async move { api(&format!("/rotor/station/{}/tracks?settings2=true", st), auth().t(12000)).await };
    let one = seeds.iter().find(|x| station_ok(x)).cloned().unwrap_or_else(|| "user:onyourwave".into());
    let r = match get(one.clone()).await {
        Ok(r) => r,
        Err(e) => {
            if one == "user:onyourwave" {
                return Err(e);
            }
            get("user:onyourwave".into()).await?
        }
    };
    Ok(from_seq(&r))
}

/* ---------- the stations of the wheel ---------- */
const WHEEL_TYPES: [&str; 4] = ["activity", "mood", "genre", "epoch"];
fn ya_pic(s: &str) -> bool {
    re!(r"^(https?:)?//?avatars\.(mds\.)?yandex\.net/[^\s\x22'<>()]+$|^avatars\.(mds\.)?yandex\.net/[^\s\x22'<>()]+$").is_match(s)
}
fn agent_of(x: &Value, depth: u32) -> Option<String> {
    if !x.is_object() && !x.is_array() || depth > 3 {
        return None;
    }
    let vals: Vec<&Value> = match x {
        Value::Object(m) => m.values().collect(),
        Value::Array(a) => a.iter().collect(),
        _ => vec![],
    };
    for v in vals {
        if let Some(s) = v.as_str() {
            if re!(r"(?i)agent").is_match(s) && ya_pic(s) {
                return Some(s.to_string());
            }
        }
        if v.is_object() || v.is_array() {
            if let Some(r) = agent_of(v, depth + 1) {
                return Some(r);
            }
        }
    }
    None
}
fn station_card(x: &Value) -> Option<Value> {
    let s = if x.is_object() { if x.g("station").truthy() { x.g("station") } else { x } } else { return None };
    if !s.is_object() {
        return None;
    }
    let sid = s.g("id");
    let id = if sid.is_object() && sid.g("type").truthy() && sid.g("tag").truthy() {
        format!("{}:{}", sid.g("type").sv(), sid.g("tag").sv())
    } else if let Some(x) = sid.as_str() {
        x.to_string()
    } else {
        String::new()
    };
    if !station_ok(&id) || id == "user:onyourwave" {
        return None;
    }
    let title = first_of(&[s.g("name"), x.g("rupTitle")]).s().trim().to_string();
    if title.is_empty() {
        return None;
    }
    let ic = s.g("icon");
    let agent = agent_of(x, 0);
    let pic = [agent.clone(), ic.g("imageUrl").as_str().map(String::from), s.g("fullImageUrl").as_str().map(String::from)]
        .into_iter()
        .flatten()
        .find(|v| ya_pic(v));
    let col = ic.g("backgroundColor").s();
    Some(json!({
        "station": id,
        "type": id.split(':').next().unwrap_or(""),
        "title": slice(&title, 100),
        "img": pic.as_ref().map(|p| sized(p, "200x200")),
        "agent": agent.is_some() && pic == agent,
        "color": if hex6(&col) { json!(col) } else { Value::Null },
    }))
}
pub async fn wave_wheel() -> R<Vec<Value>> {
    let max = 12;
    let (dash, list) = tokio::join!(
        async { if has_token() { api("/rotor/stations/dashboard", auth().t(9000)).await } else { Ok(Value::Null) } },
        api("/rotor/stations/list?language=ru", opt_auth().t(12000))
    );
    if let (Err(e), Err(_)) = (&dash, &list) {
        return Err(e.clone());
    }
    let mut seen = HashSet::new();
    let mut out: Vec<Value> = vec![];
    let mut add = |c: Option<Value>, out: &mut Vec<Value>| {
        if let Some(c) = c {
            let st = c.g("station").s();
            if !seen.contains(&st) && out.len() < max {
                seen.insert(st);
                out.push(c);
            }
        }
    };
    if let Ok(d) = &dash {
        for x in d.g("stations").arr().iter().take(5) {
            add(station_card(x), &mut out);
        }
    }
    let all: Vec<Value> = list
        .as_ref()
        .map(|l| l.arr().iter().filter_map(station_card).filter(|c| WHEEL_TYPES.contains(&c.g("type").as_str().unwrap_or(""))).collect())
        .unwrap_or_default();
    let mut by: Vec<(&str, std::collections::VecDeque<Value>)> = WHEEL_TYPES
        .iter()
        .map(|t| {
            let mut v: Vec<Value> = all.iter().filter(|c| c.g("type").as_str() == Some(t)).cloned().collect();
            shuffle(&mut v);
            (*t, v.into())
        })
        .collect();
    let mut want = [3, 2, 6, 1];
    let mut round = 0;
    while out.len() < max && round < 8 {
        let mut any = false;
        for (i, (_, q)) in by.iter_mut().enumerate() {
            if want[i] <= 0 {
                continue;
            }
            let mut c = None;
            while let Some(x) = q.pop_front() {
                let st = x.g("station").s();
                if out.iter().any(|o| o.g("station").s() == st) {
                    continue;
                }
                c = Some(x);
                break;
            }
            let Some(c) = c else { continue };
            want[i] -= 1;
            add(Some(c), &mut out);
            any = true;
        }
        if !any {
            break;
        }
        round += 1;
    }
    Ok(out)
}

fn wheel_item(x: &Value) -> Option<Value> {
    if !x.is_object() {
        return None;
    }
    let d = if x.g("data").is_object() { x.g("data").clone() } else { json!({}) };
    let pic = |u: &Value, size: &str| -> Value {
        match u.as_str() {
            Some(s) if ya_pic(s) => json!(sized(s, size)),
            _ => Value::Null,
        }
    };
    let ty = x.g("type").s();
    if ty == "WAVE" {
        let w = d.g("wave");
        let seeds: Vec<String> = w.g("seeds").arr().iter().map(|v| v.sv()).filter(|v| seed_ok(v)).take(8).collect();
        let title = w.g("name").s().trim().to_string();
        let cv = d.path(&["agent", "cover"]);
        let img = pic(cv.g("uri"), "400x400");
        if x.g("style").s().starts_with("CONTROL") {
            return if seeds.iter().any(|v| v.starts_with("diversity:reshuffle")) && img.truthy() {
                Some(json!({ "control": "shake", "img": img }))
            } else {
                None
            };
        }
        if seeds.is_empty() || title.is_empty() {
            return None;
        }
        let col = cv.g("color").s();
        return Some(json!({
            "station": seeds.join(","),
            "type": seeds[0].split(':').next().unwrap_or(""),
            "title": slice(&title, 100),
            "img": img,
            "agent": img.truthy(),
            "color": if hex6(&col) { json!(col) } else { Value::Null },
        }));
    }
    if ty == "ALBUM" || ty == "NON_MUSIC" {
        let al = d.g("album");
        if !al.is_object() || num(al.g("id")).is_none() {
            return None;
        }
        let c = album_card(&spread(
            al,
            &json!({
                "coverUri": first_of(&[al.g("coverUri"), &uri_of(al.g("cover")), al.g("ogImage")]),
                "artists": first_of(&[al.g("artists"), d.g("artists")]),
                "type": first_of(&[al.g("type"), al.g("albumType"), al.g("metaType")]),
            }),
        ))?;
        let from = d.path(&["resumeFrom", "trackId"]);
        let from = num(from).filter(|_| d.g("resumeFrom").truthy()).map(|f| format!("ym:{}", f));
        let owner = c.g("owner").s();
        let title = if owner.is_empty() { c.g("title").sv() } else { format!("{} — {}", owner, c.g("title").sv()) };
        let sub = first_of(&[x.g("description"), d.g("description")]);
        let sub = if sub.truthy() { sub.sv() } else if ty == "NON_MUSIC" { "Продолжить".into() } else { "Новый релиз".into() };
        let mut o = Map::new();
        o.insert("kind".into(), json!("album"));
        o.insert("album".into(), c.g("id").clone());
        o.insert("type".into(), json!("album"));
        o.insert("title".into(), json!(slice(&title, 160)));
        o.insert("sub".into(), json!(slice(&sub, 60)));
        o.insert("img".into(), c.g("cover").clone());
        if let Some(f) = from {
            o.insert("from".into(), json!(f));
        }
        if c.g("pod").truthy() {
            o.insert("pod".into(), c.g("pod").clone());
        }
        return Some(Value::Object(o));
    }
    None
}

pub async fn wheel() -> R<Vec<Value>> {
    let mut op = Opts::new().timeout(10000).h("Content-Type", "application/json");
    for (k, v) in WEB_H {
        op = op.h(k, v);
    }
    if let Some(t) = token() {
        op = op.h("Authorization", &format!("OAuth {}", t));
    }
    let r = get_json(
        &format!("{}/wheel/new", API),
        op.post(json!({ "context": { "type": "EMPTY" }, "feedbacks": [] }).to_string()),
    )
    .await
    .map_err(|e| {
        if e.status == Some(451) || e.body.as_deref().unwrap_or("").contains("Legal") {
            E::new("Яндекс Музыка недоступна из вашего региона (451)").status(451)
        } else {
            e
        }
    })?;
    let res = if r.g("result").g("items").is_array() { r.g("result") } else { &r };
    let mut out = vec![];
    let mut seen = HashSet::new();
    for x in res.g("items").arr().iter().take(40) {
        let Some(it) = wheel_item(x) else { continue };
        let k = first_of(&[it.g("control"), it.g("station"), it.g("album")]).sv();
        if !seen.insert(k) {
            continue;
        }
        out.push(it);
    }
    out.truncate(20);
    Ok(out)
}

/* ---------- top artists of the month ---------- */
fn top_artists_of(r: &Value) -> Vec<Value> {
    let list = if r.g("artists").truthy() { r.g("artists") } else { r.g("items") };
    let mut out: Vec<Value> = vec![];
    for x in list.arr() {
        let Some(a) = artist_card(x.g("artist")) else { continue };
        if out.iter().any(|y| y.g("id") == a.g("id")) {
            continue;
        }
        let pos = x.path(&["top", "position"]).n();
        let mv = x.path(&["top", "progress"]).s().to_lowercase();
        let av = big(&pic_of(x.g("artist"), 0), "400x400");
        let mut o = a.as_object().unwrap().clone();
        o.insert("avatar".into(), if av.truthy() { av } else { a.g("avatar").clone() });
        o.insert("sec".into(), jn(crate::js::round(nz(x.g("listenTimeSeconds").n())).max(0.0)));
        if pos.fract() == 0.0 && pos > 0.0 && pos < 1000.0 {
            o.insert("pos".into(), jn(pos));
        }
        if ["up", "down", "same", "new"].contains(&mv.as_str()) {
            o.insert("progress".into(), json!(mv));
        }
        out.push(Value::Object(o));
        if out.len() >= 20 {
            break;
        }
    }
    out
}
pub async fn top_artists() -> R<Value> {
    if !has_token() {
        return Ok(Value::Null);
    }
    Ok(json!(top_artists_of(&api("/personal/top/artists/month", auth().t(10000)).await?)))
}

pub async fn artist_stats(id: &str, name: &str) -> R<Value> {
    let mut aid = if re!(r"^yar:\d{1,15}$").is_match(id) { Some(id[4..].to_string()) } else { None };
    if aid.is_none() && !name.is_empty() {
        let r = api(
            &format!("/search?{}", qs(&[("text", &slice(name, 100)), ("type", "artist"), ("page", "0")])),
            opt_auth().t(8000),
        )
        .await?;
        let list = r.path(&["artists", "results"]).arr();
        let hit = list.iter().find(|a| low(&a.g("name").s()) == low(name)).or(list.first());
        let Some(hit) = hit else { return Ok(Value::Null) };
        aid = Some(hit.g("id").sv());
    }
    let Some(aid) = aid else { return Ok(Value::Null) };
    let r = api(&format!("/artists/{}/brief-info", aid), opt_auth().t(8000)).await?;
    let a = r.g("artist");
    Ok(json!({
        "id": format!("yar:{}", aid),
        "name": if a.g("name").truthy() { a.g("name").clone() } else { json!(name) },
        "listeners": jn(nz(r.path(&["stats", "lastMonthListeners"]).n())),
        "likes": jn(nz(a.g("likesCount").n())),
        "cover": cover(first_of(&[a.path(&["cover", "uri"]), a.g("ogImage")])),
        "link": format!("https://music.yandex.ru/artist/{}", aid),
    }))
}

/* ---------- landing pages of the new web client ---------- */
fn pic_re(s: &str) -> bool {
    re!(r"^(https?://)?avatars\.yandex\.net/|%%").is_match(s)
}
fn pic_of(a: &Value, depth: u32) -> Value {
    if !a.is_object() || depth > 2 {
        return Value::Null;
    }
    for v in [uri_of(a.g("cover")), a.g("coverUri").clone(), uri_of(a.g("avatar")), a.g("ogImage").clone(), a.g("image").clone(), a.g("imageUrl").clone()] {
        if let Some(s) = v.as_str() {
            if pic_re(s) {
                return v;
            }
        }
    }
    if let Value::Object(m) = a {
        for v in m.values() {
            if let Some(s) = v.as_str() {
                if pic_re(s) && s.contains("avatars.yandex") {
                    return v.clone();
                }
            }
            if v.is_object() {
                let r = pic_of(v, depth + 1);
                if r.truthy() {
                    return r;
                }
            }
        }
    }
    Value::Null
}
pub fn artist_card(a: &Value) -> Option<Value> {
    if !a.truthy() || num(a.g("id")).is_none() || !a.g("name").truthy() {
        return None;
    }
    Some(json!({ "id": format!("yar:{}", a.g("id").sv()), "name": slice(&a.g("name").sv(), 150), "avatar": cover(&pic_of(a, 0)) }))
}
fn wave_card(w: &Value, d: &Value) -> Option<Value> {
    let st = if w.g("seeds").is_array() && w.g("seeds").at(0).is_string() {
        w.g("seeds").at(0).clone()
    } else {
        first_of(&[w.g("stationId"), w.g("id")]).clone()
    };
    let id = if let Some(s) = st.as_str() {
        s.to_string()
    } else if st.truthy() && st.g("type").truthy() && st.g("tag").truthy() {
        format!("{}:{}", st.g("type").sv(), st.g("tag").sv())
    } else {
        return None;
    };
    if id.is_empty() || !station_ok(&id) {
        return None;
    }
    let title = first_of(&[w.g("title"), w.g("name"), d.g("title"), w.path(&["station", "name"])]);
    if !title.truthy() {
        return None;
    }
    let col = first_of(&[
        w.path(&["compositeCover", "backgroundColor"]),
        w.g("backgroundColor"),
        w.path(&["icon", "backgroundColor"]),
        w.path(&["colors", "average"]),
    ])
    .s();
    Some(json!({
        "station": id,
        "title": slice(&title.sv(), 100),
        "cover": cover(first_of(&[&uri_of(w.g("cover")), &uri_of(w.g("compositeCover")), w.g("imageUrl"), w.path(&["icon", "imageUrl"])])),
        "color": if hex6(&col) { json!(col) } else { Value::Null },
    }))
}
fn card(x: &Value) -> Option<Value> {
    if !x.is_object() && !x.is_array() {
        return None;
    }
    let d = if x.g("data").is_object() { x.g("data") } else { x };
    let t = if d.g("track").truthy() {
        d.g("track")
    } else if !d.g("durationMs").is_null() && d.g("title").truthy() && !d.g("trackCount").truthy() {
        d
    } else {
        &crate::js::NULL
    };
    if t.is_object() {
        return track(t).map(|tr| json!({ "kind": "track", "track": tr }));
    }
    let cond = !d.g("trackCount").is_null() && !d.g("uid").truthy() && d.g("title").truthy() && !d.g("durationMs").truthy();
    let al = if d.g("album").truthy() {
        d.g("album")
    } else if d.g("albumType").truthy() || cond {
        d
    } else {
        &crate::js::NULL
    };
    if al.is_object() && num(al.g("id")).is_some() {
        let c = album_card(&spread(
            al,
            &json!({
                "coverUri": first_of(&[al.g("coverUri"), &uri_of(al.g("cover")), al.g("ogImage")]),
                "artists": first_of(&[al.g("artists"), d.g("artists")]),
                "type": first_of(&[al.g("type"), al.g("albumType")]),
            }),
        ))?;
        let colors = colors_of(first_of(&[al.path(&["cover", "derivedColors"]), al.g("derivedColors")]));
        let mut c = c;
        if let Some(cl) = colors {
            crate::js::set(&mut c, "colors", cl);
        }
        return Some(json!({ "kind": "album", "card": c }));
    }
    let pl = if d.g("playlist").truthy() {
        d.g("playlist")
    } else if !d.g("uid").is_null() && !d.g("kind").is_null() && d.g("title").truthy() {
        d
    } else {
        &crate::js::NULL
    };
    if pl.is_object() {
        let lc = if !pl.g("likesCount").is_null() { pl.g("likesCount").clone() } else { d.g("likesCount").clone() };
        return playlist_card(&spread(pl, &json!({ "likesCount": lc }))).map(|c| json!({ "kind": "playlist", "card": c }));
    }
    if d.g("artist").is_object() {
        return artist_card(d.g("artist")).map(|a| json!({ "kind": "artist", "artist": a }));
    }
    if d.g("wave").truthy() || d.g("station").truthy() || d.g("seeds").is_array() || d.g("stationId").truthy() {
        let w = first_of(&[d.g("wave"), d.g("station")]);
        let w = if w.truthy() { w } else { d };
        return wave_card(w, d).map(|w| json!({ "kind": "wave", "wave": w }));
    }
    let link = first_of(&[d.g("url"), d.g("weblink"), d.g("link")]).s();
    if let Some(m) = re!(r"/tags?/([A-Za-z0-9_\-]{1,60})").captures(&link) {
        if d.g("title").truthy() {
            let bg = d.g("backgroundColor").s();
            return Some(json!({
                "kind": "mix",
                "mix": {
                    "tag": &m[1],
                    "title": slice(&d.g("title").sv(), 100),
                    "cover": cover(first_of(&[d.g("backgroundImageUri"), &uri_of(d.g("cover")), d.g("coverWhite")])),
                    "color": if hex6(&bg) { json!(bg) } else { Value::Null },
                }
            }));
        }
    }
    if d.g("name").truthy() && num(d.g("id")).is_some() && (d.g("cover").truthy() || d.g("ogImage").truthy()) {
        return artist_card(d).map(|a| json!({ "kind": "artist", "artist": a }));
    }
    None
}
fn items_of(r: &Value, depth: u32) -> Vec<Value> {
    if (!r.is_object() && !r.is_array()) || depth > 3 {
        return vec![];
    }
    if let Value::Array(a) = r {
        return if a.iter().any(|x| card(x).is_some()) { a.clone() } else { vec![] };
    }
    for k in ["items", "entities", "tracks", "albums", "playlists", "artists", "waves", "stations"] {
        if let Value::Array(a) = r.g(k) {
            if a.iter().any(|x| card(x).is_some()) {
                return a.clone();
            }
        }
    }
    if let Value::Object(m) = r {
        for v in m.values() {
            let a = items_of(v, depth + 1);
            if !a.is_empty() {
                return a;
            }
        }
    }
    vec![]
}
fn artist_picks(r: &Value) -> Vec<Value> {
    let list = if r.g("albumBanners").is_array() { r.g("albumBanners").arr() } else { r.g("items").arr() };
    let mut out = vec![];
    for x in list.iter().take(24) {
        let al = x.g("album");
        if !al.is_object() || num(al.g("id")).is_none() {
            continue;
        }
        let src = if x.g("artists").is_array() && !x.g("artists").arr().is_empty() { x.g("artists").arr() } else { al.g("artists").arr() };
        let artists: Vec<Value> = src.iter().filter_map(artist_card).take(3).collect();
        let Some(c) = album_card(&spread(
            al,
            &json!({
                "coverUri": first_of(&[al.g("coverUri"), &uri_of(al.g("cover")), al.g("ogImage")]),
                "artists": first_of(&[al.g("artists"), x.g("artists")]),
                "type": first_of(&[al.g("type"), al.g("albumType")]),
            }),
        )) else {
            continue;
        };
        let photo = uri_of(x.g("cover"));
        let raw = if x.g("artists").is_array() && x.g("artists").at(0).truthy() { x.g("artists").at(0) } else { al.g("artists").at(0) };
        out.push(json!({
            "album": c,
            "artists": artists,
            "photo": if photo.as_str().map(ya_pic).unwrap_or(false) { big(&photo, "1000x1000") } else { Value::Null },
            "avatar": if raw.truthy() { big(&pic_of(raw, 0), "1000x1000") } else { Value::Null },
            "top": x.g("coverContentMode").as_str() == Some("TOP"),
            "explicit": al.g("contentWarning").as_str() == Some("explicit") || al.g("explicitDisclaimer").truthy(),
        }));
    }
    out
}
fn promo(s: &str) -> bool {
    re!(r"(?i)don(at|ation)|донат|поддерж(ите|ать)\s+(артист|музыкант|автор)|plus_promo|promo_banner").is_match(s)
}
async fn block_data(b: &Value, r: &Value) -> R<Value> {
    if !r.truthy() {
        return Ok(json!({ "items": [] }));
    }
    if re!(r"ARTIST_(RECOMMENDATIONS_PROMO|PICK)").is_match(&b.g("type").s()) || r.g("albumBanners").is_array() {
        let picks = artist_picks(r);
        if !picks.is_empty() {
            return Ok(json!({ "view": "artistpick", "picks": picks }));
        }
    }
    if r.g("chart").truthy() && r.path(&["chart", "tracks"]).is_array() {
        let tracks: Vec<Value> = r.path(&["chart", "tracks"]).arr().iter().filter_map(chart_track).take(100).collect();
        return Ok(json!({ "view": "chart", "tracks": tracks, "playlist": playlist_card(&spread(r.g("chart"), &json!({ "title": "Чарт" }))) }));
    }
    if r.g("tracks").is_array() && r.g("playlist").truthy() {
        let pc = playlist_card(r.g("playlist"));
        let pl = pc.map(|pc| {
            let c = cover(&uri_of(r.g("cover")));
            let c = if c.truthy() { c } else { pc.g("cover").clone() };
            spread(&pc, &json!({ "cover": c }))
        });
        let tracks: Vec<Value> = r
            .g("tracks")
            .arr()
            .iter()
            .filter_map(|x| track(if x.g("track").truthy() { x.g("track") } else { x }))
            .take(60)
            .collect();
        return Ok(json!({ "view": "playlist", "playlist": pl, "tracks": tracks }));
    }
    if !r.g("newReleases").arr().is_empty() {
        let ids: Vec<String> = r.g("newReleases").arr().iter().take(20).map(|x| x.sv()).collect();
        let a = api("/albums", form(&[("album-ids", &ids.join(","))])).await?;
        let items: Vec<Value> = a.arr().iter().filter_map(album_card).map(|c| json!({ "kind": "album", "card": c })).collect();
        return Ok(json!({ "view": "cards", "items": items }));
    }
    if !r.g("newPlaylists").arr().is_empty() {
        let ids: Vec<String> = r.g("newPlaylists").arr().iter().take(20).map(uid_kind).collect();
        let l = api("/playlists/list", form(&[("playlist-ids", &ids.join(","))])).await?;
        let items: Vec<Value> = l.arr().iter().filter_map(playlist_card).map(|c| json!({ "kind": "playlist", "card": c })).collect();
        return Ok(json!({ "view": "cards", "items": items }));
    }
    let items: Vec<Value> = items_of(r, 0)
        .iter()
        .filter(|x| {
            !promo(&first_of(&[x.g("type"), x.path(&["data", "type"])]).s())
                && !re!(r"(?i)донат").is_match(&first_of(&[x.g("title"), x.path(&["data", "title"])]).s())
        })
        .filter_map(card)
        .take(40)
        .collect();
    let tracks: Vec<Value> = items.iter().filter(|x| x.g("kind").as_str() == Some("track")).map(|x| x.g("track").clone()).collect();
    if !tracks.is_empty() && tracks.len() == items.len() {
        return Ok(json!({ "view": "tracks", "tracks": tracks }));
    }
    Ok(json!({ "view": "cards", "items": items.into_iter().filter(|x| x.g("kind").as_str() != Some("track")).collect::<Vec<_>>() }))
}
fn is_promo(b: &Value) -> bool {
    promo(&b.g("type").s()) || promo(&b.g("title").s()) || promo(&b.g("description").s())
}
const SKIP: [&str; 4] = ["DYNAMIC_BANNER", "NEUROMUSIC", "LIKES_AND_HISTORY", "HISTORY"];
fn uri_ok(s: &str) -> bool {
    re!(r"^/[A-Za-z0-9_\-/.]{1,200}(\?[A-Za-z0-9_\-=&%.]{0,200})?$").is_match(s)
}

pub async fn landing_page(id: &str) -> R<Value> {
    if !re!(r"^[A-Za-z_]{1,40}$").is_match(id) {
        return Err(E::new("Неизвестная страница"));
    }
    let sk = web(&format!("/landing/skeleton/{}", id), 12000).await?;
    // tabs: (id, title, blocks)
    let mut tabs: Vec<(String, String, Vec<Value>)> = vec![];
    let mut plain: Vec<Value> = vec![];
    let mut tabs_uri: Option<String> = None;
    fn walk(blocks: &[Value], tab: Option<usize>, tabs: &mut Vec<(String, String, Vec<Value>)>, plain: &mut Vec<Value>, tabs_uri: &mut Option<String>) {
        for b in blocks {
            if !b.is_object() {
                continue;
            }
            let su = b.path(&["data", "source", "uri"]).s();
            if b.g("type").as_str() == Some("TABS") && tabs_uri.is_none() && uri_ok(&su) {
                *tabs_uri = Some(su);
            }
            if b.g("type").as_str() == Some("TABS") {
                for t in b.path(&["data", "tabs"]).arr() {
                    tabs.push((slice(&t.g("id").s(), 40), slice(&t.g("title").s(), 60), vec![]));
                    let i = tabs.len() - 1;
                    walk(t.g("blocks").arr(), Some(i), tabs, plain, tabs_uri);
                }
            } else if let Some(i) = tab {
                tabs[i].2.push(b.clone());
            } else {
                plain.push(b.clone());
            }
        }
    }
    walk(sk.g("blocks").arr(), None, &mut tabs, &mut plain, &mut tabs_uri);
    if !plain.is_empty() {
        tabs.insert(0, ("main".into(), String::new(), plain));
    }
    let mut out: Vec<(Map<String, Value>, Vec<Map<String, Value>>)> = tabs
        .into_iter()
        .map(|(tid, title, blocks)| {
            let mut t = Map::new();
            t.insert("id".into(), json!(tid));
            t.insert("title".into(), json!(title));
            let bl: Vec<Map<String, Value>> = blocks
                .iter()
                .map(|b| {
                    let mut m = Map::new();
                    m.insert("id".into(), json!(slice(&b.g("id").s(), 80)));
                    m.insert("type".into(), json!(b.g("type").s()));
                    m.insert("title".into(), json!(slice(&b.path(&["data", "title"]).s(), 120)));
                    m.insert("description".into(), json!(slice(&b.path(&["data", "description"]).s(), 200)));
                    m.insert("uri".into(), b.path(&["data", "source", "uri"]).clone());
                    m
                })
                .filter(|b| {
                    let ty = b.get("type").map(|x| x.s()).unwrap_or_default();
                    b.get("title").map(|x| x.truthy()).unwrap_or(false) || ty == "LIKES_AND_HISTORY" || ty == "HISTORY"
                })
                .filter(|b| !is_promo(&Value::Object(b.clone())))
                .collect();
            (t, bl)
        })
        .collect();
    let meta = async {
        match &tabs_uri {
            Some(u) => web(u, 8000).await.ok(),
            None => None,
        }
    };
    let mut jobs = vec![];
    for (ti, (_, blocks)) in out.iter_mut().enumerate() {
        for (bi, b) in blocks.iter_mut().enumerate() {
            let ty = b.get("type").map(|x| x.s()).unwrap_or_default();
            let mut uri = b.get("uri").map(|x| x.s()).unwrap_or_default();
            if SKIP.contains(&ty.as_str()) || !uri_ok(&uri) {
                continue;
            }
            if ty == "CHART_TRACKS" && !uri.contains('?') {
                uri.push_str("?limit=100");
                b.insert("uri".into(), json!(uri));
            }
            let bv = Value::Object(b.clone());
            jobs.push(async move {
                let r = async { block_data(&bv, &web(&uri, 12000).await?).await }.await;
                (ti, bi, r)
            });
        }
    }
    let (meta, results) = tokio::join!(meta, join_all(jobs));
    let mut errors = vec![];
    for (ti, bi, r) in results {
        let b = &mut out[ti].1[bi];
        match r {
            Ok(Value::Object(m)) => {
                for (k, v) in m {
                    b.insert(k, v);
                }
            }
            Ok(_) => {}
            Err(e) => {
                b.insert("error".into(), json!(e.msg.clone()));
                errors.push(e.msg);
            }
        }
    }
    if let Some(r) = meta {
        for t in r.g("tabs").arr() {
            let tid = t.g("id").s();
            if let Some(tab) = out.iter_mut().find(|x| x.0.get("id").map(|v| v.s()) == Some(tid.clone())) {
                if let Some(s) = t.g("subtitle").as_str() {
                    if !s.trim().is_empty() {
                        tab.0.insert("subtitle".into(), json!(slice(s.trim(), 80)));
                    }
                }
                if let Some(cv) = t.g("covers").arr().iter().filter_map(|u| u.as_str()).find(|u| ya_pic(u)) {
                    tab.0.insert("cover".into(), big(&json!(cv), "400x400"));
                }
            }
        }
    }
    let tabs: Vec<Value> = out
        .into_iter()
        .map(|(mut t, blocks)| {
            let bl: Vec<Value> = blocks
                .into_iter()
                .filter(|b| {
                    let has = |k: &str| b.get(k).map(|v| !v.arr().is_empty()).unwrap_or(false);
                    has("tracks") || has("items") || has("picks") || SKIP.contains(&b.get("type").map(|x| x.s()).unwrap_or_default().as_str())
                })
                .map(|mut b| {
                    b.remove("uri");
                    Value::Object(b)
                })
                .collect();
            t.insert("blocks".into(), Value::Array(bl));
            Value::Object(t)
        })
        .collect();
    Ok(json!({
        "id": id,
        "title": sk.g("title").s(),
        "tabs": tabs,
        "errors": crate::js::uniq_strings(errors).into_iter().take(5).collect::<Vec<_>>(),
        "at": jn(now_ms()),
    }))
}

pub async fn tag_playlists(tag: &str) -> R<Value> {
    if !re!(r"^[A-Za-z0-9_\-]{1,60}$").is_match(tag) {
        return Err(E::new("Неизвестная подборка"));
    }
    let r = api(&format!("/tags/{}/playlist-ids", tag), Ao::default()).await?;
    let ids: Vec<String> = r.g("ids").arr().iter().take(40).map(uid_kind).collect();
    let list = if ids.is_empty() { vec![] } else { playlists_by_ids(&ids).await? };
    let n = r.path(&["tag", "name"]);
    Ok(json!({ "title": if n.truthy() { n.clone() } else { json!(tag) }, "playlists": list }))
}

pub async fn track_info(id: &str) -> R<Value> {
    let n = id.strip_prefix("ym:").unwrap_or(id);
    if !re!(r"^\d{1,15}$").is_match(n) {
        return Ok(Value::Null);
    }
    let (t, sim) = tokio::join!(
        async { api(&format!("/tracks/{}", n), opt_auth().t(8000)).await },
        async { api(&format!("/tracks/{}/similar", n), opt_auth().t(8000)).await }
    );
    let raw = t.as_ref().map(|v| v.at(0).clone()).unwrap_or(Value::Null);
    let al = raw.path(&["albums", "0"]);
    let album = if al.truthy() {
        json!({
            "id": format!("yma:{}", al.g("id").sv()),
            "title": al.g("title"),
            "cover": cover(al.g("coverUri")),
            "count": if al.g("trackCount").truthy() { al.g("trackCount").clone() } else { json!(0) },
            "year": if al.g("year").truthy() { al.g("year").clone() } else { Value::Null },
            "labels": labels_of(al),
            "releaseDate": date_of(al.g("releaseDate")),
        })
    } else {
        Value::Null
    };
    let similar: Vec<Value> = sim.map(|s| tracks_of(s.g("similarTracks").arr()).into_iter().take(12).collect()).unwrap_or_default();
    Ok(json!({ "album": album, "similar": similar }))
}

pub async fn find_artist(name: &str) -> R<Value> {
    let q = slice(name.trim(), 100);
    if q.is_empty() {
        return Ok(Value::Null);
    }
    let r = api(&format!("/search?{}", qs(&[("text", &q), ("type", "artist"), ("page", "0")])), opt_auth().t(8000)).await?;
    let a = r
        .path(&["artists", "results"])
        .arr()
        .iter()
        .find(|x| x.truthy() && num(x.g("id")).is_some() && name_key(&x.g("name").s()) == name_key(&q));
    Ok(match a {
        Some(a) => json!({
            "id": format!("yar:{}", a.g("id").sv()),
            "name": a.g("name"),
            "avatar": big(first_of(&[&uri_of(a.g("cover")), a.g("ogImage")]), "1000x1000"),
        }),
        None => Value::Null,
    })
}

pub fn first_sentence(text: &str, max: usize) -> String {
    let t = text.replace('\u{0301}', "");
    let t = re!(r"\s*\([^()]*\)").replace_all(&t, "");
    let mut t = re!(r"\s+").replace_all(&t, " ").trim().to_string();
    if t.is_empty() {
        return t;
    }
    if let Some(m) = first_sentence_cut(&t) {
        t = m;
    }
    if t.chars().count() > max {
        t = re!(r"[\s,;:–—-]+\S*$").replacen(&slice(&t, max - 1), 1, "").into_owned() + "…";
    }
    t
}

fn artist_info(a: &Value, r: &Value) -> Value {
    let pic = first_of(&[&uri_of(a.g("cover")), a.g("ogImage")]).clone();
    let desc = a.path(&["description", "text"]);
    json!({
        "id": format!("yar:{}", a.g("id").sv()),
        "source": "yandex",
        "name": slice(&a.g("name").s(), 150),
        "avatar": big(&pic, "400x400"),
        "banner": big(&pic, "1000x1000"),
        "followers": jn(nz(a.g("likesCount").n())),
        "tracks": jn(nz(a.path(&["counts", "tracks"]).n())),
        "listeners": jn(nz(r.path(&["stats", "lastMonthListeners"]).n())),
        "genres": a.g("genres").arr().iter().filter(|g| g.is_string()).take(3).cloned().collect::<Vec<_>>(),
        "description": desc.as_str().map(|s| slice(s, 2000)).unwrap_or_default(),
        "bio": first_sentence(&desc.s(), 160),
        "link": format!("https://music.yandex.ru/artist/{}", a.g("id").sv()),
    })
}

fn rel_time(a: &Value) -> f64 {
    if let Some(d) = date_of(a.g("releaseDate")) {
        if let Ok(nd) = chrono::NaiveDate::parse_from_str(&d, "%Y-%m-%d") {
            let ms = nd.and_hms_opt(0, 0, 0).unwrap().and_utc().timestamp_millis() as f64;
            if ms != 0.0 {
                return ms;
            }
        }
    }
    match num(a.g("year")) {
        Some(y) => chrono::NaiveDate::from_ymd_opt(y.parse().unwrap_or(1970), 1, 1)
            .map(|d| d.and_hms_opt(0, 0, 0).unwrap().and_utc().timestamp_millis() as f64)
            .unwrap_or(0.0),
        None => 0.0,
    }
}
fn release_of(r: &Value, albums: &[Value]) -> Value {
    let ok = |a: &Value| a.truthy() && a.g("id").truthy() && a.g("title").truthy() && pod_kind(a).is_none();
    let ids: HashSet<String> = r.g("lastReleaseIds").arr().iter().map(|x| x.sv()).collect();
    let mut named: Vec<Value> = r.g("lastReleases").arr().to_vec();
    named.extend(albums.iter().filter(|a| a.truthy() && ids.contains(&a.g("id").sv())).cloned());
    let named: Vec<Value> = named.into_iter().filter(|a| ok(a)).collect();
    let mut pool: Vec<Value> = if !named.is_empty() { named.clone() } else { albums.iter().filter(|a| ok(a)).cloned().collect() };
    pool.sort_by(|x, y| rel_time(y).partial_cmp(&rel_time(x)).unwrap_or(std::cmp::Ordering::Equal));
    let Some(a) = pool.first() else { return Value::Null };
    let Some(c) = album_card(a) else { return Value::Null };
    let y = num(a.g("year")).map(|y| jn(y.parse::<f64>().unwrap_or(0.0))).unwrap_or(Value::Null);
    spread(&c, &json!({ "year": y, "named": !named.is_empty(), "source": "yandex" }))
}
fn photos_of(r: &Value) -> Vec<Value> {
    let mut list = vec![first_of(&[&uri_of(r.path(&["artist", "cover"])), r.path(&["artist", "ogImage"])]).clone()];
    for c in r.g("allCovers").arr() {
        let u = uri_of(c);
        list.push(if u.truthy() { u } else { c.g("uri").clone() });
    }
    let urls: Vec<String> = list.iter().filter_map(|u| u.as_str()).filter(|u| pic_re(u)).map(|u| big(&json!(u), "1000x1000").s()).collect();
    crate::js::uniq_strings(urls).into_iter().take(40).map(Value::String).collect()
}

pub async fn artist_page(id: &str) -> R<Value> {
    let aid = num(&json!(id.strip_prefix("yar:").unwrap_or(id))).ok_or_else(|| E::new("Неверный id исполнителя Яндекс Музыки"))?;
    let (info, all, albums) = tokio::join!(
        async { api(&format!("/artists/{}/brief-info", aid), opt_auth().t(10000)).await },
        async { api(&format!("/artists/{}/tracks?page=0&page-size=50", aid), opt_auth().t(10000)).await },
        async { api(&format!("/artists/{}/direct-albums?page=0&page-size=30&sort-by=year", aid), opt_auth().t(10000)).await }
    );
    let r = match info {
        Ok(v) if v.g("artist").truthy() => v,
        Ok(_) => return Err(E::new("Исполнитель не найден")),
        Err(e) => return Err(e),
    };
    let top: Vec<Value> = tracks_of(r.g("popularTracks").arr()).into_iter().take(10).collect();
    let tracks = all.map(|a| tracks_of(a.g("tracks").arr())).unwrap_or_default();
    let al: Vec<Value> = match &albums {
        Ok(a) if !a.g("albums").arr().is_empty() => a.g("albums").arr().to_vec(),
        _ => r.g("albums").arr().to_vec(),
    };
    Ok(json!({
        "artist": artist_info(r.g("artist"), &r),
        "photos": photos_of(&r),
        "top": top.clone(),
        "tracks": if tracks.is_empty() { top } else { tracks },
        "albums": al.iter().filter_map(album_card).take(30).collect::<Vec<_>>(),
        "similar": r.g("similarArtists").arr().iter().filter_map(artist_card).take(20).collect::<Vec<_>>(),
        "release": release_of(&r, &al),
    }))
}

pub async fn artist_tracks(id: &str) -> R<Value> {
    let aid = num(&json!(id.strip_prefix("yar:").unwrap_or(id))).ok_or_else(|| E::new("Неверный id исполнителя Яндекс Музыки"))?;
    let page = |p: u32| {
        let aid = aid.clone();
        async move { api(&format!("/artists/{}/tracks?page={}&page-size=100", aid, p), opt_auth().t(15000)).await }
    };
    let (info, first) = tokio::join!(async { api(&format!("/artists/{}/brief-info", aid), opt_auth().t(15000)).await }, page(0));
    let info = info.ok();
    let first = first?;
    let mut raw: Vec<Value> = first.g("tracks").arr().to_vec();
    let pt = first.path(&["pager", "total"]).n();
    let total = (if pt.truthy_n() { pt } else { raw.len() as f64 }).min(500.0);
    let mut p = 1;
    while (raw.len() as f64) < total && p < 5 {
        let Ok(r) = page(p).await else { break };
        if r.g("tracks").arr().is_empty() {
            break;
        }
        raw.extend(r.g("tracks").arr().iter().cloned());
        p += 1;
    }
    let mut seen = HashSet::new();
    let tracks: Vec<Value> = raw.iter().filter_map(track).filter(|t| seen.insert(t.g("id").s())).collect();
    let a = match &info {
        Some(i) if i.g("artist").truthy() => artist_info(i.g("artist"), i),
        _ => json!({ "id": format!("yar:{}", aid), "source": "yandex", "name": "", "avatar": null }),
    };
    let tot = nz(pt).max(tracks.len() as f64);
    Ok(json!({ "artist": a, "tracks": tracks, "total": jn(tot) }))
}
trait Tn {
    fn truthy_n(self) -> bool;
}
impl Tn for f64 {
    fn truthy_n(self) -> bool {
        self != 0.0 && !self.is_nan()
    }
}

pub async fn artist_brief(id: &str) -> R<Value> {
    let Some(aid) = num(&json!(id.strip_prefix("yar:").unwrap_or(id))) else { return Ok(Value::Null) };
    let r = api(&format!("/artists/{}/brief-info", aid), opt_auth().t(8000)).await?;
    if !r.g("artist").truthy() {
        return Ok(Value::Null);
    }
    let a = artist_info(r.g("artist"), &r);
    let pic = first_of(&[&uri_of(r.path(&["artist", "cover"])), r.path(&["artist", "ogImage"])]).clone();
    Ok(json!({ "id": a.g("id"), "name": a.g("name"), "avatar": big(&pic, "1000x1000"), "source": "yandex" }))
}

pub async fn artist_bio(id: &str, name: &str) -> R<String> {
    let mut aid = num(&json!(id.strip_prefix("yar:").unwrap_or(id)));
    if aid.is_none() && !name.is_empty() {
        let f = find_artist(name).await?;
        aid = num(&json!(f.g("id").s().trim_start_matches("yar:")));
    }
    let Some(aid) = aid else { return Ok(String::new()) };
    let r = api(&format!("/artists/{}/brief-info", aid), opt_auth().t(8000)).await?;
    Ok(first_sentence(&r.path(&["artist", "description", "text"]).s(), 160))
}

pub async fn search_all(text: &str) -> R<Value> {
    let q = slice(text.trim(), 150);
    if q.is_empty() {
        return Ok(Value::Null);
    }
    let r = api(
        &format!("/search?{}", qs(&[("text", &q), ("type", "all"), ("page", "0"), ("nocorrect", "false")])),
        opt_auth().t(9000),
    )
    .await?;
    if !r.truthy() {
        return Ok(Value::Null);
    }
    let raw_artists = r.path(&["artists", "results"]).arr();
    let artists: Vec<Value> = raw_artists
        .iter()
        .filter_map(artist_card)
        .map(|mut a| {
            let raw = raw_artists.iter().find(|x| format!("yar:{}", x.g("id").sv()) == a.g("id").s()).unwrap_or(&crate::js::NULL);
            crate::js::set(&mut a, "source", json!("yandex"));
            crate::js::set(&mut a, "followers", jn(nz(raw.g("likesCount").n())));
            let g = raw.g("genres").at(0);
            crate::js::set(&mut a, "genre", if g.truthy() { g.clone() } else { json!("") });
            a
        })
        .collect();
    let b = r.g("best");
    let best = if b.g("result").truthy() {
        match b.g("type").as_str() {
            Some("artist") => json!({ "kind": "artist", "id": format!("yar:{}", b.path(&["result", "id"]).sv()) }),
            Some("track") => json!({ "kind": "track", "id": format!("ym:{}", b.path(&["result", "id"]).sv()) }),
            _ => Value::Null,
        }
    } else {
        Value::Null
    };
    let ep = if r.path(&["podcast_episodes", "results"]).truthy() {
        r.path(&["podcast_episodes", "results"])
    } else {
        r.path(&["podcastEpisodes", "results"])
    };
    Ok(json!({
        "best": best,
        "misspell": if r.g("misspellCorrected").truthy() && r.g("misspellResult").truthy() { json!(slice(&r.g("misspellResult").sv(), 150)) } else { json!("") },
        "artists": artists,
        "tracks": r.path(&["tracks", "results"]).arr().iter().filter(|x| x.truthy() && x.g("available") != &Value::Bool(false)).filter_map(track).collect::<Vec<_>>(),
        "albums": r.path(&["albums", "results"]).arr().iter().filter_map(album_card).collect::<Vec<_>>(),
        "playlists": r.path(&["playlists", "results"]).arr().iter().filter_map(playlist_card).collect::<Vec<_>>(),
        "podcasts": r.path(&["podcasts", "results"]).arr().iter().filter_map(|x| {
            let ty = if x.g("type").truthy() { x.g("type").clone() } else { json!("podcast") };
            album_card(&spread(x, &json!({ "type": ty })))
        }).collect::<Vec<_>>(),
        "episodes": ep.arr().iter().filter_map(|x| {
            let ty = if x.g("type").truthy() { x.g("type").clone() } else { json!("podcast-episode") };
            track(&spread(x, &json!({ "type": ty })))
        }).collect::<Vec<_>>(),
    }))
}

pub async fn non_music() -> R<Value> {
    let seen = Mutex::new(HashSet::new());
    let add = |list: &mut Vec<Value>, a: &Value, kind: Option<&str>| {
        if !a.is_object() {
            return;
        }
        let Some(k) = pod_kind(a).or(kind) else { return };
        let ty = first_of(&[a.g("type"), a.g("metaType")]);
        let ty = if ty.truthy() { ty.clone() } else { json!(if k == "book" { "audiobook" } else { "podcast" }) };
        let Some(c) = album_card(&spread(
            a,
            &json!({ "coverUri": first_of(&[a.g("coverUri"), &uri_of(a.g("cover")), a.g("ogImage")]), "type": ty }),
        )) else {
            return;
        };
        if !seen.lock().unwrap().insert(c.g("id").s()) {
            return;
        }
        list.push(c);
    };
    let mut liked = vec![];
    let mut errors: Vec<String> = vec![];
    if has_token() {
        let r = async { api(&format!("/users/{}/likes/albums?rich=true", uid().await?), auth().t(12000)).await }.await;
        match r {
            Ok(r) => {
                for x in r.arr() {
                    add(&mut liked, if x.g("album").truthy() { x.g("album") } else { x }, None);
                }
            }
            Err(e) => errors.push(slice(&e.msg, 160)),
        }
    }
    let search = |text: &'static str, ty: &'static str| async move {
        api(&format!("/search?{}", qs(&[("text", text), ("type", ty), ("page", "0")])), opt_auth().t(9000)).await
    };
    let (p1, books) = tokio::join!(api("/landing3?blocks=podcasts", opt_auth().t(9000)), search("аудиокнига", "all"));
    let mut podcasts = vec![];
    let mut landing_ok = false;
    if let Ok(r) = &p1 {
        for b in r.g("blocks").arr() {
            for e in b.g("entities").arr() {
                let d = first_of(&[e.path(&["data", "podcast"]), e.path(&["data", "album"]), e.g("data")]);
                add(&mut podcasts, d, Some("podcast"));
            }
        }
        landing_ok = !podcasts.is_empty();
    }
    if !landing_ok {
        match search("подкаст", "podcast").await {
            Ok(r) => {
                for x in r.path(&["podcasts", "results"]).arr() {
                    add(&mut podcasts, x, Some("podcast"));
                }
            }
            Err(e) => errors.push(slice(&e.msg, 160)),
        }
    }
    let mut bk = vec![];
    match books {
        Ok(r) => {
            for x in r.path(&["albums", "results"]).arr().iter().chain(r.path(&["podcasts", "results"]).arr().iter()) {
                if pod_kind(x) == Some("book") {
                    add(&mut bk, x, None);
                }
            }
        }
        Err(e) => errors.push(slice(&e.msg, 160)),
    }
    podcasts.truncate(24);
    bk.truncate(24);
    Ok(json!({
        "liked": liked,
        "podcasts": podcasts,
        "books": bk,
        "errors": crate::js::uniq_strings(errors).into_iter().take(3).collect::<Vec<_>>(),
    }))
}
