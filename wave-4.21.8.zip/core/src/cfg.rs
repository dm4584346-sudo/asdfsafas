//! Settings and library: defaults, the cleaning of what the interface sends, the public settings, and the repair of
//! both files at start-up (main.cjs).

use crate::app::{app, blog, p};
use crate::js::{clamp_num, jn, round, slice, J};
use crate::re;
use crate::security::clean_track;
use serde_json::{json, Map, Value};

pub fn default_settings() -> Value {
    json!({
        "theme": "dark", "scClientId": "", "scClientIdAuto": "", "spotifyClientId": "",
        "sources": { "soundcloud": true, "audius": true, "spotify": true },
        "autoMatch": true, "animation": true, "volume": 0.7, "ui": "glass", "player": "cover", "accent": "violet",
        "glassFx": "full", "autoMatchImport": true, "ymLikesSync": true, "ytFallback": true, "ymStream": true,
        "autostart": false, "ymPrefer": "free", "ymWaveDirect": true, "ymQuality": "lossless", "waveCutout": true,
        "cutStrict": "strict", "waveColorPause": true, "waveGlow": true, "waveStyle": "classic",
        "waveGlowFx": { "power": 100, "reach": 86, "height": 100, "pulse": 50 },
        "wavePins": [], "waveLikes": [], "gpu": true, "noSandbox": false, "sandboxRetry": null,
        "offlineAuto": true, "offlineLimit": 2048,
        "profile": { "nick": "Слушатель", "avatar": null, "banner": null, "bannerLayout": { "height": 300, "x": 50, "y": 50, "zoom": 100 } },
        "wave": { "mood": "all", "diversity": "default" },
        "sidebarWidth": 250, "progressGif": null, "progressGifSize": 44, "concertCity": "", "waveSource": "wave",
        "artistStats": "yandex", "artistBanner": "spotify", "skin": "wave", "volPct": true,
        "speed": 1, "keepPitch": true, "crossfade": 5,
        "eq": { "on": false, "preset": "flat", "pre": 0, "bands": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "custom": null },
        "hq": true, "genius": true,
        "waveFx": { "shake": 10, "react": 60, "size": 110, "lines": false },
        "font": "ys",
        "liquid": { "on": true, "refract": 60, "blur": 30, "shine": 60, "clear": 35, "follow": true, "player": true, "buttons": true, "menus": true }
    })
}

pub fn default_library() -> Value {
    json!({
        "likes": [], "dislikes": [], "dislikeKeys": [], "playlists": [], "history": [], "matches": {},
        "likesCover": null, "files": {}, "picked": {}, "original": {}, "upgrades": {}, "artistTime": {}
    })
}

pub const UI_OPTIONS: [(&str, &[&str]); 15] = [
    ("ui", &["classic", "glass"]),
    ("player", &["cover", "nowplaying", "classic"]),
    ("accent", &["violet", "yellow", "cover", "arcane", "emerald", "sakura"]),
    ("glassFx", &["full", "lite", "off"]),
    ("waveSource", &["wave", "likes", "yandex", "spotify"]),
    ("artistStats", &["yandex", "spotify", "soundcloud", "audius"]),
    ("font", &["ys", "onest"]),
    ("ymPrefer", &["free", "ym"]),
    ("ymQuality", &["lossless", "hq", "nq"]),
    ("cutStrict", &["soft", "normal", "strict"]),
    ("waveStyle", &["classic", "yandex", "aura"]),
    ("artistBanner", &["yandex", "soundcloud", "spotify"]),
    ("skin", &["wave", "yandex", "spotify"]),
    ("theme", &[]),
    ("", &[]),
];
pub fn ui_opts(k: &str) -> &'static [&'static str] {
    UI_OPTIONS.iter().find(|x| x.0 == k).map(|x| x.1).unwrap_or(&[])
}
pub fn ui_ok(k: &str, v: &Value) -> bool {
    v.as_str().map(|s| ui_opts(k).contains(&s)).unwrap_or(false)
}
fn real_ui_options() -> impl Iterator<Item = &'static (&'static str, &'static [&'static str])> {
    UI_OPTIONS.iter().filter(|x| !x.1.is_empty())
}

pub const MOODS: [&str; 9] = ["all", "energetic", "calm", "sad", "fun", "rap", "rock", "wakeup", "sleep"];
pub fn mood_genres(m: &str) -> &'static [&'static str] {
    match m {
        "energetic" => &["electronic", "house", "drum & bass", "phonk"],
        "calm" => &["ambient", "piano", "lofi", "chill"],
        "sad" => &["sad"],
        "fun" => &["pop", "dance", "disco"],
        "rap" => &["hip-hop", "rap", "trap"],
        "rock" => &["rock", "alternative", "metal"],
        "wakeup" => &["indie pop", "acoustic", "funk", "morning"],
        "sleep" => &["sleep", "ambient", "piano", "lofi"],
        _ => &[],
    }
}

fn has(v: &Value, k: &str) -> bool {
    v.as_object().map(|m| m.contains_key(k)).unwrap_or(false)
}

pub fn clean_liquid(w: &Value, cur: &Value) -> Value {
    let mut o = Map::new();
    for k in ["refract", "blur", "shine", "clear"] {
        o.insert(k.into(), jn(round(clamp_num(w.g(k), 0.0, 100.0, cur.g(k).n()))));
    }
    for k in ["on", "follow", "player", "buttons", "menus"] {
        let v = w.g(k);
        o.insert(k.into(), json!(if v.is_boolean() { v.as_bool().unwrap() } else { cur.g(k) != &Value::Bool(false) }));
    }
    Value::Object(o)
}
pub fn clean_wave_fx(w: &Value, cur: &Value) -> Value {
    let lines = w.g("lines");
    json!({
        "shake": jn(round(clamp_num(w.g("shake"), 0.0, 100.0, cur.g("shake").n()))),
        "react": jn(round(clamp_num(w.g("react"), 0.0, 100.0, cur.g("react").n()))),
        "size": jn(round(clamp_num(w.g("size"), 60.0, 140.0, cur.g("size").n()))),
        "lines": if lines.is_boolean() { lines.clone() } else { json!(cur.g("lines") != &Value::Bool(false)) },
    })
}
pub fn clean_glow_fx(w: &Value, cur: &Value) -> Value {
    let mut o = Map::new();
    for (k, lo, hi) in [("power", 0.0, 150.0), ("reach", 30.0, 120.0), ("height", 60.0, 140.0), ("pulse", 0.0, 100.0)] {
        o.insert(k.into(), jn(round(clamp_num(w.g(k), lo, hi, cur.g(k).n()))));
    }
    Value::Object(o)
}

fn station_id(s: &str) -> bool {
    re!(r"^(user|genre|mood|activity|epoch|track|artist|album|playlist|local|personal):[A-Za-z0-9_\-.:]{1,80}$").is_match(s)
}
fn preset_seed(s: &str) -> bool {
    re!(r"^[a-z][a-z0-9_-]{0,30}:[A-Za-z0-9_\-.:]{1,80}$").is_match(s)
}
pub fn non_genre(s: &str) -> String {
    re!(r"[^\p{L}\p{N} &-]").replace_all(s, "").into_owned()
}

fn clean_preset(p: &Value) -> Option<Value> {
    if !p.is_object() {
        return None;
    }
    let k = p.g("k").as_str().map(|s| slice(s.trim(), 160)).unwrap_or_default();
    let title = p.g("title").as_str().map(|s| slice(s.trim(), 100)).unwrap_or_default();
    if k.is_empty() || title.is_empty() || re!(r#"[<>"`]"#).is_match(&k) {
        return None;
    }
    let mut o = Map::new();
    o.insert("k".into(), json!(k));
    o.insert("title".into(), json!(title));
    if let Some(s) = p.g("sub").as_str() {
        if !s.trim().is_empty() {
            o.insert("sub".into(), json!(slice(s.trim(), 60)));
        }
    }
    if let Some(s) = p.g("station").as_str() {
        if s.encode_utf16().count() <= 400 {
            let seeds: Vec<&str> = s.split(',').collect();
            if seeds.len() <= 8 && seeds.iter().all(|x| station_id(x) || preset_seed(x)) {
                o.insert("station".into(), json!(s));
            }
        }
    }
    if let Some(s) = p.g("album").as_str() {
        if re!(r"^yma:\d{1,12}$").is_match(s) {
            o.insert("album".into(), json!(s));
        }
    }
    if let Some(s) = p.g("from").as_str() {
        if re!(r"^ym:\d{1,15}$").is_match(s) {
            o.insert("from".into(), json!(s));
        }
    }
    if let Some(s) = p.g("mood").as_str() {
        if MOODS.contains(&s) {
            o.insert("mood".into(), json!(s));
        }
    }
    if let Some(s) = p.g("genre").as_str() {
        let g = slice(non_genre(s).trim(), 40);
        if !g.is_empty() {
            o.insert("genre".into(), json!(g));
        }
    }
    if let Some(s) = p.g("img").as_str() {
        if re!(r#"^https://[^\s"'<>()\\]{1,500}$"#).is_match(s) {
            o.insert("img".into(), json!(s));
        }
    }
    if let Some(s) = p.g("color").as_str() {
        if re!(r"(?i)^#[0-9a-f]{6}$").is_match(s) {
            o.insert("color".into(), json!(s));
        }
    }
    for f in ["g", "y"] {
        if let Some(s) = p.g(f).as_str() {
            if re!(r"^[a-z]{1,12}$").is_match(s) {
                o.insert(f.into(), json!(s));
            }
        }
    }
    for f in ["round", "agent", "likes"] {
        if p.g(f) == &Value::Bool(true) {
            o.insert(f.into(), json!(true));
        }
    }
    if p.g("seed").is_object() || p.g("seed").is_array() {
        if let Ok(t) = clean_track(p.g("seed")) {
            o.insert("seed".into(), t);
        }
    }
    Some(Value::Object(o))
}
pub fn clean_presets(a: &Value, max: usize) -> Value {
    let mut seen = std::collections::HashSet::new();
    json!(a.arr().iter().filter_map(clean_preset).filter(|p| seen.insert(p.g("k").s())).take(max).collect::<Vec<_>>())
}

const EQ_PRESETS: [&str; 18] = [
    "flat", "bass", "bassmax", "treble", "bt", "vocal", "pop", "rock", "hiphop", "electro", "dance", "acoustic", "jazz",
    "classic", "loud", "phones", "laptop", "custom",
];
fn db_half(v: &Value) -> Value {
    jn(round(clamp_num(v, -12.0, 12.0, 0.0) * 2.0) / 2.0)
}
fn eq_bands(b: &Value) -> Option<Value> {
    match b.as_array() {
        Some(a) if a.len() == 10 => Some(json!(a.iter().map(db_half).collect::<Vec<_>>())),
        _ => None,
    }
}
pub fn clean_eq(e: &Value, cur: &Value) -> Value {
    if !e.is_object() && !e.is_array() {
        return cur.clone();
    }
    let preset = |v: &Value| v.as_str().filter(|s| EQ_PRESETS.contains(s)).map(String::from);
    json!({
        "on": if has(e, "on") { e.g("on").truthy() } else { cur.g("on").truthy() },
        "preset": preset(e.g("preset")).or_else(|| preset(cur.g("preset"))).unwrap_or_else(|| "flat".into()),
        "pre": if has(e, "pre") { db_half(e.g("pre")) } else { db_half(cur.g("pre")) },
        "bands": eq_bands(e.g("bands")).or_else(|| eq_bands(cur.g("bands"))).unwrap_or(json!([0, 0, 0, 0, 0, 0, 0, 0, 0, 0])),
        "custom": if has(e, "custom") { eq_bands(e.g("custom")) } else { eq_bands(cur.g("custom")) },
    })
}
pub fn default_eq() -> Value {
    default_settings().g("eq").clone()
}

/* ---------- «Микс» of an own playlist ---------- */
pub const MIX_STYLES: [&str; 6] = ["auto", "fade", "rise", "blend", "echo", "cut"];
fn mix_len(v: &Value, def: f64) -> Value {
    jn(round(clamp_num(v, 1.0, 16.0, def) * 2.0) / 2.0)
}
fn clean_mix_tr(t: &Value) -> Map<String, Value> {
    let mut o = Map::new();
    if !t.is_object() {
        return o;
    }
    if let Some(s) = t.g("style").as_str() {
        if MIX_STYLES.contains(&s) {
            o.insert("style".into(), json!(s));
        }
    }
    if !t.g("len").is_null() && t.g("len").n().is_finite() {
        o.insert("len".into(), mix_len(t.g("len"), 8.0));
    }
    for k in ["out", "in"] {
        let v = t.g(k);
        if !v.is_null() && v.n().is_finite() && v.n() > 0.0 {
            o.insert(k.into(), jn(round(clamp_num(v, 0.0, 30.0, 0.0))));
        }
    }
    o
}
pub fn clean_mix(m: &Value, p: &Value) -> Option<Value> {
    if !m.is_object() {
        return None;
    }
    let ids: std::collections::HashSet<String> = p.g("tracks").arr().iter().map(|t| t.g("id").sv()).collect();
    let mut tr = Map::new();
    if let Value::Object(map) = m.g("tr") {
        for (k, v) in map {
            let ab: Vec<&str> = k.split('>').collect();
            if ab.len() != 2 || ab[0] == ab[1] || !ids.contains(ab[0]) || !ids.contains(ab[1]) {
                continue;
            }
            let c = clean_mix_tr(v);
            if c.is_empty() {
                continue;
            }
            tr.insert(k.clone(), Value::Object(c));
            if tr.len() >= 2000 {
                break;
            }
        }
    }
    Some(json!({
        "on": m.g("on") == &Value::Bool(true),
        "style": m.g("style").as_str().filter(|s| MIX_STYLES.contains(s)).unwrap_or("auto"),
        "len": mix_len(m.g("len"), 8.0),
        "tr": tr,
    }))
}

pub fn public_settings() -> Value {
    let s = app().settings.lock().clone();
    let pick = |k: &str, def: &str| -> Value { if ui_ok(k, s.g(k)) { s.g(k).clone() } else { json!(def) } };
    let or = |k: &str, def: Value| -> Value { if s.g(k).truthy() { s.g(k).clone() } else { def } };
    let me = crate::providers::yandex::me();
    let cf = s.g("crossfade");
    let ol = s.g("offlineLimit");
    json!({
        "theme": s.g("theme"),
        "scClientId": s.g("scClientId"),
        "scAuto": s.g("scClientIdAuto").truthy(),
        "spotifyClientId": s.g("spotifyClientId"),
        "sources": s.g("sources"),
        "autoMatch": s.g("autoMatch"),
        "animation": s.g("animation"),
        "volume": s.g("volume"),
        "volCurve": or("volCurve", json!(1)),
        "ui": s.g("ui"),
        "player": s.g("player"),
        "accent": s.g("accent"),
        "glassFx": s.g("glassFx"),
        "autoMatchImport": s.g("autoMatchImport") != &Value::Bool(false),
        "ymLikesSync": s.g("ymLikesSync") != &Value::Bool(false),
        "ytFallback": s.g("ytFallback") != &Value::Bool(false),
        "ymStream": s.g("ymStream") != &Value::Bool(false),
        "ymPrefer": pick("ymPrefer", "free"),
        "ymWaveDirect": s.g("ymWaveDirect") == &Value::Bool(true),
        "ymQuality": pick("ymQuality", "lossless"),
        // the artist cut-out needs the image tools of the PC build: off on the phone (the switch is hidden)
        "waveCutout": false,
        "waveColorPause": s.g("waveColorPause") != &Value::Bool(false),
        "waveGlow": s.g("waveGlow") != &Value::Bool(false),
        "cutStrict": pick("cutStrict", "strict"),
        "gpu": s.g("gpu") != &Value::Bool(false),
        "autostart": s.g("autostart") == &Value::Bool(true),
        "profile": s.g("profile"),
        "wave": s.g("wave"),
        "sidebarWidth": or("sidebarWidth", json!(250)),
        "progressGif": or("progressGif", Value::Null),
        "progressGifSize": or("progressGifSize", json!(44)),
        "concertCity": or("concertCity", json!("")),
        "waveSource": or("waveSource", json!("wave")),
        "artistStats": or("artistStats", json!("yandex")),
        "volPct": s.g("volPct") != &Value::Bool(false),
        "speed": or("speed", json!(1)),
        "keepPitch": s.g("keepPitch") != &Value::Bool(false),
        "crossfade": if cf.n().is_finite() && cf.is_number() { cf.clone() } else { json!(5) },
        "offlineAuto": s.g("offlineAuto") != &Value::Bool(false),
        "offlineLimit": if ol.is_number() && ol.as_f64().unwrap_or(0.0) >= 200.0 { ol.clone() } else { json!(2048) },
        "eq": clean_eq(s.g("eq"), &default_eq()),
        "hq": s.g("hq") != &Value::Bool(false),
        "genius": s.g("genius") != &Value::Bool(false),
        "waveFx": clean_wave_fx(s.g("waveFx"), default_settings().g("waveFx")),
        "waveStyle": pick("waveStyle", "classic"),
        "artistBanner": pick("artistBanner", "spotify"),
        "skin": pick("skin", "wave"),
        "waveGlowFx": clean_glow_fx(s.g("waveGlowFx"), default_settings().g("waveGlowFx")),
        "wavePins": clean_presets(s.g("wavePins"), 8),
        "waveLikes": clean_presets(s.g("waveLikes"), 40),
        "liquid": clean_liquid(s.g("liquid"), default_settings().g("liquid")),
        "font": pick("font", "ys"),
        "ymToken": crate::providers::yandex::has_token(),
        "ymUser": if me.g("name").truthy() { me.g("name").clone() } else { Value::Null },
        "spotifyRedirect": crate::providers::spotify::REDIRECT,
    })
}

fn obj_or_empty(v: &Value) -> Value {
    if v.is_object() {
        v.clone()
    } else {
        json!({})
    }
}

/// the repairs of whenReady() in main.cjs
pub fn repair_settings(s: &mut Value) {
    let d = default_settings();
    // 4.20: new defaults of «Подключения» for everyone, once: SoundCloud/Audius first, «Моя волна» straight from
    // Yandex, Lossless; afterwards the user's own choice is kept
    if s.g("defaults420") != &Value::Bool(true) {
        crate::js::set(s, "ymPrefer", json!("free"));
        crate::js::set(s, "ymWaveDirect", json!(true));
        crate::js::set(s, "ymQuality", json!("lossless"));
        crate::js::set(s, "defaults420", json!(true));
    }
    let sources = crate::js::spread(d.g("sources"), &obj_or_empty(s.g("sources")));
    crate::js::set(s, "sources", sources);
    let mut profile = crate::js::spread(d.g("profile"), &obj_or_empty(s.g("profile")));
    let bl = crate::js::spread(d.path(&["profile", "bannerLayout"]), &obj_or_empty(profile.g("bannerLayout")));
    crate::js::set(&mut profile, "bannerLayout", bl);
    crate::js::set(s, "profile", profile);
    for (k, _) in real_ui_options() {
        if !ui_ok(k, s.g(k)) {
            let v = d.g(k).clone();
            crate::js::set(s, k, v);
        }
    }
    let wave = crate::js::spread(d.g("wave"), &obj_or_empty(s.g("wave")));
    crate::js::set(s, "wave", wave);
    let sw = jn(round(clamp_num(s.g("sidebarWidth"), 200.0, 380.0, 250.0)));
    crate::js::set(s, "sidebarWidth", sw);
    let sp = jn(round(clamp_num(s.g("speed"), 0.5, 2.0, 1.0) * 100.0) / 100.0);
    crate::js::set(s, "speed", sp);
    let cf = jn(round(clamp_num(s.g("crossfade"), 0.0, 12.0, 5.0)));
    crate::js::set(s, "crossfade", cf);
    crate::js::set(s, "offlineAuto", json!(s.g("offlineAuto") != &Value::Bool(false)));
    let ol = jn(round(clamp_num(s.g("offlineLimit"), 200.0, 50000.0, 2048.0)));
    crate::js::set(s, "offlineLimit", ol);
    let eq = clean_eq(s.g("eq"), &default_eq());
    crate::js::set(s, "eq", eq);
    let wf = clean_wave_fx(s.g("waveFx"), d.g("waveFx"));
    crate::js::set(s, "waveFx", wf);
    let lq = clean_liquid(s.g("liquid"), d.g("liquid"));
    crate::js::set(s, "liquid", lq);
    let gf = clean_glow_fx(s.g("waveGlowFx"), d.g("waveGlowFx"));
    crate::js::set(s, "waveGlowFx", gf);
    let wp = clean_presets(s.g("wavePins"), 8);
    crate::js::set(s, "wavePins", wp);
    let wl = clean_presets(s.g("waveLikes"), 40);
    crate::js::set(s, "waveLikes", wl);
    let cc = crate::providers::afisha::valid_city(s.g("concertCity"));
    crate::js::set(s, "concertCity", json!(cc));
    let gif_ok = s.g("progressGif").as_str().map(|x| x.starts_with("data:image/gif;base64,")).unwrap_or(false);
    if !gif_ok {
        crate::js::set(s, "progressGif", Value::Null);
    }
}

pub fn repair_library(l: &mut Value) {
    // remove only repeated identical Yandex track ids, after a backup of the original library
    let likes = l.g("likes").clone();
    if let Value::Array(list) = &likes {
        let mut seen = std::collections::HashSet::new();
        let mut kept = vec![];
        let mut removed = 0;
        for t in list {
            let id = t.g("id").as_str().unwrap_or("");
            if re!(r"^ym:\d{1,15}$").is_match(id) {
                if !seen.insert(id.to_string()) {
                    removed += 1;
                    continue;
                }
            }
            kept.push(t.clone());
        }
        if removed > 0 {
            let backup = p(&format!(
                "library-before-ym-likes-dedup-{}-{}.json",
                crate::js::now_ms() as i64,
                uuid::Uuid::new_v4()
            ));
            let ok = !backup.exists() && std::fs::copy(p("library.json"), &backup).is_ok();
            if ok {
                crate::js::set(l, "likes", Value::Array(kept));
                blog(&format!("ym likes: removed {} exact duplicates; original library backed up", removed));
            } else {
                blog("ym likes: cleanup skipped; backup failed");
            }
        }
    }
    for k in ["matches", "files", "picked", "original", "upgrades", "artistTime"] {
        if !l.g(k).is_object() {
            crate::js::set(l, k, json!({}));
        }
    }
    if let Some(pls) = l.get_mut("playlists").and_then(|v| v.as_array_mut()) {
        for pl in pls.iter_mut() {
            if !pl.as_object().map(|m| m.contains_key("mix")).unwrap_or(false) {
                continue;
            }
            let m = if pl.g("tracks").is_array() && !pl.g("source").truthy() && pl.g("kind").as_str() != Some("album") {
                clean_mix(pl.g("mix"), pl)
            } else {
                None
            };
            match m {
                Some(m) => crate::js::set(pl, "mix", m),
                None => {
                    if let Some(o) = pl.as_object_mut() {
                        o.shift_remove("mix");
                    }
                }
            }
        }
    }
    let files = l.g("files").clone();
    if let Some(h) = l.get("history").and_then(|v| v.as_array()).cloned() {
        let h: Vec<Value> = h
            .into_iter()
            .filter(|t| t.g("id").as_str().map(|id| !id.starts_with("lf:") || files.g(id).truthy()).unwrap_or(false))
            .collect();
        crate::js::set(l, "history", Value::Array(h));
    }
}
