import UIKit
import WebKit

/// a sign-in window of the core (Яндекс and others): every address it goes to is reported back
final class AuthViewController: UIViewController, WKNavigationDelegate, WKUIDelegate {
    let id: String
    private let start: URL
    var onNav: ((String) -> Void)?
    var onClose: (() -> Void)?
    private var web: WKWebView!

    init(id: String, url: URL) {
        self.id = id
        self.start = url
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        isModalInPresentation = true
        let cfg = WKWebViewConfiguration()
        cfg.websiteDataStore = .default()
        web = WKWebView(frame: view.bounds, configuration: cfg)
        web.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        web.navigationDelegate = self
        web.uiDelegate = self
        view.addSubview(web)
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Закрыть", style: .plain, target: self, action: #selector(closeTapped))
        title = start.host
        web.load(URLRequest(url: start))
    }

    @objc private func closeTapped() {
        let cb = onClose
        onClose = nil
        dismiss(animated: true) { cb?() }
    }

    /// the core closed the window itself: nothing to report
    func closeFromCore() {
        onClose = nil
        onNav = nil
        dismiss(animated: true)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        let url = navigationAction.request.url
        if let u = url?.absoluteString, navigationAction.targetFrame?.isMainFrame ?? true {
            onNav?(u)
        }
        let scheme = url?.scheme?.lowercased() ?? ""
        decisionHandler(scheme == "http" || scheme == "https" || scheme == "about" ? .allow : .cancel)
    }

    func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
        if let u = webView.url?.absoluteString { onNav?(u) }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        title = webView.title?.isEmpty == false ? webView.title : webView.url?.host
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil { webView.load(navigationAction.request) }
        return nil
    }
}
