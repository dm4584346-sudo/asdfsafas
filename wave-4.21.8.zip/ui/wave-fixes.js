"use strict";
/* Wave 4.20.2 — UI fixes (overlay, loaded after app.js / mobile.js / social.js) */
(() => {
  const root = document.documentElement;
  const NATIVE = window.WaveAndroid || null;
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];

  /* ---------- 1. Status bar: a reliable top inset on Android 10–17 ---------- */
  let probe = null;
  const envTop = () => {
    try {
      if (!probe) {
        probe = document.createElement("div");
        probe.style.cssText = "position:fixed;top:0;left:0;width:1px;height:env(safe-area-inset-top,0px);visibility:hidden;pointer-events:none";
        document.body.appendChild(probe);
      }
      return probe.offsetHeight || 0;
    } catch { return 0; }
  };
  const nativeTop = () => {
    try {
      if (NATIVE && typeof NATIVE.safeInsets === "function") return Math.max(0, Number(String(NATIVE.safeInsets()).split(",")[0]) || 0);
    } catch {}
    return 0;
  };
  let safeTop = 0;
  const syncTop = () => {
    const n = nativeTop(), e = envTop();
    let top = Math.max(n, e);
    // Android 15+ draws apps edge-to-edge: the WebView covers the status bar even without a cutout.
    const edgeToEdge = window.innerHeight >= (screen.height || 0) - 4;
    if (top < 24 && edgeToEdge) top = 28;
    safeTop = Math.min(160, top);
    root.style.setProperty("--wf-safe-top", safeTop + "px");
    if (n < safeTop) root.style.setProperty("--m-safe-top", safeTop + "px");
  };
  const fixClose = () => {
    $$(".fpa-close, .fp-close, [data-cmd='fp-close']").forEach(b => {
      if (!b.offsetParent && getComputedStyle(b).position !== "fixed") return;
      const cur = parseFloat(b.style.getPropertyValue("--wf-push")) || 0;
      const r = b.getBoundingClientRect();
      if (!r.height) return;
      const top0 = r.top - cur;
      const need = Math.max(0, Math.ceil(safeTop + 6 - top0));
      if (need !== cur) b.style.setProperty("--wf-push", need + "px");
    });
  };
  const syncAll = () => { syncTop(); fixClose(); };
  syncAll();
  [300, 1200, 3000].forEach(ms => setTimeout(syncAll, ms));
  addEventListener("resize", () => setTimeout(syncAll, 60), { passive: true });
  addEventListener("orientationchange", () => setTimeout(syncAll, 300), { passive: true });
  document.addEventListener("click", () => requestAnimationFrame(() => requestAnimationFrame(fixClose)), true);
  setInterval(fixClose, 800);

  /* ---------- 2. «Войти по коду» → straight to the code field ---------- */
  const waitFor = (sel, ms = 3000) => new Promise(resolve => {
    const t0 = performance.now();
    const tick = () => {
      const el = $(sel);
      if (el) return resolve(el);
      if (performance.now() - t0 > ms) return resolve(null);
      requestAnimationFrame(tick);
    };
    tick();
  });
  document.addEventListener("click", e => {
    if (!e.target.closest?.("[data-wf-join]")) return;
    waitFor('#soc-join-room input[name="code"]').then(input => {
      if (!input) return;
      const panel = input.closest("form, section, .soc-panel") || input;
      panel.scrollIntoView({ block: "center", behavior: "smooth" });
      panel.classList.remove("wf-focus-panel");
      void panel.offsetWidth;
      panel.classList.add("wf-focus-panel");
      setTimeout(() => { try { input.focus({ preventScroll: true }); input.select?.(); } catch {} }, 280);
    });
  }, true);

  /* ---------- 3. Room queue: live track suggestions while typing ---------- */
  let timer = 0, lastQuery = "", pending = false;
  const qInput = () => $('#soc-track-search input[name="q"]');
  const runSearch = () => {
    const input = qInput();
    if (!input) return;
    const form = input.form, q = input.value.trim();
    if (q.length < 2 || q === lastQuery) return;
    const btn = form?.querySelector("button");
    if (!form || btn?.disabled) { clearTimeout(timer); timer = setTimeout(runSearch, 200); return; }
    lastQuery = q;
    pending = true;
    $("#soc-track-results")?.classList.add("wf-loading");
    try { form.requestSubmit ? form.requestSubmit() : form.dispatchEvent(new Event("submit", { cancelable: true })); } catch {}
  };
  document.addEventListener("focusin", e => {
    if (e.target.matches?.('#soc-track-search input[name="q"]')) {
      e.target.setAttribute("autocomplete", "off");
      e.target.setAttribute("enterkeyhint", "search");
    }
  });
  document.addEventListener("input", e => {
    if (!e.target.matches?.('#soc-track-search input[name="q"]')) return;
    clearTimeout(timer);
    if (e.target.value.trim().length < 2) { lastQuery = ""; return; }
    timer = setTimeout(runSearch, 280);
  });
  new MutationObserver(() => {
    const out = $("#soc-track-results");
    const btn = $("#soc-track-search button");
    if (out && pending && btn && !btn.disabled) {
      pending = false;
      out.classList.remove("wf-loading");
      const input = qInput();
      if (input && input.value.trim() !== lastQuery && input.value.trim().length >= 2) { clearTimeout(timer); timer = setTimeout(runSearch, 120); }
    }
    if (!qInput()) lastQuery = "";
  }).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["disabled"] });
})();

// 4.20.3: «Моя волна» — the list is prepared in the background, so Play starts without the long wait
(function () {
  const warm = () => {
    try {
      if (typeof waveWarmup === "function" && !S.current && !document.hidden) waveWarmup({});
    } catch {}
  };
  setTimeout(warm, 2500);
  setInterval(warm, 100e3);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) setTimeout(warm, 500); });
})();

/* 4.20.3: bottom tabs and other tab rows - every tap counts.
   A tap could be lost: the click that follows a gesture (mini-player swipe, list drag) was eaten, or the page was
   re-rendered under the finger. If the real click does not come right after the finger is lifted, the tab is
   clicked here; a late real click after that is dropped, so a tab never opens twice. */
(function () {
  const root = document.documentElement;
  if (!root.hasAttribute("data-mobile")) return;
  const NAV = "#m-tabs button, #m-tabs [data-go], .soc-hub-nav > button, .stabs[role='tablist'] .stab, .soc-tabs > button";
  const route = () => { try { return S.route; } catch { return ""; } };
  let down = null, tap = null;
  const unpress = () => document.querySelectorAll(".wf-press").forEach((x) => x.classList.remove("wf-press"));
  document.addEventListener("pointerdown", (e) => {
    const b = e.isPrimary ? e.target.closest?.(NAV) : null;
    down = b ? { b, x: e.clientX, y: e.clientY, t: performance.now(), r: route() } : null;
    if (b) b.classList.add("wf-press");
  }, { capture: true, passive: true });
  document.addEventListener("pointercancel", () => { down = null; unpress(); }, { capture: true, passive: true });
  document.addEventListener("pointerup", (e) => {
    unpress();
    const d = down;
    down = null;
    if (!d || !e.isPrimary) return;
    if (Math.hypot(e.clientX - d.x, e.clientY - d.y) > 16 || performance.now() - d.t > 800) return;
    const under = document.elementFromPoint(e.clientX, e.clientY);
    if (under && !d.b.contains(under) && under.closest?.(NAV) !== d.b) return;
    const me = { b: d.b, real: false, synth: false };
    tap = me;
    setTimeout(() => {
      if (tap !== me || me.real || !me.b.isConnected) return;
      if (route() !== d.r) return; // the tab was opened by another handler (touchend) - nothing to repeat
      me.synth = true;
      me.b.click();
    }, 120);
    setTimeout(() => { if (tap === me) tap = null; }, 900);
  }, { capture: true, passive: true });
  // window, capture: runs before every other click handler
  window.addEventListener("click", (e) => {
    const me = tap;
    if (!me || !e.isTrusted) return;
    const b = e.target.closest?.(NAV);
    if (b && b !== me.b) return;
    if (me.synth) { e.stopImmediatePropagation(); e.preventDefault(); tap = null; return; }
    me.real = true;
  }, true);
})();

/* 4.20.3: smoother switching. Pictures are decoded off the main thread; quick taps on tabs do not queue a
   pile of renders - the screen follows the last tap. */
(function () {
  const root = document.documentElement;
  if (!root.hasAttribute("data-mobile")) return;
  const tune = (n) => {
    if (n.tagName === "IMG") { if (!n.hasAttribute("decoding")) n.decoding = "async"; return; }
    n.querySelectorAll?.("img:not([decoding])").forEach((im) => (im.decoding = "async"));
  };
  new MutationObserver((list) => {
    for (const m of list) for (const n of m.addedNodes) if (n.nodeType === 1) tune(n);
  }).observe(document.body, { childList: true, subtree: true });
  tune(document.body);

  if (typeof window.go !== "function") return;
  const orig = window.go;
  let last = 0, pending = null, raf = 0;
  window.go = function (route, opts) {
    const now = performance.now();
    // a burst of taps (< 1 frame apart): only the last one is rendered
    if (now - last < 90 && !(opts && opts.keep)) {
      pending = [route, opts];
      if (!raf) raf = requestAnimationFrame(() => {
        raf = 0;
        const p = pending;
        pending = null;
        if (p) { last = performance.now(); orig.apply(this, p); }
      });
      return;
    }
    last = now;
    return orig.apply(this, arguments);
  };
})();
