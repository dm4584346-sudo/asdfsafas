"use strict";
/* Wave Android — the touch layer over the desktop interface (app/ui/app.js runs unchanged before this file).
   • the tab bar (Моя волна / Для вас / Поиск / Коллекция / Ещё) and the side panel as a drawer;
   • a long press works as the right click (track menus, playlist menus…);
   • the Android «Назад» button, the media notification and its buttons;
   • controls of the full-screen player for fingers (on the PC they appear on hover). */
(() => {
  const NATIVE = window.WaveAndroid || null;
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const ico = (id) => `<svg><use href="#i-${id}"/></svg>`;
  const body = document.body;
  // Android reports cutout insets separately so the background still fills the screen.
  const syncSafeInsets = () => {
    try {
      const raw = NATIVE && typeof NATIVE.safeInsets === "function" ? NATIVE.safeInsets() : "0,0,0";
      const values = String(raw).split(",").map(v => Math.max(0, Math.min(160, Number(v) || 0)));
      ["top", "left", "right"].forEach((side, i) => document.documentElement.style.setProperty(`--m-safe-${side}`, `${values[i] || 0}px`));
    } catch { /* CSS safe-area and a small default margin remain as fallbacks. */ }
  };
  syncSafeInsets();
  [250, 1000, 2500].forEach(ms => setTimeout(syncSafeInsets, ms));
  addEventListener("resize", syncSafeInsets, {passive:true});
  addEventListener("orientationchange", () => setTimeout(syncSafeInsets, 250), {passive:true});
  // S (the state of app.js) is a top-level const of the classic script: visible here by name, not as window.S
  const hasS = () => typeof S !== "undefined";

  /* ---------- tab bar (four icons, no labels) + the header (profile · title · search) ---------- */
  // the own icon of «Моя волна»: two flowing waves (not the burst of Yandex Music)
  const sym = document.querySelector("svg.sym defs");
  if (sym && !document.getElementById("i-mwave"))
    sym.insertAdjacentHTML(
      "beforeend",
      // the wave of the user's logo: an outer ribbon (hooks at the ends, a tall crest in the middle) and an inner one
      // woven through it under the crest
      // ribbon 1: the left hook, the left valley, a low hump in the middle, the right valley;
      // ribbon 2: from the left valley over the tall crest, the right valley and the right hook — drawn over ribbon 1,
      // which is a bit darker, so they look woven
      // (symmetric: the left hook of ribbon 1 is the mirror of the right hook of ribbon 2 around x = 25)
      '<symbol id="i-mwave" viewBox="0 0 50 30">' +
        '<path d="M3 13.5C8.5 13.5 12.6 26 16.4 22.4 19.4 19.6 21.6 15.2 25 15.2 28.4 15.2 30.6 19.6 33.6 22.4" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" opacity=".72"/>' +
        '<path d="M16.4 22.4C19.4 16.4 21.2 4.5 25 4.5 28.8 4.5 30.6 16.4 33.6 22.4 37.4 26 41.5 13.5 47 13.5" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/>' +
        "</symbol>",
    );
  // «Друзья и комнаты»: два силуэта (как в Яндекс Музыке), стиль «i-user» (заливка)
  if (sym && !document.getElementById("i-hist"))
    sym.insertAdjacentHTML(
      "beforeend",
      '<symbol id="i-hist" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M3.5 12a8.5 8.5 0 1 0 2.5-6M3.5 4.5V9H8"/><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M12 7.6V12l3 2"/></symbol>' +
        '<symbol id="i-dl" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" d="M12 3.5v11M7.5 10l4.5 4.5 4.5-4.5M4.5 15.5v2.5a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2v-2.5"/></symbol>',
    );
  if (sym && !document.getElementById("i-pals"))
    sym.insertAdjacentHTML(
      "beforeend",
      '<symbol id="i-pals" viewBox="0 0 24 24">' +
        '<circle cx="9" cy="8" r="3.7"/>' +
        '<path d="M2.6 20c.5-4 3-6.1 6.4-6.1 3.4 0 5.9 2.1 6.4 6.1z"/>' +
        '<circle cx="17" cy="9.4" r="2.9"/>' +
        '<path d="M15.6 14.2c3 .1 5.2 1.9 5.8 5.8h-5.9c-.3-2.3-1.1-4.2-2.4-5.5.8-.2 1.6-.3 2.5-.3z"/>' +
        "</symbol>",
    );
  const TABS = [
    ["wave", "mwave", "Моя волна"],
    ["home", "notes", "Что послушать"],
    ["pals", "pals", "Друзья и комнаты"],
    ["collection", "library", "Коллекция"],
  ];
  const tabs = document.createElement("nav");
  tabs.id = "m-tabs";
  tabs.innerHTML = TABS.map(([k, i, t]) => `<button data-m-tab="${k}" aria-label="${t}">${ico(i)}<span>${t}</span></button>`).join("");
  // 4.20: every skin is its own interface — Spotify names the tabs like the Spotify app (the labels show only there)
  const SP_TABS = { wave: "Моя волна", home: "Главная", pals: "Друзья и комнаты", collection: "Медиатека" };
  const skinOf = () => document.documentElement.dataset.skin || "wave";
  body.appendChild(tabs);
  const ROOTS = new Set(["wave", "home", "pals", "friends", "listen", "account", "collection"]);
  const head = document.createElement("header");
  head.id = "m-head";
  head.innerHTML =
    `<button class="m-hb" id="m-left" aria-label="Профиль">${ico("user")}</button>` +
    `<div class="m-ht" id="m-title"></div>` +
    `<button class="m-hb" id="m-search" aria-label="Поиск">${ico("search")}</button>`;
  ($(".main") || body).appendChild(head);
  $("#m-left").addEventListener("click", () => {
    if (!hasS()) return;
    if (S.route === "collection") go("settings");
    else if (ROOTS.has(S.route)) go("profile");
    else if (typeof navBack === "function" && S.back.length) navBack();
    else go("wave");
  });
  $("#m-search").addEventListener("click", () => hasS() && go("search"));
  const TITLES = {
    // before the first track the logo, while music plays «Моя волна» (CSS switches them by body.m-started)
    wave: `<span class="m-logo"><img src="assets/logo.png" data-logo alt=""><b>Wave</b></span><b class="m-mw">Моя волна</b>`,
    collection: `<b>Коллекция</b><small>Вся ваша музыка — <em>без цензуры</em></small>`,
    pals: "<b>Друзья и комнаты</b>",
    friends: "<b>Друзья</b>",
    listen: "<b>Слушать вместе</b>",
    account: "<b>Настройки</b>",
    "collection:pl": "<b>Плейлисты</b>",
    "collection:al": "<b>Альбомы</b>",
    "collection:mix": "<b>Микс</b>",
  };
  function syncHead() {
    const r = (hasS() && S.route) || "";
    const root = ROOTS.has(r);
    // «Коллекция»: the gear (settings); the other tabs: the profile; deeper pages: back
    const gear = r === "collection";
    $("#m-left").innerHTML = ico(gear ? "settings" : root ? "user" : "left");
    $("#m-left").setAttribute("aria-label", gear ? "Настройки" : root ? "Профиль" : "Назад");
    const sk = skinOf();
    let title = TITLES[r] || "";
    // Yandex: «Моя волна» on top, «Коллекция» without the Wave slogan; Spotify: no logo, «Медиатека»
    if (r === "wave" && sk === "yandex") title = '<b class="m-mw m-mw-ym">Моя волна</b>';
    if (r === "wave" && sk === "spotify") title = "";
    if (r === "collection" && sk !== "wave") title = `<b>${sk === "spotify" ? "Медиатека" : "Коллекция"}</b>`;
    $("#m-title").innerHTML = title;
    for (const b of $$("#m-tabs button")) {
      const t = TABS.find((x) => x[0] === b.dataset.mTab);
      const sp = b.querySelector("span");
      if (t && sp) sp.textContent = sk === "spotify" ? SP_TABS[t[0]] : t[2];
    }
    // 4.20: the header logo follows the accent colour like the other logos
    const lg = $("#m-title img[data-logo]");
    if (lg && typeof LOGO !== "undefined" && LOGO.url) lg.src = LOGO.url;
    head.classList.toggle("on-wave", r === "wave");
  }
  const contentEl = $("#content");
  contentEl && contentEl.addEventListener("scroll", () => head.classList.toggle("solid", contentEl.scrollTop > 24), { passive: true });
  // the dimming goes inside .app, right under the side panel: .app is its own stacking context (z-index of the PC
  // styles), so a scrim outside of it covered the panel too
  const scrim = document.createElement("div");
  scrim.id = "m-scrim";
  ($("#app") || body).appendChild(scrim);
  const drawer = (on) => body.classList.toggle("m-drawer", on);
  scrim.addEventListener("click", () => drawer(false));
  tabs.addEventListener("click", (e) => {
    const b = e.target.closest("[data-m-tab]");
    if (!b) return;
    const k = b.dataset.mTab;
    drawer(false);
    closeOverlays();
    // no focus left on the tab after a tap (the WebView would draw its focus rectangle around it)
    b.blur();
    if (typeof go === "function") go(k === "pals" && window.WaveSocial ? "friends" : k);
  });
  // any navigation from the drawer closes it
  document.addEventListener(
    "click",
    (e) => {
      if (body.classList.contains("m-drawer") && e.target.closest(".sidebar [data-go], .sidebar .pin, .sidebar a, .sidebar .side-pins button"))
        setTimeout(() => drawer(false), 60);
    },
    true,
  );
  const routeTab = (r) => {
    r = String(r || "");
    if (r === "wave") return "wave";
    if (r === "home" || r.startsWith("ym") || r.startsWith("chart") || r.startsWith("cat") || r === "history") return "home";
    if (r === "pals" || r === "friends" || r === "listen" || r === "account" || r.startsWith("people")) return "pals";
    if (
      r.startsWith("collection") ||
      r === "likes" ||
      r.startsWith("playlist") ||
      r.startsWith("mix") ||
      r === "favartists" ||
      r === "books" ||
      r === "offline"
    )
      return "collection";
    return "";
  };
  let lastRoute = null;
  function syncTabs() {
    const r = hasS() && S.route;
    if (r === lastRoute) return;
    lastRoute = r;
    const t = routeTab(r);
    for (const b of $$("#m-tabs button")) b.classList.toggle("on", b.dataset.mTab === t);
    syncHead();
  }
  setInterval(syncTabs, 250);
  new MutationObserver(() => syncHead()).observe(document.documentElement, { attributes: true, attributeFilter: ["data-skin"] });

  /* ---------- overlays the Android «Назад» closes first ---------- */
  function closeOverlays() {
    const menu = $("#menu");
    if (menu && !menu.hidden) {
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      menu.hidden = true;
      return true;
    }
    return false;
  }
  function escape() {
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
  }
  const visible = (el) => el && !el.hidden && getComputedStyle(el).display !== "none";
  window.waveBack = () => {
    if (body.classList.contains("m-drawer")) return drawer(false), true;
    const menu = $("#menu");
    if (visible(menu)) return escape(), (menu.hidden = true), true;
    const dlg = $("#dialog");
    if (dlg && dlg.open) return dlg.close(), true;
    const snd = $("#sndp");
    if (snd && visible(snd) && typeof closeSound === "function") return closeSound(), true;
    if ($(".clipbox") && typeof closeClip === "function") return closeClip(), true;
    if ($(".lbox") && typeof closeLightbox === "function") return closeLightbox(), true;
    const tp = $("#tpanel.on");
    if (tp && visible(tp) && typeof closeTrackPanel === "function") return closeTrackPanel(), true;
    const ly = $("#lyrics");
    if (visible(ly)) return $('#lyrics [data-cmd="lyrics"]')?.click(), true;
    const fp = $("#fullplayer");
    if (visible(fp) && typeof closeFull === "function") return closeFull(), true;
    const q = $("#queue");
    if (visible(q)) return $("#queue-close")?.click(), true;
    if (typeof navBack === "function" && !$("#back")?.disabled) return navBack(), true;
    if (hasS() && S.route !== "wave" && typeof go === "function") return go("wave"), true;
    return false;
  };

  /* ---------- long press = right click ---------- */
  let lp = null;
  document.addEventListener(
    "touchstart",
    (e) => {
      if (e.touches.length !== 1) return;
      const t = e.touches[0];
      const target = e.target;
      clearTimeout(lp?.timer);
      if (target.closest("[data-seek],[data-vol],input[type=range],#ly-text")) { lp = null; return; }
      lp = {
        x: t.clientX,
        y: t.clientY,
        fired: false,
        timer: setTimeout(() => {
          lp.fired = true;
          if (navigator.vibrate) navigator.vibrate(12);
          target.dispatchEvent(
            new MouseEvent("contextmenu", { bubbles: true, cancelable: true, clientX: lp.x, clientY: lp.y, button: 2 }),
          );
        }, 520),
      };
    },
    { passive: true },
  );
  document.addEventListener(
    "touchmove",
    (e) => {
      if (!lp) return;
      const t = e.touches[0];
      if (Math.hypot(t.clientX - lp.x, t.clientY - lp.y) > 10) clearTimeout(lp.timer);
    },
    { passive: true },
  );
  document.addEventListener("touchend", (e) => {
    if (!lp) return;
    clearTimeout(lp.timer);
    // the click after a long press must not also open / play the row
    if (lp.fired) {
      e.preventDefault();
      const stop = (ev) => {
        ev.stopPropagation();
        ev.preventDefault();
      };
      document.addEventListener("click", stop, { capture: true, once: true });
      setTimeout(() => document.removeEventListener("click", stop, true), 400);
    }
    lp = null;
  });
  document.addEventListener("touchcancel", () => lp && clearTimeout(lp.timer));

  /* A tap on a mobile track row starts playback. Artist links and actions keep their own handlers. */
  document.addEventListener("click", (e) => {
    const row = e.target.closest(".tr[data-l]");
    if (!row || !hasS() || e.target.closest("[data-act], [data-artist], input, .drag")) return;
    const list = S.lists && S.lists[row.dataset.l], i = +row.dataset.i, t = list && list[i];
    if (!t) return;
    e.stopPropagation(); e.preventDefault();
    if (S.current?.id === t.id) {
      if (audio.paused || S.pendingResume) togglePlay();
    } else if (row.dataset.l === "q") playAt(i);
    else playFromRow(list, i, row.dataset.l);
  }, true);

  // …so the track panel («О треке») gets its own item in the track menu
  if (typeof trackMenu === "function" && typeof openTrackPanel === "function") {
    const orig = trackMenu;
    window.trackMenu = function (e, t, ...rest) {
      const r = orig.call(this, e, t, ...rest);
      const m = document.getElementById("menu");
      if (m && !m.hidden && t && !m.querySelector(".m-info")) {
        const b = document.createElement("button");
        b.className = "m-info";
        b.innerHTML = `${ico("info")}<span class="mi-l">О треке</span>`;
        const row = e.target?.closest?.(".tr[data-l]");
        const ctx = row ? { list: S.lists?.[row.dataset.l], i: +row.dataset.i, lid: row.dataset.l } : {};
        b.onclick = () => {
          m.hidden = true;
          openTrackPanel(t, ctx);
        };
        m.insertBefore(b, m.firstChild);
      }
      return r;
    };
  }

  /* ---------- the sound panel: the equalizer curve is measured from the slider positions — measured while the panel
     still slides in (scaled by its animation) it came out tiny and was stretched across the whole panel. It is drawn
     again once the panel stands still, and whenever the screen size changes. ---------- */
  if (typeof openSound === "function" && typeof drawCurve === "function") {
    const origOpen = openSound;
    window.openSound = function (...a) {
      const r = origOpen.apply(this, a);
      for (const ms of [60, 260, 520, 900]) setTimeout(() => drawCurve(), ms);
      return r;
    };
    addEventListener("resize", () => setTimeout(() => drawCurve(), 120));
    document.addEventListener(
      "animationend",
      (e) => e.target && e.target.id === "sndp" && drawCurve(),
      true,
    );
    document.addEventListener(
      "transitionend",
      (e) => e.target && e.target.id === "sndp" && drawCurve(),
      true,
    );
  }

  /* ---------- «Моя волна»: a tap on the cover opens the full player (text, equalizer, queue…); the artist name keeps
     opening the artist ---------- */
  document.addEventListener(
    "click",
    (e) => {
      const c = e.target.closest("#wv-now .wv-cover, #wv-now .wpill");
      if (!c || !hasS() || !S.current || typeof openFull !== "function") return;
      if (Date.now() < swipeUntil) { e.preventDefault(); e.stopImmediatePropagation(); return; }
      e.stopPropagation();
      e.preventDefault();
      openFull();
    },
    true,
  );

  /* ---------- sound: straight from the <audio> element unless something needs Web Audio ----------
     Through Web Audio (MediaElementSource → equalizer → limiter) Android WebView crackles and stutters whenever the
     page is busy drawing. The PC interface plays elements without CORS directly anyway (AX.failed / noCorsHosts) —
     here that path is the normal one, and the graph is used only while the equalizer is on, a «Микс» plays or the
     wave reacts to the music. Turning the equalizer on restarts the track at the same second through the graph. */
  const needGraph = () => {
    try {
      const fx = (S.settings && S.settings.waveFx) || {};
      return !!(SND.eq.on || (typeof mixCfg === "function" && mixCfg()) || +fx.react > 0 || +fx.shake > 0);
    } catch {
      return false;
    }
  };
  let lastGraphWant = null;
  setInterval(() => {
    if (!hasS() || typeof AX === "undefined" || typeof SND === "undefined") return;
    const want = needGraph();
    if (want === lastGraphWant || seekDrag != null || audio.seeking || (manualSeek.id === S.current?.id && Date.now() < manualSeek.until)) return;
    lastGraphWant = want;
    if (AX.failed === !want) return;
    AX.failed = !want;
    const a = el();
    if (want && S.current && a && !a.hasAttribute("crossorigin") && !a.paused && typeof playAt === "function") {
      S.startAt = { id: S.current.id, t: a.currentTime };
      playAt(S.index);
    }
  }, 700);

  // the sound panel of the PC says «Обработка звука недоступна… эквалайзер не работает» whenever the sound bypasses
  // Web Audio — here that is a choice, not a failure: with the equalizer off the note is not shown (turning it on
  // switches the track to the graph, see above)
  if (typeof sndNote === "function") {
    const origNote = sndNote;
    window.sndNote = function (...a) {
      const r = origNote.apply(this, a);
      const n = document.querySelector("#sndp #snd-note");
      if (n && typeof SND !== "undefined" && !needGraph()) n.hidden = true;
      return r;
    };
  }

  /* ---------- nothing in the player yet: no mini player ---------- */
  setInterval(() => body.classList.toggle("m-nocur", !(hasS() && S.current)), 300);

  /* ---------- «Коллекция» of the phone: «Мне нравится» with its first tracks, «Ещё у вас в Коллекции» (playlists,
     albums, the «Микс», books and podcasts, history) and the favourite artists. The lists open as sub-pages
     collection:pl / collection:al / collection:mix — the same cards and dialogs as on the PC. ---------- */
  if (typeof gCollection === "function") {
    const coverOf = (list) => (list.find((p) => p.cover) || {}).cover || "";
    const names = (list) =>
      list
        .slice(0, 3)
        .map((p) => p.title)
        .join(", ");
    /* 4.20.1: every tile of «Коллекция» can have its own cover (long press → «Выбрать обложку…») */
    const tileKey = (go) => String(go).replace(/^collection:/, "c:");
    const mTile = (go, cover, iconId, title, sub) => {
      const own = S.tileCovers?.[tileKey(go)];
      if (own) cover = own;
      return `<button class="m-tile" data-go="${go}" data-tile="${esc(tileKey(go))}"><span class="m-tc${cover ? "" : " ic"}${own ? " own" : ""}" ${cover ? lbg(cover, "s") : ""}>${
        cover ? "" : icon(iconId)
      }</span><span class="m-tt"><b>${esc(title)}</b>${sub ? `<small>${esc(sub)}</small>` : ""}</span></button>`;
    };
    if (!S.tileCovers) {
      S.tileCovers = {};
      api("tile-covers").then((c) => {
        S.tileCovers = c || {};
        if (Object.keys(S.tileCovers).length && String(S.route || "") === "collection") reroute();
      }).catch(() => {});
    }
    document.addEventListener("contextmenu", (e) => {
      const tile = e.target.closest(".m-coll .m-tile[data-tile]");
      if (!tile) return;
      e.preventDefault();
      e.stopPropagation();
      const k = tile.dataset.tile;
      const pick = async (remove) => {
        try {
          const url = await api("playlist-cover", { id: "tile:" + k, remove });
          if (remove || url) {
            if (url) S.tileCovers[k] = url;
            else delete S.tileCovers[k];
            reroute();
            if (!remove) toast("Обложка обновлена", 1800);
          }
        } catch (err) {
          toast(err.message);
        }
      };
      const items = [["Выбрать обложку…", "image", () => pick(false)]];
      if (S.tileCovers[k]) items.push(["Вернуть стандартную обложку", "close", () => pick(true)]);
      menu(e, items);
    }, true);
    window.gCollection = function () {
      if (!S.settings.ymToken) S.ymTop = null;
      const sub = String(S.route || "").split(":")[1] || "";
      const mine = S.playlists.filter((p) => !p.source && p.kind !== "album");
      const liked = S.playlists.filter((p) => p.source && p.kind !== "album");
      const albums = S.playlists.filter((p) => p.kind === "album");
      if (sub === "pl") {
        setContent(`<div class="grid m-sub">${newPlCard()}${[...mine, ...liked].map(plCard).join("")}</div>`);
        const nb = $("#c-new");
        if (nb) nb.onclick = () => newPlaylistDialog();
        return lazyScan();
      }
      if (sub === "al") {
        setContent(
          albums.length
            ? `<div class="grid m-sub">${albums.map(plCard).join("")}</div>`
            : '<div class="empty"><b>Нет сохранённых альбомов</b>Откройте любой альбом и нажмите «В коллекцию»</div>',
        );
        return lazyScan();
      }
      if (sub === "mix") {
        setContent(`<div class="mx-tab m-sub">${mixCardsHtml()}</div>`);
        return lazyScan();
      }
      const lid = reg(S.likes);
      const prev = S.likes.slice(0, 3);
      const arts = favArtists();
      const lc = S.likesCover;
      setContent(`<div class="m-coll">
        <button class="m-likes" data-go="likes"><span class="m-heart" ${lc ? lbg(lc, "s") : ""}>${lc ? "" : icon("heart")}</span>
          <span class="m-lt"><b>${isSpotify() ? "Любимые треки" : "Мне нравится"}<i>›</i></b><small>${plural(S.likes.length, "трек", "трека", "треков")}</small></span></button>
        ${prev.length ? `<div class="tracks m-ltracks">${prev.map((t, i) => trackRow(t, lid, i)).join("")}</div>` : '<p class="m-hint">Нажмите ♡ у трека — он появится здесь</p>'}
        <h2 class="m-h2">Ещё у вас в Коллекции</h2>
        <div class="m-tiles">
          ${mTile("collection:pl", coverOf([...mine, ...liked]), "list", "Плейлисты", names([...mine, ...liked]) || "Создать плейлист")}
          ${mTile("collection:al", "", "album", "Альбомы", names(albums))}
          ${mTile("mix:@all", "", "mix", "Микс", "Переходы между треками")}
          ${mTile("history", "", "hist", "История", "")}
          ${mTile("concerts", "", "ticket", "Концерты", "Афиша и билеты")}
          ${mTile("offline", "", "dl", "Скачанное", "Треки без интернета")}
        </div>
        ${
          arts.length || S.settings.ymToken
            ? `<section class="section" id="fav-sec"${arts.length || S.ymTop?.length ? "" : " hidden"}><div class="sec-head"><h2><button data-go="favartists">Любимые исполнители<i class="arr">›</i></button></h2></div><div class="ytop${S.ymTop?.length ? " ym" : ""}" id="fav-arts">${topArtistsHtml(S.ymTop?.length ? S.ymTop : localTop())}</div></section>`
            : ""
        }
      </div>`);
      if (arts.length && !S.ymTop?.length) loadAvatars(arts.slice(0, TOP_N));
      loadTopArtists();
      lazyScan();
    };
  }

  /* ---------- «Что послушать»: «Вы недавно слушали» — two small tiles («Мне нравится · N треков», «История») and the
     recently played tracks under them (on the PC: a big «Мне нравится» card next to two columns of tracks) ---------- */
  if (typeof likesHistoryBlock === "function") {
    window.likesHistoryBlock = function () {
      const recent = S.history.slice(0, 5);
      if (!S.likes.length && !recent.length) return "";
      const lid = reg(recent);
      const lc = S.likesCover;
      return `<section class="section m-lh">
        <div class="m-lh-tiles">
          <button class="m-lht" data-go="likes"><span class="m-lhi likes" ${lc ? lbg(lc, "s") : ""}>${lc ? "" : icon("heart")}</span>
            <span class="m-lhx"><b>Мне нравится</b><small>${plural(S.likes.length, "трек", "трека", "треков")}</small></span></button>
          <button class="m-lht" data-go="history"><span class="m-lhi hist">${icon("hist")}</span>
            <span class="m-lhx"><b>История</b><small>${plural(S.history.length, "трек", "трека", "треков")}</small></span></button>
        </div>
        ${
          recent.length
            ? `<div class="sec-head"><h2><button data-go="history">Вы недавно слушали<i class="arr">›</i></button></h2></div><div class="tracks">${recent.map((t, i) => trackRow(t, lid, i)).join("")}</div>`
            : ""
        }
      </section>`;
    };
  }

  /* ---------- the profile page: «Редактировать» → «Настройки» (it opens the settings) ---------- */
  if (typeof profile === "function") {
    const origProfile = profile;
    window.profile = function (...a) {
      const r = origProfile.apply(this, a);
      const b = document.querySelector('.phead .btn[data-go="settings"]');
      if (b) b.innerHTML = `${ico("settings")}Настройки`;
      return r;
    };
  }

  /* Mini-player: artwork and title follow the finger; controls and seek rail stay fixed. */
  let miniSwipe = null, miniSwipeClickUntil = 0, miniPending = null, miniTransition = false;
  let miniAnimations = [];
  const mini = $("#player");
  const miniParts = () => [$("#pl-cover"), $("#player .pl-meta")].filter(Boolean);
  const miniMotion = () => hasS() && S.settings?.animation !== false && !body.classList.contains("no-anim") &&
    !matchMedia("(prefers-reduced-motion: reduce)").matches;
  const miniStopAnimations = () => { for (const a of miniAnimations) a.cancel(); miniAnimations = []; };
  const miniPaint = (x) => {
    for (const el of miniParts()) {
      el.style.transform = x ? `translate3d(${x}px, 0, 0)` : "";
      el.style.opacity = x ? String(Math.max(.4, 1 - Math.abs(x) / 240)) : "";
    }
  };
  const miniReturn = () => {
    const els = miniParts();
    const old = els.map(el => ({transform:el.style.transform || "translate3d(0, 0, 0)", opacity:el.style.opacity || "1"}));
    miniPaint(0); miniStopAnimations();
    if (miniMotion()) miniAnimations = els.filter(el => el.animate).map((el,i) => el.animate(
      [old[i], {transform:"translate3d(0, 0, 0)", opacity:1}],
      {duration:200, easing:"cubic-bezier(.2,.8,.2,1)"}));
  };
  const miniTrackUpdated = (track) => {
    if (!miniPending || !track || (track.id === miniPending.id && S.index === miniPending.index)) return;
    const dir = miniPending.dir; miniPending = null;
    if (!mini || !mini.getClientRects().length || !miniMotion()) return;
    miniPaint(0); miniStopAnimations();
    miniAnimations = miniParts().filter(el => el.animate).map(el => el.animate(
      [{transform:`translate3d(${-dir * 70}px, 0, 0)`,opacity:.4}, {transform:"translate3d(0, 0, 0)",opacity:1}],
      {duration:260,easing:"cubic-bezier(.18,.8,.2,1)"}));
  };
  if (mini) {
    mini.addEventListener("touchstart", (e) => {
      const t = e.touches[0], seek = e.target.closest("[data-seek]");
      const r = seek?.getBoundingClientRect();
      const insideSeek = r && t && t.clientX >= r.left && t.clientX <= r.right && t.clientY >= r.top && t.clientY <= r.bottom;
      if (e.touches.length !== 1 || insideSeek || e.target.closest("[data-vol],input,select,textarea") ||
          !hasS() || !S.current || miniTransition) { if (miniSwipe) miniReturn(); miniSwipe = null; return; }
      miniStopAnimations(); miniPaint(0);
      miniSwipe = {x:t.clientX,y:t.clientY,t:Date.now(),id:S.current.id,index:S.index,moving:false};
    }, {passive:true});
    mini.addEventListener("touchmove", (e) => {
      if (!miniSwipe) return;
      if (e.touches.length !== 1) { miniSwipe = null; miniReturn(); return; }
      const dx = e.touches[0].clientX - miniSwipe.x, dy = e.touches[0].clientY - miniSwipe.y;
      if (Math.abs(dx) > 10 && Math.abs(dx) > Math.abs(dy) * 1.4) {
        miniSwipe.moving = true;
        if (e.cancelable) e.preventDefault();
        if (miniMotion()) miniPaint(Math.max(-110, Math.min(110, dx)));
      }
    }, {passive:false});
    mini.addEventListener("touchend", (e) => {
      if (!miniSwipe || !e.changedTouches.length) { miniSwipe = null; return; }
      const start = miniSwipe, touch = e.changedTouches[0]; miniSwipe = null;
      const dx = touch.clientX - start.x, dy = touch.clientY - start.y;
      if (Date.now() - start.t >= 1200 || Math.abs(dx) < 55 || Math.abs(dx) < Math.abs(dy) * 1.4 ||
          S.current?.id !== start.id || S.index !== start.index) { miniReturn(); return; }
      if (e.cancelable) e.preventDefault();
      miniSwipeClickUntil = Date.now() + 500;
      const dir = dx < 0 ? -1 : 1;
      if (dir > 0 && S.index <= 0) { miniReturn(); toast("Предыдущего трека в очереди нет",1800); return; }
      if (dir < 0 && S.index >= S.queue.length - 1 && S.repeat !== "all" && !S.wave) {
        miniReturn(); toast("Следующего трека в очереди нет",1800); return;
      }
      const switchTrack = () => {
        miniTransition = false; miniPaint(0); miniStopAnimations();
        if (!S.current || S.current.id !== start.id || S.index !== start.index || !mini.getClientRects().length) return;
        const pending = miniPending = {id:start.id,index:start.index,dir};
        setTimeout(() => { if (miniPending === pending) miniPending = null; }, 10000);
        if (dir < 0) next(); else playAt(S.index - 1);
      };
      if (!miniMotion()) return switchTrack();
      miniTransition = true;
      const els = miniParts(), current = els.map(el => ({transform:el.style.transform || "translate3d(0, 0, 0)",opacity:el.style.opacity || "1"}));
      miniPaint(0); miniStopAnimations();
      miniAnimations = els.filter(el => el.animate).map((el,i) => el.animate(
        [current[i],{transform:`translate3d(${dir * 140}px, 0, 0)`,opacity:0}],
        {duration:140,easing:"cubic-bezier(.4,0,1,1)",fill:"forwards"}));
      setTimeout(switchTrack,140);
    }, {passive:false});
    mini.addEventListener("touchcancel", () => { miniSwipe = null; miniReturn(); }, {passive:true});
    document.addEventListener("click", (e) => {
      if (Date.now() < miniSwipeClickUntil && e.target.closest("#player")) {
        e.preventDefault(); e.stopImmediatePropagation();
      }
    }, true);
  }

  /* ---------- the mini player: a tap opens the full player ---------- */
  document.addEventListener("click", (e) => {
    const pl = e.target.closest("#player");
    if (!pl || e.target.closest("button, [data-cmd], [data-seek]")) return;
    if (typeof openFull === "function" && hasS() && S.current) {
      e.preventDefault(); e.stopPropagation(); openFull();
    }
  }, true);

  /* ---------- the full player «Обложка»: the controls under the cover (on the PC they appear on hover) ---------- */
  function addFullControls() {
    const c = $("#fullplayer .fpa-center");
    if (!c || $(".m-fpctl", c)) return;
    const box = document.createElement("div");
    box.className = "m-fpctl";
    box.innerHTML =
      `<div class="m-row m-main"><button data-cmd="dislike" title="Не рекомендовать" aria-label="Не рекомендовать">${ico("dislike")}</button>` +
      `<button data-cmd="prev">${ico("prev")}</button><button class="m-play" data-cmd="play">${ico("play")}</button>` +
      `<button data-cmd="next">${ico("next")}</button><button data-cmd="like" title="Нравится" aria-label="Нравится">${ico("heart-o")}</button></div>` +
      `<div class="m-row m-sub"><button data-cmd="shuffle" title="Перемешать">${ico("shuffle")}</button>` +
      `<button data-cmd="lyrics" title="Текст песни">${ico("lyrics")}</button>` +
      `<button data-cmd="queue" title="Очередь">${ico("list")}</button>` +
      `<button data-cmd="cur-menu" title="Ещё" aria-label="Ещё">${ico("more")}</button>` +
      `<button data-cmd="sound" title="Настройки звука">${ico("eq")}</button>` +
      `<button data-cmd="repeat" title="Повтор">${ico("repeat")}<i class="one">1</i></button></div>`;
    c.appendChild(box);
    if (typeof setPlayIcons === "function") setPlayIcons();
    if (typeof syncModes === "function") syncModes();
    if (typeof refreshLikeButtons === "function") refreshLikeButtons();
  }
  addFullControls();
  // Keep the queue independent of the chosen player variant (it was hidden inside .fpa).
  const mobileQueue = $("#fpq"), mobilePlayer = $("#fullplayer");
  if (mobileQueue && mobilePlayer && mobileQueue.parentElement !== mobilePlayer) mobilePlayer.appendChild(mobileQueue);

  /* ---------- «Моя волна»: the presets of the wheel as a horizontal strip under the stage ----------
     The wheel of the PC is a vertical loop made for the mouse wheel; the strip shows the same items (WAVE_ITEMS,
     same icons and marks) and runs the same actions. A long press opens the menu of the preset pill on top. */
  const WCOPIES = 9, WMID = 4;
  let stripSig = "", stripFrame = 0, stripTimer = 0, stripPrev = new Set(), stripSelection = null, wheelGeometry = null;
  function dropHue(x) {
    const key = String(x.k || "").toLowerCase();
    if (/likes|love/.test(key)) return 347;
    if (/sad/.test(key)) return 184;
    if (/rap/.test(key)) return 165;
    if (/road/.test(key)) return 128;
    if (/dream|sleep|calm/.test(key)) return 321;
    const c = x.color || x.c?.[1] || "";
    if (/^#[0-9a-f]{6}$/i.test(c)) {
      const r = parseInt(c.slice(1,3),16)/255, g = parseInt(c.slice(3,5),16)/255, b = parseInt(c.slice(5,7),16)/255;
      const hi = Math.max(r,g,b), lo = Math.min(r,g,b), d = hi-lo;
      if (d > .08) return Math.round(60*(hi===r ? (g-b)/d+(g<b?6:0) : hi===g ? (b-r)/d+2 : (r-g)/d+4));
    }
    let h = 0; for (const c of key) h = (h*31+c.charCodeAt(0)) >>> 0;
    return [24, 337, 182, 32, 273, 212, 133][h%7];
  }
  // Geometry is read together, never between style writes during a scroll frame.
  function measureWheel(strip) {
    if (!strip.isConnected || strip.children.length < 2) return wheelGeometry = null;
    const children = strip.children;
    return wheelGeometry = { strip, step: children[1].offsetLeft - children[0].offsetLeft,
      base: children[0].offsetLeft, itemWidth: children[0].offsetWidth, width: strip.clientWidth };
  }
  function paintWheel(strip, virtualLeft) {
    stripFrame = 0;
    const g = wheelGeometry && wheelGeometry.strip === strip ? wheelGeometry : measureWheel(strip);
    if (!g || g.step <= 0 || !strip.isConnected) return;
    const children = strip.children, left = virtualLeft == null ? strip.scrollLeft : virtualLeft;
    const center = left + g.width / 2;
    const first = Math.max(0, Math.floor((left-g.base)/g.step)-2);
    const last = Math.min(children.length-1, Math.ceil((left + g.width-g.base)/g.step)+2);
    const reduced = S.settings?.animation === false || matchMedia("(prefers-reduced-motion: reduce)").matches;
    // 4.20: every skin moves its cards its own way — «Яндекс Музыка» the arc of drops, «Wave» a running wave
    // (the cards ride a sine that flows while scrolling, tilted along its slope), «Spotify» a flat row
    const skin = document.documentElement.dataset.skin;
    const active = new Set();
    for (let i=first; i<=last; i++) {
      const el=children[i]; active.add(el);
      const dist=Math.max(-1.6,Math.min(1.6,(g.base+i*g.step+g.itemWidth/2-center)/(g.width*.48)));
      const a=reduced ? 0 : Math.min(1,Math.abs(dist));
      if (!stripPrev.has(el)) el.style.willChange="transform";
      let tf;
      if (skin === "spotify") tf = "none";
      else if (skin === "wave") {
        const ph = (g.base + i*g.step + g.itemWidth/2) / g.width * Math.PI * 1.15 - left / g.width * Math.PI * 1.15;
        const y = reduced ? 0 : Math.sin(ph) * 16, tilt = reduced ? 0 : Math.cos(ph) * 7;
        tf = `translate3d(0,${y.toFixed(1)}px,0) scale(${(1-a*.08).toFixed(3)}) rotate(${tilt.toFixed(2)}deg)`;
      } else tf = `translate3d(0,${(a*a*27).toFixed(1)}px,0) scale(${(1-a*.14).toFixed(3)}) rotate(${(reduced ? 0 : dist*3).toFixed(2)}deg)`;
      el.style.setProperty("transform", tf, "important");
    }
    for (const el of stripPrev) if (!active.has(el)) {
      el.style.removeProperty("transform"); el.style.removeProperty("will-change");
    }
    stripPrev=active;
  }
  const requestWheelPaint = (strip) => { if (!stripFrame) stripFrame=requestAnimationFrame(()=>paintWheel(strip)); };
  /* 4.20: «Spotify» and «Wave» show the presets as covers — a square tile (Spotify) or a circle (Wave) with the cover
     of a track the preset is going to play. «Назад к привычному» and «Настроить Мою волну» stay only in «Яндекс». */
  const coverSkin = () => { const k = document.documentElement.dataset.skin || "wave"; return k === "spotify" || k === "wave"; };
  const stripList = () => coverSkin() ? WAVE_ITEMS.filter((x) => x.k !== "back" && x.k !== "tune") : WAVE_ITEMS;
  const CV_KEY = "wave.stripCovers.v2", CV_TTL = 6 * 3600e3;
  let cvMap = {};
  try { cvMap = JSON.parse(localStorage.getItem(CV_KEY) || "{}") || {}; } catch { cvMap = {}; }
  const cvQueue = [], cvAsked = new Set();
  let cvBusy = false;
  const presetOpts = (x) => {
    if (x.seed) return { seed: x.seed };
    if (x.mood && !x.genre) return x.station && S.settings?.ymToken ? { mood: x.mood, station: x.station } : { mood: x.mood };
    if (x.station || x.genre) return { station: x.station || null, genre: x.genre || null };
    return {};
  };
  // one picture = one card: the same album/track cover never shows on two presets
  const cvNorm = (u) => String(u || "").replace(/[?#].*$/, "").replace(/\/(\d+x\d+|%%|orig)$/, "").replace(/-(t\d+x\d+|large|crop|original|t500x500)(\.\w+)$/, "$2").replace(/^https?:/, "");
  const cvLive = () => new Set(WAVE_ITEMS.map((y) => y.k));
  function cvUsed(k) {
    const live = cvLive(), used = new Map();
    for (const y of WAVE_ITEMS) if (y.k !== k && y.img && !y.g) used.set(cvNorm(y.img), -1);
    for (const [k2, c] of Object.entries(cvMap)) if (k2 !== k && c.u && live.has(k2) && !used.has(cvNorm(c.u))) used.set(cvNorm(c.u), c.t);
    return used;
  }
  function cvDup(k, c) {
    const t = cvUsed(k).get(cvNorm(c.u));
    return t != null && t <= c.t;
  }
  function presetCover(x) {
    if (x.img && !x.g) return x.img;
    const c = cvMap[x.k];
    const dup = !!(c?.u && cvDup(x.k, c));
    if (c && !dup && Date.now() - c.t < (c.u ? CV_TTL : CV_TTL / 12)) return c.u;
    if (!cvAsked.has(x.k)) { cvAsked.add(x.k); cvQueue.push(x); pumpCovers(); }
    return dup ? "" : (c?.u || "");
  }
  async function pumpCovers() {
    if (cvBusy) return;
    cvBusy = true;
    window.mCoverQuiet = true;
    try {
      while (cvQueue.length) {
        const x = cvQueue.shift();
        const list = await api("wave", presetOpts(x)).catch(() => null);
        // every preset gets its own cover; a fallback list (the same familiar tracks) or a placeholder avatar → no cover
        const used = cvUsed(x.k);
        const pick = (l) => (l || []).find((t) => t.cover && !/default_avatar/.test(t.cover) && !used.has(cvNorm(t.cover)));
        let t = pick(list);
        // the wave gave only the shared fallback → a track found by the name of the preset
        if (!t && x.title) t = pick((await api("search", { q: x.title }).catch(() => null))?.tracks);
        if (!t) t = pick((await api("wave", presetOpts(x)).catch(() => null)));
        // never swap pictures under a moving finger — that is the stutter while scrolling
        for (let w = 0; w < 40 && document.getElementById("m-wstrip")?.dataset.busy === "1"; w++) await new Promise((r) => setTimeout(r, 250));
        cvMap[x.k] = { u: t ? t.cover : "", t: Date.now() };
        try { localStorage.setItem(CV_KEY, JSON.stringify(cvMap)); } catch {}
        if (!t) {
          for (const el of $$(`#m-wstrip [data-k="${CSS.escape(x.k)}"] .m-cv-img`)) { el.style.backgroundImage = ""; el.classList.remove("has"); }
          continue;
        }
        for (const el of $$(`#m-wstrip [data-k="${CSS.escape(x.k)}"] .m-cv-img`)) {
          el.style.backgroundImage = `url("${t.cover}")`;
          el.classList.add("has");
        }
      }
    } finally { cvBusy = false; setTimeout(() => { if (!cvBusy) window.mCoverQuiet = false; }, 1500); }
  }
  const coverItemHtml = (x, i) => {
    const u = presetCover(x);
    const sub = x.k === "shake" ? "Что-то новое" : x.sub || (x.g ? "Моя волна" : "");
    return `<button class="m-cv${x.k === S.wavePreset ? " on" : ""}${x.round ? " art" : ""}" data-wi="${i}" data-k="${esc(x.k)}">`
      + `<span class="m-cv-img${u ? " has" : ""}"${u ? ` style="background-image:url(&quot;${esc(u)}&quot;)"` : ""}>${x.likes && !u ? icon("heart") : ""}</span>`
      + `<span class="m-cv-tx"><b>${esc(x.title)}</b>${sub ? `<small>${esc(sub)}</small>` : ""}</span></button>`;
  };
  function waveStrip() {
    const wv = $("#wv");
    if (!wv || typeof WAVE_ITEMS === "undefined") return;
    let strip=$("#m-wstrip",wv);
    if (!strip) {
      strip=document.createElement("div"); strip.id="m-wstrip";
      strip.setAttribute("aria-label","Подборки Моей волны"); wv.appendChild(strip);
      let touching=false, motionSuspended=false;
      const suspendBackground=()=>{
        if (motionSuspended) return;
        motionSuspended=true; document.body.classList.add("m-wheel-moving");
        if (typeof WaveFx !== "undefined") WaveFx.stop();
      };
      const resumeBackground=()=>{
        if (!motionSuspended) return;
        motionSuspended=false; document.body.classList.remove("m-wheel-moving");
        if (typeof WaveFx !== "undefined" && document.documentElement.dataset.waveEconomy !== "1") WaveFx.resume();
      };
      const settle=()=>{
        clearTimeout(stripTimer);
        stripTimer=setTimeout(()=>{
          if (touching) return;
          if (!strip.isConnected || strip.children.length<2) { resumeBackground(); return; }
          const g=wheelGeometry || measureWheel(strip), span=(g?.step||0)*(+strip.dataset.count||0);
          if (!span) { strip.dataset.busy="0"; resumeBackground(); return; }
          if (strip.scrollLeft < span*WMID || strip.scrollLeft >= span*(WMID+1)) {
            // Prepare the identical copy before the instantaneous wrap, avoiding one untransformed frame.
            const target=span*WMID+((strip.scrollLeft%span)+span)%span;
            paintWheel(strip,target);
            strip.scrollLeft=target;
          }
          strip.dataset.busy="0"; resumeBackground();
        },200);
      };
      strip.addEventListener("click",(e)=>{
        const b=e.target.closest("[data-wi]");
        if (b) WAVE_ITEMS.find(x=>x.k===b.dataset.k)?.act?.();
      });
      strip.addEventListener("touchstart",()=>{touching=true;strip.dataset.busy="1";suspendBackground();clearTimeout(stripTimer);},{passive:true});
      const end=()=>{touching=false;settle();};
      strip.addEventListener("touchend",end,{passive:true}); strip.addEventListener("touchcancel",end,{passive:true});
      strip.addEventListener("scroll",()=>{strip.dataset.busy="1";suspendBackground();requestWheelPaint(strip);if(!touching)settle();},{passive:true});
      stripSig=""; stripSelection=null; stripPrev=new Set(); wheelGeometry=null;
    }
    const ITEMS=stripList(), cov=coverSkin();
    const sig=(cov?"cv|":"")+ITEMS.map(x=>x.k+(x.pinned?"p":"")+(x.liked?"l":"")).join("|");
    if (sig===stripSig) {
      if (stripSelection!==S.wavePreset) {
        stripSelection=S.wavePreset;
        for (const el of strip.children) el.classList.toggle("on",el.dataset.k===stripSelection);
      }
      return;
    }
    // Do not rebuild cards or lose finger momentum while the strip is being used.
    if (strip.dataset.busy==="1") return;
    const oldCount=+strip.dataset.count||0;
    const oldStep=strip.children.length>1 ? strip.children[1].offsetLeft-strip.children[0].offsetLeft : 0;
    const oldPosition=oldCount&&oldStep ? ((strip.scrollLeft/oldStep)%oldCount) : null;
    stripSig=sig; stripSelection=S.wavePreset; strip.dataset.count=String(ITEMS.length);
    strip.classList.toggle("m-covers",cov);
    if (!ITEMS.length) {strip.replaceChildren();return;}
    // SVG gradient names must not collide with desktop wheel or another carousel copy.
    strip.innerHTML=Array.from({length:WCOPIES},(_,c)=>c).map(copy=>ITEMS.map((x,i)=>{
      if (cov) return coverItemHtml(x,i);
      const suffix=`-mob-${copy}-${i}`;
      return wheelItemHtml(x,i).replace(/id="(g[fsh][^"]+)"/g,(all,id)=>`id="${id}${suffix}"`)
        .replace(/url\(#(g[fsh][^)]+)\)/g,(all,id)=>`url(#${id}${suffix})`);
    }).join("")).join("");
    for (let i=0;i<strip.children.length;i++) {
      const el=strip.children[i], x=ITEMS[i%ITEMS.length];
      el.style.setProperty("--drop-hue",String(dropHue(x)));
      if (cov) el.style.setProperty("--i",String(Math.max(0,Math.min(8,i-ITEMS.length*WMID))));
      if (Math.floor(i/ITEMS.length)!==WMID) {el.setAttribute("aria-hidden","true");el.tabIndex=-1;}
    }
    if (strip.children.length<2) return;
    const g=measureWheel(strip), step=g.step, width=g.itemWidth;
    const active=Math.max(0,ITEMS.findIndex(x=>x.k===S.wavePreset));
    strip.scrollLeft=cov&&oldPosition==null ? strip.children[ITEMS.length*WMID].offsetLeft-strip.children[0].offsetLeft
      : step*(ITEMS.length*WMID+(oldPosition??active))-(oldPosition==null?Math.max(0,(strip.clientWidth-width)/2):0);
    stripPrev=new Set(); requestWheelPaint(strip);
  }
  addEventListener("resize",()=>{const strip=$("#m-wstrip");if(strip){measureWheel(strip);requestWheelPaint(strip);}},{passive:true});
  // another skin → the cards take its sizes and motion at once
  new MutationObserver(()=>{const strip=$("#m-wstrip");if(strip){requestAnimationFrame(()=>{measureWheel(strip);paintWheel(strip);});}})
    .observe(document.documentElement,{attributes:true,attributeFilter:["data-skin"]});
  setInterval(() => {
    if (!hasS() || S.route !== "wave") return;
    waveStrip();
  }, 400);
  // The cover and artist follow the finger; controls and seek bar stay fixed and usable.
  let sw = null, swipeUntil = 0, pendingSwipe = null, switchingSwipe = false;
  const motionOK = () => S.settings?.animation !== false && !body.classList.contains("no-anim") &&
    !matchMedia("(prefers-reduced-motion: reduce)").matches;
  const motionEls = () => [$("#wv-cover"), $("#wv-title")].filter(Boolean);
  let dragRaf = 0, dragX = 0;
  const dragPaint = (dx) => {
    if (!motionOK()) return;
    dragX = dx;
    if (dragRaf) return;
    dragRaf = requestAnimationFrame(() => {
      dragRaf = 0;
      const x = Math.max(-72, Math.min(72, dragX * 0.45));
      for (const el of motionEls()) {
        el.style.willChange = "translate, opacity";
        el.style.translate = `${x}px 0`;
        el.style.opacity = String(1 - Math.abs(x) / 320);
      }
    });
  };
  const resetDrag = (animate) => {
    cancelAnimationFrame(dragRaf);
    dragRaf = 0;
    for (const el of motionEls()) {
      el.style.willChange = "";
      const translate = el.style.translate || "0px 0px", opacity = el.style.opacity || "1";
      el.style.translate = ""; el.style.opacity = "";
      if (animate && motionOK() && el.animate) el.animate([{translate, opacity}, {translate:"0px 0px", opacity:1}], {duration:180,easing:"cubic-bezier(.2,.8,.2,1)"});
    }
  };
  if (typeof renderWaveNow === "function") {
    const originalRender = renderWaveNow;
    window.renderWaveNow = function (...args) {
      const result = originalRender.apply(this, args);
      const pill = $("#wv-now .wpill[data-seek]");
      if (pill) { pill.removeAttribute("data-seek"); pill.setAttribute("role", "button"); pill.setAttribute("aria-label", "Открыть плеер"); }
      if (pendingSwipe && S.current?.id !== pendingSwipe.id && S.route === "wave") {
        const dir = pendingSwipe.dir;
        pendingSwipe = null;
        if (motionOK()) for (const el of motionEls()) if (el.animate)
          el.animate([{translate:`${-dir * 35}px 0`,opacity:0.55},{translate:"0px 0px",opacity:1}], {duration:260,easing:"cubic-bezier(.18,.8,.24,1)"});
      }
      return result;
    };
  }
  document.addEventListener("touchstart", (e) => {
    const target = e.target, stage = target.closest("#wv-stage");
    const excluded = target.closest("[data-seek],[data-vol],input,select,textarea,a,#m-wstrip,.wpill");
    const button = target.closest("button"), okButton = !button || button.classList.contains("wv-cover");
    sw = stage && !excluded && okButton && !switchingSwipe && e.touches.length === 1 && hasS() && S.current && S.route === "wave"
      ? { x:e.touches[0].clientX, y:e.touches[0].clientY, t:Date.now(), id:S.current.id, moving:false } : null;
  }, { passive:true });
  document.addEventListener("touchmove", (e) => {
    if (!sw || e.touches.length !== 1) return;
    const dx=e.touches[0].clientX-sw.x, dy=e.touches[0].clientY-sw.y;
    if (Math.abs(dx)>10 && Math.abs(dx)>Math.abs(dy)*1.4) { sw.moving=true; dragPaint(dx); }
  }, {passive:true});
  document.addEventListener("touchend", (e) => {
    if (!sw || !e.changedTouches.length) { sw=null; return; }
    const t=e.changedTouches[0], dx=t.clientX-sw.x, dy=t.clientY-sw.y, initial=sw;
    sw=null;
    if (Date.now()-initial.t>=900 || Math.abs(dx)<55 || Math.abs(dx)<Math.abs(dy)*1.4 || initial.id!==S.current?.id) { resetDrag(true); return; }
    e.preventDefault(); swipeUntil=Date.now()+700;
    if (dx>0 && S.index<=0) { resetDrag(true); toast("Предыдущего трека в очереди нет",1800); return; }
    const dir=dx<0 ? -1 : 1;
    switchingSwipe=true;
    const goNext=() => {
      resetDrag(false);
      switchingSwipe=false;
      if (S.route !== "wave" || S.current?.id !== initial.id) return;
      pendingSwipe={id:initial.id,dir};
      setTimeout(() => { if (pendingSwipe?.id===initial.id) pendingSwipe=null; }, 10000);
      if (dir<0) next(); else playAt(S.index-1);
    };
    if (!motionOK()) return goNext();
    const outgoing = motionEls().filter(el => el.animate).map(el => el.animate([
      {translate:el.style.translate || "0px 0px",opacity:el.style.opacity || "1"},
      {translate:`${dir*60}px 0`,opacity:.55}
    ],{duration:120,easing:"ease-in",fill:"forwards"}));
    setTimeout(() => { for (const animation of outgoing) animation.cancel(); goNext(); },120);
  }, {passive:false});
  document.addEventListener("touchcancel", () => { sw=null; resetDrag(true); }, {passive:true});
  document.addEventListener("click", (e) => {
    if (Date.now()<swipeUntil && e.target.closest("#wv-stage")) { e.preventDefault(); e.stopImmediatePropagation(); }
  }, true);

  /* Swipe on the full-player cover: same queue rules as on the wave screen. */
  let fullSwipe=null, fullPending=null, fullGuard=0;
  const fullArt=()=>typeof fpArt === "function" ? fpArt() : null;
  const clearFullDrag=(animate)=>{
    const el=fullSwipe?.el;
    if (!el) return;
    const old=el.style.transform || "translateX(0)";
    el.style.transform=""; el.style.opacity="";
    if (animate && motionOK() && el.animate) el.animate([{transform:old},{transform:"translateX(0)"}],{duration:180,easing:"ease-out"});
  };
  if (typeof updateNow === "function") {
    const originalUpdateNow=updateNow;
    window.updateNow=function(t,...args) {
      const result=originalUpdateNow.call(this,t,...args);
      miniTrackUpdated(t);
      if (fullPending && t?.id !== fullPending.id && !$("#fullplayer").hidden) {
        const dir=fullPending.dir, el=fullArt(); fullPending=null;
        if (el && motionOK() && el.animate) el.animate([{transform:`translateX(${-dir*90}px) scale(.96)`,opacity:0},{transform:"translateX(0) scale(1)",opacity:1}],{duration:300,easing:"cubic-bezier(.2,.8,.2,1)"});
      }
      return result;
    };
  }
  document.addEventListener("touchstart",e=>{
    const fp=$("#fullplayer"), art=e.target.closest("#fullplayer .fp-art");
    if (!art || fp.hidden || fp.classList.contains("q") || e.target.closest("button,[data-seek],[data-vol]") || e.touches.length!==1 || !S.current || Date.now()<fullGuard) return;
    fullSwipe={el:art,x:e.touches[0].clientX,y:e.touches[0].clientY,t:Date.now(),id:S.current.id,moving:false};
  },{passive:true});
  document.addEventListener("touchmove",e=>{
    if (!fullSwipe || e.touches.length!==1) return;
    const dx=e.touches[0].clientX-fullSwipe.x,dy=e.touches[0].clientY-fullSwipe.y;
    if (Math.abs(dx)>10 && Math.abs(dx)>Math.abs(dy)*1.4) {
      fullSwipe.moving=true;
      if (motionOK()) {
        fullSwipe.dx=dx;
        if (!fullSwipe.raf) fullSwipe.raf=requestAnimationFrame(()=>{
          const s=fullSwipe; if (!s) return; s.raf=0;
          const x=Math.max(-72,Math.min(72,s.dx*.45));
          s.el.style.willChange="transform, opacity";
          s.el.style.transform=`translateX(${x}px)`;s.el.style.opacity=String(1-Math.abs(x)/320);
        });
      }
    }
  },{passive:true});
  document.addEventListener("touchend",e=>{
    if (!fullSwipe || !e.changedTouches.length) return;
    const t=e.changedTouches[0], dx=t.clientX-fullSwipe.x,dy=t.clientY-fullSwipe.y, initial=fullSwipe;
    if (Date.now()-initial.t>=900 || Math.abs(dx)<55 || Math.abs(dx)<Math.abs(dy)*1.4 || initial.id!==S.current?.id) {clearFullDrag(true);fullSwipe=null;return;}
    e.preventDefault(); fullGuard=Date.now()+700;
    if (initial.raf) cancelAnimationFrame(initial.raf);
    if (dx>0 && S.index<=0) { clearFullDrag(true); fullSwipe=null; return void toast("Предыдущего трека в очереди нет",1800); }
    fullSwipe=null;
    const dir=dx<0?-1:1, el=initial.el;
    const go=()=>{
      el.style.transform=""; el.style.opacity=""; el.style.willChange="";
      fullPending={id:initial.id,dir};
      setTimeout(()=>{if(fullPending?.id===initial.id)fullPending=null;},10000);
      if (dx<0) next(); else playAt(S.index-1);
    };
    // the old cover keeps going the way the finger threw it, then the next one comes in from the other side
    if (motionOK() && el.animate) {
      const a=el.animate([{transform:el.style.transform||"translateX(0)",opacity:el.style.opacity||1},{transform:`translateX(${dir*110}px)`,opacity:0}],{duration:150,easing:"cubic-bezier(.4,0,1,1)",fill:"forwards"});
      a.finished.catch(()=>{}).then(()=>{ go(); requestAnimationFrame(()=>a.cancel()); });
    } else go();
  },{passive:false});
  document.addEventListener("touchcancel",()=>{clearFullDrag(true);fullSwipe=null;},{passive:true});
  document.addEventListener("click",e=>{if(Date.now()<fullGuard && e.target.closest("#fullplayer .fp-art")){e.preventDefault();e.stopImmediatePropagation();}},true);

  /* 4.20: a swipe down anywhere on the full player closes it, like the ‹ arrow. The player follows the finger; a long
     enough pull (or a quick flick) closes it, a short one springs back. Horizontal swipes on the cover (next /
     previous track), the seek and volume bars, the queue and lists that are scrolled down are left alone. */
  let fpDown = null, fpDownGuard = 0;
  const scrolledInside = (el, fp) => {
    for (let n = el; n && n !== fp; n = n.parentElement) if (n.scrollTop > 0 && n.scrollHeight > n.clientHeight + 2) return true;
    return false;
  };
  /* 4.20.1: once the full player has opened, everything under it (the wave, its glow, the station strip, the
     ambient light) stops being drawn — it is covered by the opaque player anyway, and on phones with a weaker GPU
     (Pixel 6 Pro: ~10 fps) those animated, blurred layers were composited on every frame. Shown again while the
     player is dragged down and when it closes. */
  let stillTimer = 0;
  function fpStill(on) {
    clearTimeout(stillTimer);
    const b = document.body, open = () => b.classList.contains("fp-open") && !$("#fullplayer")?.hidden && !fpDown?.active;
    if (!on) return b.classList.remove("fp-still");
    stillTimer = setTimeout(() => b.classList.toggle("fp-still", open()), 380);
  }
  new MutationObserver(() => {
    const open = document.body.classList.contains("fp-open");
    if (open !== document.body.classList.contains("fp-still")) fpStill(open);
  }).observe(document.body, { attributes: true, attributeFilter: ["class"] });

  /* 4.20.1: the light mode for a slow GPU — measured, not guessed. Each time the full player opens, the frames of
     its first second are counted; under ~20 fps once, or under 35 fps twice, the heavy blurs of the player (the
     blurred cover behind it, the frosted buttons) are replaced with plain ones and the setting is remembered. */
  const LOWFX = "wave.lowfx";
  let slowOpens = 0;
  try {
    if (localStorage.getItem(LOWFX) === "1") document.documentElement.dataset.lowfx = "1";
    slowOpens = +localStorage.getItem(LOWFX + ".slow") || 0;
  } catch {}
  let probing = false;
  function probeFps() {
    if (probing || document.documentElement.dataset.lowfx === "1" || document.hidden) return;
    probing = true;
    let n = 0;
    const t0 = performance.now();
    const tick = (t) => {
      if (t - t0 < 1000) { n++; return requestAnimationFrame(tick); }
      probing = false;
      if (document.hidden || !document.body.classList.contains("fp-open")) return;
      const fps = (n * 1000) / (t - t0);
      if (fps < 35) slowOpens++;
      const low = fps < 20 || slowOpens >= 2;
      try { localStorage.setItem(LOWFX + ".slow", String(slowOpens)); if (low) localStorage.setItem(LOWFX, "1"); } catch {}
      if (low) document.documentElement.dataset.lowfx = "1";
    };
    requestAnimationFrame(tick);
  }
  new MutationObserver(() => { if (document.body.classList.contains("fp-open") && !document.body.classList.contains("fp-still")) probeFps(); })
    .observe(document.body, { attributes: true, attributeFilter: ["class"] });

  const fpDownReset = (fp, animate) => {
    const from = fp.style.transform, op = fp.style.opacity;
    fp.style.transform = ""; fp.style.opacity = "";
    if (animate && from && motionOK() && fp.animate)
      fp.animate([{ transform: from, opacity: op || 1 }, { transform: "none", opacity: 1 }], { duration: 220, easing: "cubic-bezier(.2,.8,.2,1)" });
  };
  document.addEventListener("touchstart", (e) => {
    fpDown = null;
    const fp = $("#fullplayer"), tg = e.target;
    if (!fp || fp.hidden || fp._closing || e.touches.length !== 1 || !fp.contains(tg) || fp.classList.contains("q")) return;
    if (tg.closest("[data-seek],[data-vol],input,select,textarea,#fpq,#sndp,.menu") || scrolledInside(tg, fp)) return;
    fpDown = { fp, x: e.touches[0].clientX, y: e.touches[0].clientY, t: Date.now(), active: false, dy: 0 };
  }, { passive: true });
  document.addEventListener("touchmove", (e) => {
    if (!fpDown || e.touches.length !== 1) return;
    const dx = e.touches[0].clientX - fpDown.x, dy = e.touches[0].clientY - fpDown.y;
    if (!fpDown.active) {
      if (dy > 12 && dy > Math.abs(dx) * 1.3) { fpDown.active = true; fpStill(false); }
      else if (Math.abs(dx) > 12 || dy < -12) { fpDown = null; return; }
      else return;
    }
    if (e.cancelable) e.preventDefault();
    fpDown.dy = Math.max(0, dy);
    fpDown.fp.style.transform = `translateY(${fpDown.dy}px)`;
    fpDown.fp.style.opacity = String(Math.max(0.35, 1 - fpDown.dy / (innerHeight * 1.1)));
  }, { passive: false });
  document.addEventListener("touchend", (e) => {
    const d = fpDown;
    fpDown = null;
    if (!d || !d.active) return;
    setTimeout(() => fpStill(true), 450);
    if (e.cancelable) e.preventDefault();
    fpDownGuard = Date.now() + 500;
    const speed = d.dy / Math.max(1, Date.now() - d.t);
    if (d.dy < 110 && !(d.dy > 45 && speed > 0.6)) return fpDownReset(d.fp, true);
    const done = () => {
      d.fp.style.transform = ""; d.fp.style.opacity = "";
      if (typeof closeFull === "function") closeFull(true);
    };
    if (!motionOK() || !d.fp.animate) return done();
    d.fp
      .animate([{ transform: `translateY(${d.dy}px)`, opacity: d.fp.style.opacity || 1 }, { transform: "translateY(100%)", opacity: 0.2 }], { duration: 180, easing: "cubic-bezier(.4,0,1,1)", fill: "forwards" })
      .finished.catch(() => {})
      .then(done);
  }, { passive: false });
  document.addEventListener("touchcancel", () => { if (fpDown?.active) { fpDownReset(fpDown.fp, true); setTimeout(() => fpStill(true), 450); } fpDown = null; }, { passive: true });
  document.addEventListener("click", (e) => {
    if (Date.now() < fpDownGuard && e.target.closest("#fullplayer")) { e.preventDefault(); e.stopImmediatePropagation(); }
  }, true);

  /* ---------- the media notification / lock screen ---------- */
  const el = () => document.getElementById("audio");
  let lastSend = 0;
  /* 4.20.1: the cover of the system player / the status-bar island goes through Wave's own local server
     (http://127.0.0.1/px/…, the same proxy the interface uses) instead of being fetched by Java directly: on a Pixel
     the direct download gave nothing and the island showed a blank disc. The server fetches it with its own client
     and the Java side accepts http://127.0.0.1 addresses. Unknown CDNs keep the direct address. */
  const PX_HOSTS = /(^|\.)(sndcdn\.com|soundcloud\.cloud|audius\.co|audius\.org|audius\.network|yandex\.net|yandex\.ru|ytimg\.com|googleusercontent\.com|ggpht\.com|scdn\.co|spotifycdn\.com|deezer\.com|dzcdn\.net)$/i;
  function nativeCover(raw) {
    if (!raw || !/^https:/.test(raw)) return "";
    const u = typeof thumb === "function" ? thumb(raw, "l") : raw;
    let host = "";
    try { host = new URL(u).hostname; } catch { return ""; }
    const key = NATIVE && NATIVE.key ? NATIVE.key() : "";
    if (!key || !PX_HOSTS.test(host) || !/^http:\/\/127\.0\.0\.1(:\d+)?$/.test(location.origin)) return u;
    return `${location.origin}/px/${key}/?u=${encodeURIComponent(u)}`;
  }
  function sendMedia(force) {
    if (!NATIVE || !hasS()) return;
    const now = Date.now();
    if (!force && now - lastSend < 900) return;
    lastSend = now;
    const t = S.current;
    const a = el();
    if (!t || !a) return NATIVE.media(JSON.stringify({ state: "stopped" }));
    const loading = a.readyState < 3 && !a.paused;
    NATIVE.media(
      JSON.stringify({
        state: loading ? "loading" : a.paused ? "paused" : "playing",
        title: t.title || "",
        artist: t.artist || "",
        cover: nativeCover(t.cover),
        duration: isFinite(a.duration) ? a.duration : t.duration || 0,
        position: a.currentTime || 0,
        rate: a.playbackRate || 1,
      }),
    );
  }
  for (const ev of ["play", "playing", "pause", "ended", "seeked", "loadedmetadata", "waiting"])
    document.addEventListener(ev, (e) => e.target && e.target.tagName === "AUDIO" && sendMedia(true), true);
  setInterval(() => {
    const a = el();
    if (a && !a.paused) sendMedia(true);
  }, 10000);
  window.waveRemote = (a, arg) => {
    if (!hasS()) return;
    const au = el();
    if (a === "play") au && au.paused && togglePlay();
    else if (a === "pause") au && !au.paused && togglePlay();
    else if (a === "next") next();
    else if (a === "prev") prev();
    else if (a === "seek" && au) au.currentTime = (arg || 0) / 1000;
  };

  /* ---------- «Моя волна» before the first track: only the title and the big ▶ (body.m-started after the first sound) */
  /* ---------- the next track is resolved as soon as the current one plays (the PC does it 25 s before the end):
     «следующий» then starts at once instead of waiting for the network (takePre in playAt uses it) ---------- */
  let preT = 0;
  document.addEventListener(
    "playing",
    (e) => {
      if (!e.target || e.target.tagName !== "AUDIO") return;
      body.classList.add("m-started");
      clearTimeout(preT);
      preT = setTimeout(() => {
        try {
          if (typeof prefetchNext === "function") prefetchNext();
        } catch {}
      }, 1200);
    },
    true,
  );
  // a prefetched link is used for 4 minutes (signed CDN links expire) — refresh it while a long track plays
  setInterval(() => {
    const a = el();
    if (!a || a.paused || !hasS() || typeof XF === "undefined" || !XF.pre) return;
    if (Date.now() - XF.pre.at > 3.5 * 60e3) {
      XF.pre = null;
      try {
        prefetchNext();
      } catch {}
    }
  }, 30000);

  /* ---------- the «Моя волна» animation: ~20 frames a second on phones (the PC draws up to 70 — every frame is
     computed in JavaScript, which made the whole interface slow on phones). The motion is slow, it looks the same. */
  if (typeof setWinState === "function") setWinState(false, true);

  // the first ▶ of «Моя волна» starts the wave (not the track left in the player from last time)
  document.addEventListener(
    "click",
    (e) => {
      const b = e.target.closest('.wv-ctl [data-cmd="wave-play"]');
      if (!b || body.classList.contains("m-started") || !hasS() || typeof startWave !== "function") return;
      if (S.wave && S.current) return; // a wave is already loaded — the usual play / pause
      e.stopPropagation();
      e.preventDefault();
      startWave(S.waveOpts || {});
    },
    true,
  );

  /* ---------- the keyboard is open: the tab bar and the mini player step aside ---------- */
  const vv = window.visualViewport;
  let fullH = Math.max(innerHeight, vv ? vv.height : 0);
  const kb = () => {
    const h = vv ? vv.height : innerHeight;
    fullH = Math.max(fullH, h);
    const open = fullH - h > 140 && document.activeElement && /^(INPUT|TEXTAREA)$/.test(document.activeElement.tagName);
    body.classList.toggle("m-kb", !!open);
  };
  (vv || window).addEventListener("resize", kb);
  document.addEventListener("focusin", () => setTimeout(kb, 250));
  document.addEventListener("focusout", () => setTimeout(kb, 250));

  /* ---------- smooth page changes: the new page fades and rises in ---------- */
  const content = $("#content");
  if (content && window.MutationObserver) {
    let lastR = null;
    new MutationObserver(() => {
      const r = hasS() ? S.route : "";
      if (r === lastR) return;
      lastR = r;
      content.classList.remove("m-enter");
      // Artist/track pages already have a dedicated page-enter animation.
      if (content.dataset.pageEnter) return;
      void content.offsetWidth;
      content.classList.add("m-enter");
    }).observe(content, { childList: true });
  }

  /* ---------- first start on the phone: the light look of the glass (the heavy effects are for PC video cards).
     Saved once like any setting — «Настройки → Кастомизация» turns them back on. ---------- */
  (async () => {
    let done = false;
    try {
      done = localStorage.getItem("wave.m.fx") === "1";
    } catch {}
    if (done || typeof api !== "function") return;
    try {
      S.settings = await api("settings", { glassFx: "lite", liquid: { on: false } });
      if (typeof applySettings === "function") applySettings();
      localStorage.setItem("wave.m.fx", "1");
    } catch {}
  })();

  /* 4.20: the «Производительность» card (low-resource mode) is gone — the Rust backend left enough headroom. A mode
     switched on by an older version is switched off, so the animated background is never stuck without a toggle. */
  try {
    if (localStorage.getItem("wave.m.economy") === "1") {
      localStorage.setItem("wave.m.economy", "0");
      if (typeof WaveFx !== "undefined") WaveFx.resume();
    }
  } catch {}
  document.documentElement.dataset.waveEconomy = "0";

  /* 4.20.1: the settings on the phone go from the most needed to the least: what everybody changes first, the
     accounts and the wave next, looks and fine-tuning after, «О программе» (a bug report, updates) at the very end.
     Rows that only make sense on a PC are hidden. */
  const SET_ORDER = {
    main: ["Оформление", "Качество звука", "*more", "О программе"],
    more: ["Яндекс Музыка", "Моя волна", "Источники музыки", "Оффлайн", "Импорт плейлистов", "Профиль", "Приватность профиля",
      "Анимация Моей волны", "Интерфейс", "Жидкое стекло", "Spotify"],
  };
  const PC_ROWS = ["Ширина боковой панели", "Аппаратное ускорение", "Блик за курсором"];
  function orderSettings() {
    const box = document.querySelector(".settings");
    if (!box) return;
    const cards = [...box.querySelectorAll(":scope > .scard")];
    const nameOf = (c) => (c.querySelector("h2")?.textContent || "").trim();
    for (const [tab, order] of Object.entries(SET_ORDER)) {
      const mine = cards.filter((c) => c.dataset.tab === tab);
      if (!mine.length) continue;
      const anchor = mine[mine.length - 1].nextSibling;
      const ranked = [...mine].sort((a, b) => {
        const ia = order.indexOf(nameOf(a) || (a.querySelector(".m-more-row") ? "*more" : ""));
        const ib = order.indexOf(nameOf(b) || (b.querySelector(".m-more-row") ? "*more" : ""));
        return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
      });
      // only when the order differs (the move itself triggers the observer again)
      if (ranked.some((c, i) => c !== mine[i])) for (const c of ranked) box.insertBefore(c, anchor);
    }
    for (const row of box.querySelectorAll(".row")) {
      const b = (row.querySelector(".lbl b")?.textContent || "").trim();
      if (PC_ROWS.includes(b) && !row.hidden) row.hidden = true;
    }
  }
  new MutationObserver(() => orderSettings()).observe(document.body, { childList: true, subtree: true });

  /* 4.20.1: search — while something is typed the mood chips step aside and the results take the screen */
  document.addEventListener("input", (e) => {
    if (e.target?.id !== "sq") return;
    e.target.closest(".content")?.classList.toggle("m-sq-on", !!e.target.value.trim());
  }, true);
  new MutationObserver(() => {
    const q = document.querySelector(".content #sq");
    if (q) q.closest(".content")?.classList.toggle("m-sq-on", !!q.value.trim());
  }).observe(document.body, { childList: true, subtree: true });

  /* 4.20.1: going to another page (from the «⋯» menu of the full player: «Перейти к исполнителю», «к альбому»…)
     closes the full player — the page opened behind it, so the menu looked broken */
  if (typeof go === "function") {
    const goOrig = go;
    window.go = function (...args) {
      if (document.body.classList.contains("fp-open") && typeof closeFull === "function") closeFull(true);
      return goOrig.apply(this, args);
    };
  }
  // the track panel lives in the page layer, under the full player: «О треке» from the player collapses it first
  if (typeof openTrackPanel === "function") {
    const tpOrig = openTrackPanel;
    window.openTrackPanel = function (...args) {
      if (document.body.classList.contains("fp-open") && typeof closeFull === "function") closeFull(true);
      return tpOrig.apply(this, args);
    };
  }

  /* ---------- the app went to the background / came back ---------- */
  // in the background nothing is drawn at all (the music plays on): the animation, lyrics and progress loops stop
  window.waveVisible = (v) => {
    body.classList.toggle("m-bg", !v);
    if (typeof setWinState === "function") setWinState(!v, true);
    // 4.20.1: also when going to the background — the app is still in the foreground during onPause, so Android
    // still lets the playback service start; once in the background (Pixel: frozen without it) it would be too late
    sendMedia(true);
  };
  window.waveLoginResult = () => {};
})();
