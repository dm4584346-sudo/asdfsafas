/* wave-extra.js — 4.20.3: profile export/import, swipe-to-close fallback, Yandex top on the favourites page */
(() => {
  "use strict";
  const $q = (s, r = document) => r.querySelector(s);
  const say = (m, ms) => (typeof toast === "function" ? toast(m, ms) : alert(m));
  const SECRET = /token|cookie|secret|password|passwd|session|auth/i;

  /* ---------- 1. Profile export / import (PC -> Android and back) ---------- */
  function collectProfile() {
    const ls = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith("wave.") && !SECRET.test(k)) ls[k] = localStorage.getItem(k);
    }
    const st = {};
    const src = (typeof S !== "undefined" && S.settings) || {};
    for (const k of Object.keys(src)) if (!SECRET.test(k)) st[k] = src[k];
    return { v: 1, app: "wave", at: Date.now(), settings: st, ls };
  }
  const encode = (o) => "WAVE1:" + btoa(unescape(encodeURIComponent(JSON.stringify(o))));
  function decode(code) {
    const s = String(code || "").trim();
    if (!s.startsWith("WAVE1:")) throw new Error("Это не код профиля Wave");
    const o = JSON.parse(decodeURIComponent(escape(atob(s.slice(6)))));
    if (!o || o.app !== "wave") throw new Error("Код повреждён");
    return o;
  }
  async function exportProfile(box) {
    const code = encode(collectProfile());
    const ta = $q("#wx-code", box);
    if (ta) { ta.value = code; ta.select(); }
    let ok = false;
    try { ok = typeof api === "function" ? await api("copy-text", { text: code }) : false; } catch {}
    if (!ok) try { await navigator.clipboard.writeText(code); ok = true; } catch {}
    say(ok ? "Код профиля скопирован. Вставьте его на другом устройстве" : "Скопируйте код из поля вручную", 3500);
  }
  async function importProfile(box) {
    let data;
    try { data = decode($q("#wx-code", box)?.value); } catch (e) { return say(e.message, 3000); }
    if (!confirm("Заменить настройки этого устройства профилем из кода?")) return;
    let fails = 0;
    try {
      if (typeof api === "function") S.settings = await api("settings", data.settings || {});
    } catch {
      // the backend may reject some keys — try them one by one
      for (const [k, v] of Object.entries(data.settings || {})) {
        try { S.settings = await api("settings", { [k]: v }); } catch { fails++; }
      }
    }
    for (const [k, v] of Object.entries(data.ls || {})) try { localStorage.setItem(k, v); } catch { fails++; }
    say(fails ? `Профиль перенесён (не удалось: ${fails})` : "Профиль перенесён, перезапуск…", 2500);
    setTimeout(() => location.reload(), 1200);
  }
  function profileSection() {
    const sec = document.createElement("section");
    sec.id = "wx-profile";
    sec.className = "section wx-profile";
    sec.innerHTML = `<h2>Перенос профиля</h2>
      <p class="page-sub">Скопируйте код на ПК и вставьте его в приложении на телефоне (или наоборот). Входы в аккаунты (Яндекс, Spotify) не переносятся — войдите в них заново.</p>
      <textarea id="wx-code" rows="3" spellcheck="false" placeholder="Здесь появится код или вставьте сюда код с другого устройства"></textarea>
      <div class="wx-row"><button class="btn" id="wx-exp">Скопировать код профиля</button><button class="btn" id="wx-imp">Вставить код и применить</button></div>`;
    sec.querySelector("#wx-exp").onclick = () => exportProfile(sec);
    sec.querySelector("#wx-imp").onclick = () => importProfile(sec);
    return sec;
  }
  function ensureProfileSection() {
    return; // 4.21.3: «Перенос профиля» removed from the settings
    if (typeof S === "undefined" || S.route !== "settings") return;
    const c = $q("#content");
    if (!c || $q("#wx-profile", c)) return;
    const h = $q("h1.page", c);
    if (!h || !/Настройки/.test(h.textContent)) return;
    c.appendChild(profileSection());
  }
  const content = () => $q("#content");
  const startObs = () => {
    const c = content();
    if (!c) return setTimeout(startObs, 500);
    new MutationObserver(ensureProfileSection).observe(c, { childList: true });
    ensureProfileSection();
  };
  startObs();

  /* ---------- 2. Swipe-to-close fallback (Android 17 WebView may cancel touch events) ---------- */
  // a grab bar on top of the full player: tap — close, drag down — close (pointer events, works with any WebView)
  function ensureGrab() {
    const fp = $q("#fullplayer");
    if (!fp || $q(".wx-grab", fp)) return;
    const g = document.createElement("div");
    g.className = "wx-grab";
    g.setAttribute("role", "button");
    g.setAttribute("aria-label", "Свернуть плеер");
    g.innerHTML = "<i></i>";
    fp.prepend(g);
    let st = null;
    const close = () => { fp.style.transform = ""; fp.style.opacity = ""; if (typeof closeFull === "function") closeFull(true); };
    g.addEventListener("pointerdown", (e) => { st = { y: e.clientY, t: Date.now(), dy: 0 }; g.setPointerCapture?.(e.pointerId); });
    g.addEventListener("pointermove", (e) => {
      if (!st) return;
      st.dy = Math.max(0, e.clientY - st.y);
      fp.style.transform = `translateY(${st.dy}px)`;
      fp.style.opacity = String(Math.max(0.35, 1 - st.dy / (innerHeight * 1.1)));
    });
    const end = () => {
      if (!st) return;
      const d = st; st = null;
      const fast = d.dy / Math.max(1, Date.now() - d.t) > 0.5;
      if (d.dy < 8 || d.dy > 110 || (d.dy > 40 && fast)) return close();
      fp.style.transform = ""; fp.style.opacity = "";
    };
    g.addEventListener("pointerup", end);
    g.addEventListener("pointercancel", end);
  }
  new MutationObserver(() => { if (document.body.classList.contains("fp-open")) ensureGrab(); })
    .observe(document.body, { attributes: true, attributeFilter: ["class"] });

  /* ---------- 3. Yandex Music top (with listening time) on the «Любимые исполнители» page ---------- */
  if (typeof favArtistsView === "function") {
    const orig = favArtistsView;
    window.favArtistsView = function (...a) {
      const r = orig.apply(this, a);
      if (S?.settings?.ymToken && typeof api === "function" && typeof topArtistsHtml === "function") {
        const route = S.route;
        (S.ymTop ? Promise.resolve(S.ymTop) : api("ym-top-artists").catch(() => null)).then((list) => {
          if (!Array.isArray(list) || !list.length || S.route !== route) return;
          S.ymTop = list;
          const c = $q("#content"), h = c && $q("h1.page", c);
          if (!h || $q("#wx-ymtop", c)) return;
          const sec = document.createElement("section");
          sec.id = "wx-ymtop";
          sec.className = "section";
          sec.innerHTML = `<div class="sec-head"><h2>Топ месяца в Яндекс Музыке</h2></div><div class="ytop ym" id="wx-ymtop-list">${topArtistsHtml(list)}</div>`;
          (h.nextElementSibling || h).after(sec);
        });
      }
      return r;
    };
  }
})();

/* wave-extra: background-play permission prompt on launch (Android) */
(() => {
  "use strict";
  const N = window.WaveBattery || window.WaveAndroid;
  if (!N) return;
  const KEY = "wave.bgAsk";
  const has = (f) => typeof N[f] === "function";
  const ok = () => { try { return has("batteryUnrestricted") && !!N.batteryUnrestricted(); } catch { return false; } };
  if (ok()) return;
  const st = localStorage.getItem(KEY);
  // native API present: ask every launch until granted (unless "don't ask"); otherwise show once
  if (st === "never" || (!has("requestBattery") && st === "shown")) return;
  const show = () => {
    if (document.getElementById("wx-bg")) return;
    const d = document.createElement("div");
    d.id = "wx-bg";
    d.innerHTML = `<div class="wx-bg-card" role="dialog" aria-modal="true">
      <div class="wx-bg-ic">🔋</div>
      <h3>Разрешите работу в фоне</h3>
      <p>Чтобы музыка не останавливалась при выключенном экране, Android должен разрешить Wave работать без ограничений батареи.</p>
      ${has("requestBattery") ? `<ol><li>Нажмите «Открыть настройки»</li><li>Батарея</li><li>«Без ограничений»</li></ol>` : `<ol><li>Настройки → Приложения → Wave</li><li>Батарея</li><li>«Без ограничений»</li></ol>`}
      <button class="wx-bg-go">${has("requestBattery") ? "Открыть настройки" : "Понятно"}</button>
      <button class="wx-bg-later">Позже</button>
      <button class="wx-bg-never">Больше не спрашивать</button>
    </div>`;
    const close = () => d.remove();
    d.querySelector(".wx-bg-go").onclick = () => {
      localStorage.setItem(KEY, "shown");
      if (has("requestBattery")) { try { N.requestBattery(); } catch {} }
      else close();
    };
    d.querySelector(".wx-bg-later").onclick = () => { localStorage.setItem(KEY, "shown"); close(); };
    d.querySelector(".wx-bg-never").onclick = () => { localStorage.setItem(KEY, "never"); close(); };
    document.body.appendChild(d);
    document.addEventListener("visibilitychange", () => { if (!document.hidden && ok()) close(); });
  };
  // wait until the splash is gone
  const start = () => setTimeout(show, 2500);
  if (document.readyState === "complete") start(); else addEventListener("load", start, { once: true });
})();
