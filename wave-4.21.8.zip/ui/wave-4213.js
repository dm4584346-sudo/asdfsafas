/* Wave 4.21.3 — «Black» is the only look on the phone.
   - the "wave" skin (circles on the Wave screen) is always on;
   - «Интерфейс», «Тема», «Оформление», «Акцентный цвет» are removed from the settings. */
(function () {
  "use strict";
  const root = document.documentElement;
  const DROP_SEGS = ["ui", "theme", "skin", "accent"];

  /* ---------- 1. circles: the skin attribute is always "wave" ---------- */
  const keepWave = () => {
    if (root.dataset.skin && root.dataset.skin !== "wave") root.dataset.skin = "wave";
  };
  keepWave();
  new MutationObserver(keepWave).observe(root, { attributes: true, attributeFilter: ["data-skin"] });

  /* ---------- 2. saved values that break the black look are reset once ---------- */
  function fixValues() {
    let s;
    try { s = S && S.settings; } catch { return false; }
    if (!s || !Object.keys(s).length || typeof api !== "function") return false;
    const patch = {};
    if (s.ui === "classic") patch.ui = "glass";
    if (s.theme === "light") patch.theme = "dark";
    if (s.skin !== "wave") patch.skin = "wave";
    if (!Object.keys(patch).length) return true;
    Object.assign(s, patch);
    try { if (typeof applySettings === "function") applySettings(); } catch {}
    keepWave();
    Promise.resolve(api("settings", patch)).catch(() => {});
    return true;
  }
  let tries = 0;
  const t = setInterval(() => {
    if (fixValues() || ++tries > 60) clearInterval(t);
  }, 500);

  /* ---------- 3. remove the rows from the settings ---------- */
  let busy = false;
  function clean() {
    if (busy) return;
    const box = document.querySelector(".settings");
    if (!box) return;
    busy = true;
    try {
      const touched = new Set();
      for (const k of DROP_SEGS) {
        box.querySelectorAll(`[data-seg="${k}"]`).forEach((seg) => {
          const row = seg.closest(".row");
          if (row && row.parentNode) {
            const card = row.closest(".scard");
            if (card) touched.add(card);
            row.remove();
          }
        });
      }
      // only a card that we emptied ourselves goes away
      touched.forEach((c) => {
        if (!c.querySelector(".row, button, input, select, textarea, details, .m-more-row")) c.remove();
      });
    } finally {
      busy = false;
    }
  }
  // only react when something was added, and never write text (no self-triggering loop)
  let queued = false;
  new MutationObserver((list) => {
    if (queued) return;
    if (!list.some((m) => m.addedNodes.length)) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      clean();
    });
  }).observe(document.body, { childList: true, subtree: true });
  clean();
})();
