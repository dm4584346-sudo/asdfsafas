"use strict";
/* Wave Android — ТЗ 3.4.2: таймер сна.
   Секция в панели «Настройки звука»: 15 / 30 / 60 минут, «до конца трека», «Выкл».
   Остановка музыки — той же механикой, что кнопка паузы (stopFades + audio.pause).
   «До конца трека»: следующий трек не начинается — гасится готовый кроссфейд (XF.nx),
   переход перехватывается на next(true) (авто-переход; ручные перемотки работают как обычно). */
(() => {
  const isMob = () => document.documentElement.hasAttribute("data-mobile");

  let mode = null; // null | "track" | минуты числом
  let until = 0; // конец отсчёта (ms) для минутных режимов
  let timer = 0; // setTimeout отсчёта
  let guard = 0; // интервал-страховка

  const stopTimers = () => {
    clearTimeout(timer);
    clearInterval(guard);
    timer = 0;
    guard = 0;
  };
  const pauseNow = () => {
    try {
      stopFades();
    } catch {}
    try {
      audio.pause();
    } catch {}
  };

  /* ---------- индикация ---------- */
  const pad = (n) => String(n).padStart(2, "0");
  function paint() {
    const el = document.getElementById("slp-status");
    if (!el) return;
    if (mode == null) {
      el.textContent = "Музыка будет играть, пока вы сами её не выключите";
    } else if (mode === "track") {
      el.textContent = "Этот трек доиграет — и плеер остановится";
    } else {
      const s = Math.max(0, Math.ceil((until - Date.now()) / 1000));
      el.textContent = `Пауза через ${Math.floor(s / 60)}:${pad(s % 60)}`;
    }
  }
  const chipOn = (v) => (v === "off" ? mode == null : v === "track" ? mode === "track" : mode === +v);
  function syncChips() {
    document.querySelectorAll("#slp-chips [data-slp]").forEach((b) => b.classList.toggle("on", chipOn(b.dataset.slp)));
  }

  /* ---------- режимы ---------- */
  function disarm() {
    stopTimers();
    mode = null;
    until = 0;
    paint();
    syncChips();
  }
  function arm(min) {
    stopTimers();
    mode = min;
    until = Date.now() + min * 60000;
    timer = setTimeout(() => {
      stopTimers();
      mode = null;
      until = 0;
      pauseNow();
      toast("Таймер сна: пауза");
      paint();
      syncChips();
    }, until - Date.now());
    guard = setInterval(paint, 500);
    paint();
    syncChips();
  }
  function armTrack() {
    stopTimers();
    mode = "track";
    guard = setInterval(() => {
      // кроссфейд не должен подхватить следующий трек: гасим подготовленный (XF.nx) сразу, как он появился
      if (mode === "track") {
        try {
          if (XF && XF.nx) dropPending();
        } catch {}
      }
    }, 200);
    paint();
    syncChips();
    toast("Этот трек доиграет — и пауза", 2400);
  }

  /* авто-переход в конце трека: перехватываем next(true); ручной «Следующий» (next()) работает как обычно */
  if (typeof next === "function") {
    const origNext = next;
    window.next = function (autoplay = false) {
      if (mode === "track" && autoplay === true) {
        stopTimers();
        mode = null;
        until = 0;
        pauseNow();
        toast("Таймер сна: плеер остановлен");
        paint();
        syncChips();
        return;
      }
      return origNext(autoplay);
    };
  }
  // путь кроссфейда: сбрасываем подготовленный трек до того, как обработчик «ended» его возьмёт
  document.addEventListener(
    "ended",
    () => {
      if (mode !== "track") return;
      try {
        if (XF && XF.nx) dropPending();
      } catch {}
      setTimeout(() => {
        if (mode !== "track") return; // next(true) уже остановил плеер
        pauseNow();
        stopTimers();
        mode = null;
        until = 0;
        toast("Таймер сна: плеер остановлен");
        paint();
        syncChips();
      }, 150);
    },
    true,
  );

  /* ---------- секция в панели звука ---------- */
  const sectionHtml = () => `
  <section class="sndp-sec slp-sec">
    <div class="sndp-row"><span class="sndp-l">Таймер сна<small>Остановит музыку сам — удобно перед сном</small></span></div>
    <div class="sndp-chips" id="slp-chips">
      <button class="sndp-chip" data-slp="15">15 мин</button>
      <button class="sndp-chip" data-slp="30">30 мин</button>
      <button class="sndp-chip" data-slp="60">60 мин</button>
      <button class="sndp-chip" data-slp="track">Конец трека</button>
      <button class="sndp-chip" data-slp="off">Выкл</button>
    </div>
    <p class="slp-note" id="slp-status"></p>
  </section>`;

  function inject() {
    const el = typeof sndBox === "function" ? sndBox() : null;
    if (!el || !isMob() || el.querySelector(".slp-sec")) return;
    el.insertAdjacentHTML("beforeend", sectionHtml());
    paint();
    syncChips();
  }
  if (typeof renderSnd === "function") {
    const origRender = renderSnd;
    window.renderSnd = function (...a) {
      const r = origRender.apply(this, a);
      try {
        inject();
      } catch {}
      return r;
    };
  }
  // чипы живут в перерисовываемой панели — ловим клики делегированием
  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-slp]");
    if (!b || !isMob()) return;
    const v = b.dataset.slp;
    if (v === "off") disarm();
    else if (v === "track") armTrack();
    else arm(+v);
  });
})();
