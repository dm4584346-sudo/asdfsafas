"use strict";
/* Wave Android — window.wave for the desktop interface (app/ui) inside the Android WebView.
   On the PC preload.cjs gives window.wave.call / window.wave.on over Electron IPC; here the same two functions talk
   to the local Node.js server of the app (mobile/node/server.cjs), which runs the same core (main.cjs).
   Stream addresses of the CDNs go through the server too: the WebView page (http://127.0.0.1) needs CORS headers
   for hls.js and for Web Audio (equalizer, «Микс», the reaction of «Моя волна»), and the CDNs do not always send them. */
(() => {
  const NATIVE = window.WaveAndroid || null;
  const KEY = NATIVE ? NATIVE.key() : new URLSearchParams(location.search).get("k") || "";

  /* 4.20.1: localStorage that survives restarts. Android starts the local server on a new random port each time and
     the WebView keeps localStorage per origin (the port is part of it), so every start began with an empty storage:
     the welcome screens came back, remembered covers and modes were lost. The core keeps a copy on disk; it is
     loaded back here, synchronously, before the interface reads anything, and every write is mirrored to it. */
  if (NATIVE && KEY && window.localStorage) {
    try {
      const x = new XMLHttpRequest();
      x.open("POST", "/api/call", false);
      x.setRequestHeader("Content-Type", "application/json");
      x.setRequestHeader("X-Wave-Key", KEY);
      x.send(JSON.stringify({ cmd: "kv-all", data: {} }));
      const j = JSON.parse(x.responseText || "{}");
      if (j.ok && j.value && typeof j.value === "object")
        for (const [k, v] of Object.entries(j.value)) if (typeof v === "string") Storage.prototype.setItem.call(localStorage, k, v);
    } catch {}
    const pend = { set: {}, del: [] };
    let flushT = 0;
    const flush = () => {
      flushT = 0;
      const body = { set: pend.set, del: pend.del };
      pend.set = {};
      pend.del = [];
      fetch("/api/call", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Wave-Key": KEY },
        body: JSON.stringify({ cmd: "kv-set", data: body }),
        keepalive: true,
      }).catch(() => {});
    };
    const later = () => { if (!flushT) flushT = setTimeout(flush, 250); };
    const setI = Storage.prototype.setItem, remI = Storage.prototype.removeItem, clrI = Storage.prototype.clear;
    Storage.prototype.setItem = function (k, v) {
      setI.call(this, k, v);
      if (this === window.localStorage) { k = String(k); pend.set[k] = String(v); pend.del = pend.del.filter((x) => x !== k); later(); }
    };
    Storage.prototype.removeItem = function (k) {
      remI.call(this, k);
      if (this === window.localStorage) { k = String(k); delete pend.set[k]; pend.del.push(k); later(); }
    };
    Storage.prototype.clear = function () {
      clrI.call(this);
      if (this === window.localStorage) fetch("/api/call", { method: "POST", headers: { "Content-Type": "application/json", "X-Wave-Key": KEY }, body: JSON.stringify({ cmd: "kv-set", data: { clear: true } }) }).catch(() => {});
    };
    addEventListener("pagehide", () => { if (flushT) { clearTimeout(flushT); flush(); } });
    document.addEventListener("visibilitychange", () => { if (document.hidden && flushT) { clearTimeout(flushT); flush(); } });
  }
  // SoundCloud sends CORS headers itself (Access-Control-Allow-Origin: *): its streams go straight to the CDN — every
  // piece of the track through Node on the phone made the start slow. The other CDNs go through the local server.
  const DIRECT = /^https:\/\/([a-z0-9-]+\.)*(soundcloud\.cloud|sndcdn\.com)\//i;
  const proxied = (u) =>
    typeof u === "string" && /^https:\/\//.test(u) && !DIRECT.test(u) ? `/px/${KEY}/?u=${encodeURIComponent(u)}` : u;

  /* ---------- what Electron does on the PC and the phone does here ---------- */
  // a file picker of Android (WebView <input type=file>); must start inside the tap that asked for it
  function pickFiles(accept, multiple) {
    return new Promise((resolve) => {
      const inp = document.createElement("input");
      inp.type = "file";
      inp.accept = accept;
      inp.multiple = !!multiple;
      inp.style.display = "none";
      document.body.appendChild(inp);
      let done = false;
      const end = (files) => {
        if (done) return;
        done = true;
        inp.remove();
        resolve(files);
      };
      inp.addEventListener("change", () => end([...(inp.files || [])]));
      inp.addEventListener("cancel", () => end([]));
      // older WebViews have no «cancel»: the page gets the focus back without a change
      window.addEventListener("focus", () => setTimeout(() => end([...(inp.files || [])]), 1200), { once: true });
      inp.click();
    });
  }
  async function upload(blob, name, reset) {
    const r = await fetch(`/api/upload?name=${encodeURIComponent(name)}${reset ? "&reset=1" : ""}`, {
      method: "POST",
      headers: { "X-Wave-Key": KEY, "Content-Type": "application/octet-stream" },
      body: blob,
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || "Не удалось передать файл");
  }
  // a picture → JPEG no wider than max (what nativeImage does on the PC); a GIF stays a GIF when small
  async function prepImage(file, max, keepGif) {
    if (keepGif && /gif/i.test(file.type)) return { blob: file, name: "image.gif" };
    const url = URL.createObjectURL(file);
    try {
      const img = await new Promise((ok, bad) => {
        const im = new Image();
        im.onload = () => ok(im);
        im.onerror = () => bad(new Error("Не удалось прочитать изображение (подходят PNG, JPG и GIF)"));
        im.src = url;
      });
      const k = Math.min(1, max / img.naturalWidth);
      const c = document.createElement("canvas");
      c.width = Math.max(1, Math.round(img.naturalWidth * k));
      c.height = Math.max(1, Math.round(img.naturalHeight * k));
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      const blob = await new Promise((ok) => c.toBlob(ok, "image/jpeg", 0.88));
      return { blob, name: "image.jpg" };
    } finally {
      URL.revokeObjectURL(url);
    }
  }
  const IMG_MAX = { avatar: 512, banner: 2400, cover: 800 };
  function withPicked(accept, multiple, prep, then) {
    const picking = pickFiles(accept, multiple); // started synchronously, inside the tap
    return (async () => {
      const files = await picking;
      let first = true;
      for (const f of files) {
        const p = await prep(f);
        await upload(p.blob, p.name, first);
        first = false;
      }
      return then();
    })();
  }

  // cover colours (main.cjs reads them with nativeImage on the PC): the same algorithm on a 36×36 canvas
  const palCache = new Map();
  async function palette(url) {
    if (palCache.has(url)) return palCache.get(url);
    const src = /^https:/.test(url) ? proxied(url) : url;
    const img = await new Promise((ok, bad) => {
      const im = new Image();
      im.crossOrigin = "anonymous";
      im.onload = () => ok(im);
      im.onerror = () => bad(new Error("Обложка не загрузилась"));
      im.src = src;
    });
    const c = document.createElement("canvas");
    c.width = c.height = 36;
    const g = c.getContext("2d", { willReadFrequently: true });
    g.drawImage(img, 0, 0, 36, 36);
    const px = g.getImageData(0, 0, 36, 36).data;
    const hsl = (r, gg, b) => {
      ((r /= 255), (gg /= 255), (b /= 255));
      const mx = Math.max(r, gg, b),
        mn = Math.min(r, gg, b),
        l = (mx + mn) / 2;
      let h = 0,
        s = 0;
      if (mx !== mn) {
        const d = mx - mn;
        s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
        h = mx === r ? (gg - b) / d + (gg < b ? 6 : 0) : mx === gg ? (b - r) / d + 2 : (r - gg) / d + 4;
        h *= 60;
      }
      return [h, s, l];
    };
    const buckets = new Map();
    const grey = { r: 0, g: 0, b: 0, n: 0 };
    for (let k = 0; k < 36 * 36; k++) {
      const r = px[k * 4],
        gg = px[k * 4 + 1],
        b = px[k * 4 + 2],
        a = px[k * 4 + 3];
      if (a < 128) continue;
      const [hh, ss, ll] = hsl(r, gg, b);
      if (ll < 0.05 || ll > 0.97) continue;
      if (ss < 0.2 || ll < 0.1) {
        grey.r += r;
        grey.g += gg;
        grey.b += b;
        grey.n++;
        continue;
      }
      const key = Math.round(hh / 24) % 15;
      const x = buckets.get(key) || { r: 0, g: 0, b: 0, n: 0, w: 0 };
      x.r += r;
      x.g += gg;
      x.b += b;
      x.n++;
      x.w += ss * (1 - Math.abs(ll - 0.5));
      buckets.set(key, x);
    }
    const hex = (x) =>
      "#" + [x.r, x.g, x.b].map((v) => Math.round(v / x.n).toString(16).padStart(2, "0")).join("");
    const out = {
      colors: [...buckets.values()]
        .filter((x) => x.n >= 2)
        .sort((a, b) => b.w - a.w)
        .slice(0, 5)
        .map(hex),
      grey: grey.n ? hex(grey) : null,
      greyShare: grey.n / (36 * 36),
    };
    palCache.set(url, out);
    if (palCache.size > 400) palCache.delete(palCache.keys().next().value);
    return out;
  }

  // a YouTube clip: on the PC a separate view of Electron; here a player frame in the clip window of the interface
  function clipOpen(d) {
    const id = String(d.id || "").replace(/^yt:/, "");
    if (!/^[A-Za-z0-9_-]{11}$/.test(id)) throw new Error("Клип не найден");
    const box = document.querySelector(".clipbox .clip-frame");
    if (!box) return false;
    box.querySelector("iframe")?.remove();
    const f = document.createElement("iframe");
    f.src = `https://www.youtube-nocookie.com/embed/${id}?autoplay=1&rel=0&modestbranding=1&playsinline=1&hl=ru`;
    f.allow = "autoplay; encrypted-media; picture-in-picture; fullscreen";
    f.allowFullscreen = true;
    f.referrerPolicy = "strict-origin-when-cross-origin";
    f.style.cssText = "position:absolute;inset:0;width:100%;height:100%;border:0;border-radius:inherit;background:#000";
    box.style.position = "relative";
    box.appendChild(f);
    return true;
  }

  const LOCAL = {
    minimize: () => null,
    maximize: () => null,
    fullscreen: () => false,
    close: () => null,
    "mixer-init": () => ({ ok: true, skipped: true }),
    reload: () => (setTimeout(() => location.reload(), 30), true),
    logo: () => null,
    palette: (d) => palette(String(d.url || "")),
    "clip-open": clipOpen,
    "clip-bounds": () => true,
    "clip-close": () => (document.querySelector(".clipbox iframe")?.remove(), true),
    "pick-image": (d) =>
      withPicked("image/*", false, (f) => prepImage(f, IMG_MAX[d.kind] || 512, true), () => remote("pick-image", d)),
    "pick-gif": (d) => withPicked("image/gif", false, (f) => ({ blob: f, name: "image.gif" }), () => remote("pick-gif", d)),
    "playlist-cover": (d) =>
      d && d.remove
        ? remote("playlist-cover", d)
        : withPicked("image/*", false, (f) => prepImage(f, IMG_MAX.cover, true), () => remote("playlist-cover", d)),
    "playlist-upload": (d) =>
      withPicked("audio/*", true, (f) => ({ blob: f, name: f.name || "audio" }), () => remote("playlist-upload", d)),
  };

  function call(name, data) {
    name = String(name);
    if (LOCAL[name])
      try {
        return Promise.resolve(LOCAL[name](data || {}));
      } catch (e) {
        return Promise.reject(e);
      }
    return remote(name, data);
  }

  async function remote(name, data) {
    const r = await fetch("/api/call", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Wave-Key": KEY },
      body: JSON.stringify({ cmd: String(name), data: data === undefined ? {} : data }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || "Ошибка");
    let v = j.value;
    if (name === "stream" && v && v.url) v = { ...v, url: proxied(v.url) };
    // no Windows volume mixer on the phone
    if (name === "bootstrap" && v) v = { ...v, mixerGuard: false };
    return v;
  }

  const handlers = [];
  function on(fn) {
    if (typeof fn === "function") handlers.push(fn);
  }
  function listen() {
    if (!KEY) return;
    const es = new EventSource("/api/events?k=" + encodeURIComponent(KEY));
    es.onmessage = (m) => {
      let x;
      try {
        x = JSON.parse(m.data);
      } catch {
        return;
      }
      const v = x.value || {};
      if (x.kind === "native") return native(v);
      for (const fn of handlers)
        try {
          fn(v);
        } catch (e) {
          console.error(e);
        }
    };
  }
  // requests of the core that need the phone: open a link, copy, sign-in windows
  function native(v) {
    if (v.type === "open-url" && v.url) return NATIVE ? NATIVE.openUrl(v.url) : window.open(v.url, "_blank");
    if (v.type === "clipboard") return NATIVE ? NATIVE.copy(v.text || "") : navigator.clipboard?.writeText(v.text || "");
    // Spotify refuses its sign-in inside an app WebView: the phone's browser, the answer comes to the local server
    if (v.type === "window-open" && v.url && /^https:\/\/accounts\.spotify\.com\//.test(v.url)) {
      if (NATIVE) NATIVE.openUrl(v.url);
      else window.open(v.url, "_blank");
      return;
    }
    if (v.type === "window-open" && v.url) {
      // a sign-in window of the core (Яндекс, Spotify): the Android activity reports every address back
      if (NATIVE && NATIVE.authWindow) NATIVE.authWindow(String(v.id), v.url, v.watch || "");
      else window.open(v.url, "_blank");
    }
    if (v.type === "window-close" && NATIVE && NATIVE.authClose) NATIVE.authClose(String(v.id));
  }
  // the Android sign-in activity → the core window («will-redirect» / «closed»)
  window.waveAuthNav = (id, url) =>
    fetch("/api/window", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Wave-Key": KEY },
      body: JSON.stringify({ id: String(id), url: url || "", closed: !url }),
    }).catch(() => {});

  window.wave = Object.freeze({ call, on });
  window.waveMobile = { native: !!NATIVE, key: KEY, proxied };
  listen();
})();
