"use strict";
/* Wave Android — знакомство при первом запуске: три экрана после анимации заставки.
   1) «Это Wave» — музыка без цензуры;  2) «Откуда берётся музыка» — Яндекс Музыка, SoundCloud, YouTube Music;
   3) «Волна под ваш вкус» — вход в Яндекс («Яндекс подключён» → закрытие).
   4.20.1: появляется только когда заставка закончилась; слайды сменяются сразу, плавно (уход влево + появление
   справа, элементы выплывают по очереди); не показывается тем, кто уже прошёл его или уже вошёл в Яндекс.
   Флаг «wave.onboarded» переживает перезапуск: localStorage хранится в ядре (bridge.js). */
(() => {
  const root = document.documentElement;
  if (!root.hasAttribute("data-mobile")) return;
  const FLAG = "wave.onboarded";
  const seen = () => {
    try { return !!localStorage.getItem(FLAG); } catch { return false; }
  };
  const mark = () => { try { localStorage.setItem(FLAG, "1"); } catch {} };
  if (seen()) return;

  /* значки сервисов (свои рисунки в фирменных цветах, без внешних файлов) */
  const YM = `<svg viewBox="0 0 40 40"><defs><linearGradient id="obym" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffdb4d"/><stop offset=".55" stop-color="#ff9d00"/><stop offset="1" stop-color="#ff3d00"/></linearGradient></defs><circle cx="20" cy="20" r="20" fill="url(#obym)"/><path d="M23.5 10.5v12.2a4.3 4.3 0 1 1-2.6-3.95V13.6l-5.2 1.3v9.9a4.3 4.3 0 1 1-2.6-3.95v-8.3z" fill="#fff" transform="translate(1.2 1)"/></svg>`;
  const SC = `<svg viewBox="0 0 40 40"><rect width="40" height="40" rx="12" fill="#ff5500"/><path d="M27.6 27.5h-9.2V15.6a6.4 6.4 0 0 1 11.9 2.7 4.6 4.6 0 0 1-2.7 9.2z" fill="#fff"/><g fill="#fff"><rect x="15.6" y="17.2" width="1.6" height="10.3" rx=".8"/><rect x="12.8" y="18.8" width="1.6" height="8.7" rx=".8"/><rect x="10" y="20.6" width="1.6" height="6.9" rx=".8"/><rect x="7.2" y="22.6" width="1.6" height="4.9" rx=".8"/></g></svg>`;
  const YT = `<svg viewBox="0 0 40 40"><circle cx="20" cy="20" r="20" fill="#ff0033"/><circle cx="20" cy="20" r="10.5" fill="none" stroke="#fff" stroke-width="1.6"/><path d="M17.3 15.6v8.8l7.4-4.4z" fill="#fff"/></svg>`;
  const YA = `<svg viewBox="0 0 24 24" width="18" height="18"><path d="M13.6 20v-7.4L18.9 4h-2.7l-3.4 5.8L9.4 4H6.6l5.4 8.6V20z" fill="currentColor"/></svg>`;
  const OK = `<svg viewBox="0 0 24 24" width="22" height="22"><path d="m5 12.5 4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

  const slides = [
    `<span class="ob-kicker ob-in">Это Wave</span>
     <span class="ob-logo ob-in"><img src="assets/logo.png" alt=""></span>
     <h1 class="ob-h ob-in">Музыка<br>без цензуры</h1>
     <p class="ob-p ob-in">Полные версии треков — без урезанных радио-миксов и «запиканных» слов. Вы сами решаете, что звучит.</p>
     <div class="ob-btns ob-in"><button class="ob-btn acc" data-ob-next>Дальше</button></div>`,
    `<span class="ob-kicker ob-in">Откуда берётся музыка</span>
     <h1 class="ob-h ob-in">Три источника</h1>
     <div class="ob-srcs">
       <div class="ob-src ob-in"><i>${YM}</i><span><b>Яндекс Музыка</b><small>«Моя волна» и ваши лайки</small></span></div>
       <div class="ob-src ob-in"><i>${SC}</i><span><b>SoundCloud</b><small>полные версии треков</small></span></div>
       <div class="ob-src ob-in"><i>${YT}</i><span><b>YouTube Music</b><small>ремиксы и редкие треки</small></span></div>
     </div>
     <div class="ob-btns ob-in"><button class="ob-btn acc" data-ob-next>Дальше</button></div>`,
    `<span class="ob-kicker ob-in">Ваша музыка</span>
     <span class="ob-logo ob-ym ob-in">${YM}</span>
     <h1 class="ob-h ob-in">Волна под ваш вкус</h1>
     <p class="ob-p ob-in">«Моя волна» подберёт треки по вашему вкусу, а лайки из Яндекс Музыки перенесутся в Wave.</p>
     <div class="ob-btns ob-in">
       <button class="ob-btn acc" data-ob-ym>${YA}<span>Войти в Яндекс</span></button>
       <button class="ob-btn ghost" data-ob-skip>Позже</button>
     </div>`,
  ];

  let el = null, cur = 0, busy = false;
  const dots = () => el.querySelectorAll(".ob-dots i");
  function paint(i, dir) {
    const stage = el.querySelector(".ob-stage");
    const old = stage.querySelector(".ob-slide.on");
    const s = document.createElement("div");
    s.className = "ob-slide on" + (dir < 0 ? " from-left" : "");
    s.innerHTML = slides[i];
    // the elements come in one after another
    [...s.querySelectorAll(".ob-in")].forEach((n, k) => n.style.setProperty("--d", 60 + k * 70 + "ms"));
    if (old) {
      old.classList.remove("on");
      old.classList.add(dir < 0 ? "leave-right" : "leave-left");
      setTimeout(() => old.remove(), 420);
    }
    stage.appendChild(s);
    dots().forEach((d, k) => d.classList.toggle("on", k === i));
    el.querySelector("[data-ob-skip-top]").hidden = i === slides.length - 1;
  }
  function go(i) {
    i = Math.max(0, Math.min(slides.length - 1, i));
    if (i === cur) return;
    const dir = i > cur ? 1 : -1;
    cur = i;
    paint(i, dir);
  }
  function close() {
    mark();
    el.classList.add("out");
    setTimeout(() => el.remove(), 520);
  }
  async function ym(b) {
    if (busy) return;
    busy = true;
    b.disabled = true;
    b.querySelector("span").textContent = "Открываю вход…";
    try {
      const r = await api("ym-login");
      if (!r || r.cancelled || r.ok === false) throw new Error("вход отменён");
      try { S.settings = await api("settings", {}); } catch {}
      b.classList.add("done");
      b.innerHTML = `${OK}<span>Яндекс подключён${r.user ? " · " + esc(String(r.user)) : ""}</span>`;
      setTimeout(close, 1100);
    } catch (err) {
      busy = false;
      b.disabled = false;
      b.innerHTML = `${YA}<span>Войти в Яндекс</span>`;
      toast("Яндекс: " + (err && err.message ? err.message : "не удалось войти") + ". Войти можно позже в настройках", 5000);
    }
  }
  function open() {
    el = document.createElement("div");
    el.id = "onboard";
    el.className = "ob";
    el.setAttribute("role", "dialog");
    el.setAttribute("aria-label", "Знакомство с Wave");
    el.innerHTML = `<button class="ob-later" data-ob-skip data-ob-skip-top>Пропустить</button><div class="ob-stage"></div><div class="ob-dots" aria-hidden="true"><i></i><i></i><i></i></div>`;
    document.body.appendChild(el);
    paint(0, 1);
    requestAnimationFrame(() => el.classList.add("in"));
    el.addEventListener("click", (e) => {
      if (e.target.closest("[data-ob-next]")) return go(cur + 1);
      if (e.target.closest("[data-ob-skip]")) return close();
      const b = e.target.closest("[data-ob-ym]");
      if (b) ym(b);
    });
    let x0 = null;
    el.addEventListener("touchstart", (e) => { if (e.touches.length === 1) x0 = e.touches[0].clientX; }, { passive: true });
    el.addEventListener("touchend", (e) => {
      if (x0 === null) return;
      const dx = e.changedTouches[0].clientX - x0;
      x0 = null;
      if (dx < -48) go(cur + 1);
      else if (dx > 48) go(cur - 1);
    }, { passive: true });
  }

  /* after the splash animation; skipped for whoever is already signed in to Yandex */
  const t0 = Date.now();
  const wait = setInterval(() => {
    if (seen()) return clearInterval(wait);
    const sp = document.getElementById("splash");
    const splashOn = sp && !sp.classList.contains("out");
    const ready = typeof S !== "undefined" && S && S.settings;
    if ((splashOn || !ready) && Date.now() - t0 < 20000) return;
    clearInterval(wait);
    if (ready && S.settings.ymToken) return mark();
    open();
  }, 120);
})();
